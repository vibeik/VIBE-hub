﻿; Скрипт установщика (Inno Setup 6). Сборка: ISCC /DMyAppVersion=1.0.0 installer\VibeHub.iss
; Предварительно должна существовать папка dist\VibeHub (результат PyInstaller).
#ifndef MyAppVersion
  #define MyAppVersion "0.0.0"
#endif
#define MyAppName "VIBE HUB"
#define MyAppExe "VibeHub.exe"

[Setup]
AppId={{BC920CD7-65D6-45A0-8467-4A834E700BC9}
AppName={#MyAppName}
AppVersion={#MyAppVersion}
AppPublisher={#MyAppName}
DefaultDirName={autopf}\VibeHub
DefaultGroupName={#MyAppName}
DisableProgramGroupPage=yes
PrivilegesRequired=lowest
PrivilegesRequiredOverridesAllowed=dialog
OutputDir=..\dist_installer
OutputBaseFilename=VibeHub-Setup-{#MyAppVersion}
SetupIconFile=..\assets\icons\vibehub.ico
UninstallDisplayIcon={app}\{#MyAppExe}
Compression=lzma2
SolidCompression=yes
WizardStyle=modern
ArchitecturesAllowed=x64
ArchitecturesInstallIn64BitMode=x64

[Languages]
Name: "russian"; MessagesFile: "compiler:Languages\Russian.isl"
Name: "english"; MessagesFile: "compiler:Default.isl"

[Tasks]
Name: "desktopicon"; Description: "{cm:CreateDesktopIcon}"; GroupDescription: "{cm:AdditionalIcons}"; Flags: unchecked

[Files]
Source: "..\dist\VibeHub\*"; DestDir: "{app}"; Flags: ignoreversion recursesubdirs createallsubdirs

[Icons]
Name: "{autoprograms}\{#MyAppName}"; Filename: "{app}\{#MyAppExe}"
Name: "{autodesktop}\{#MyAppName}"; Filename: "{app}\{#MyAppExe}"; Tasks: desktopicon

[Run]
Filename: "{app}\{#MyAppExe}"; Description: "{cm:LaunchProgram,{#MyAppName}}"; Flags: nowait postinstall skipifsilent

[CustomMessages]
russian.DeleteDataPrompt=Удалить также ваши данные VIBE HUB (база с целями и историей матчей, настройки, резервные копии, журналы)?%n%nЭто нельзя отменить. Автозапуск, сохранённые ключи API и токены Spotify будут удалены в любом случае.
english.DeleteDataPrompt=Also delete your VIBE HUB data (database with goals and match history, settings, backups, logs)?%n%nThis cannot be undone. The autostart entry, saved API keys and Spotify tokens are removed in any case.

[Code]
// Перед удалением файлов запускаем VibeHub.exe --cleanup: убирает автозапуск, ключи в Credential Manager и кэш.
// В тихом режиме (/SILENT, /VERYSILENT) данные пользователя сохраняются.
procedure CurUninstallStepChanged(CurUninstallStep: TUninstallStep);
var
  Args: String;
  ResultCode: Integer;
begin
  if CurUninstallStep = usUninstall then
  begin
    // закрыть приложение, иначе база и файлы будут заняты
    Exec(ExpandConstant('{sys}\taskkill.exe'), '/F /IM {#MyAppExe}', '', SW_HIDE, ewWaitUntilTerminated, ResultCode);
    Args := '--cleanup';
    if SuppressibleMsgBox(CustomMessage('DeleteDataPrompt'), mbConfirmation, MB_YESNO or MB_DEFBUTTON2, IDNO) = IDYES then
      Args := Args + ' --delete-data';
    Exec(ExpandConstant('{app}\{#MyAppExe}'), Args, '', SW_HIDE, ewWaitUntilTerminated, ResultCode);
  end;
end;
