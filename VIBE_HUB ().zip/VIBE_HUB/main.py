"""VIBE HUB — точка входа.

    python main.py              обычный запуск
    python main.py --minimized  запуск свёрнутым
    python main.py --debug      подробный журнал
    python main.py --no-glass   запуск без эффекта стекла (если окно рисуется неправильно)
    python main.py --selftest   проверка: создаёт окно и все страницы на временных данных, затем выходит
    python main.py --cleanup [--delete-data]
                                удалить автозапуск, ключи в Credential Manager и кэш (с --delete-data — и все данные)
"""
from __future__ import annotations

import argparse
import logging
import os
import sys
import tempfile
from pathlib import Path

# корень проекта в sys.path (запуск из любой папки)
sys.path.insert(0, str(Path(__file__).resolve().parent))

log = logging.getLogger("vibehub")


def _parse(argv: list[str]) -> argparse.Namespace:
    p = argparse.ArgumentParser(prog="VIBE HUB", description="Игровая панель для Windows 11")
    p.add_argument("--minimized", action="store_true", help="запустить свёрнутым")
    p.add_argument("--debug", action="store_true", help="подробный журнал")
    p.add_argument("--selftest", action="store_true", help="проверить создание всех страниц и выйти")
    p.add_argument("--no-glass", action="store_true", help="выключить эффект стекла (Acrylic/Mica) на этот запуск")
    p.add_argument("--cleanup", action="store_true", help="удалить автозапуск, ключи и кэш приложения и выйти")
    p.add_argument("--delete-data", action="store_true", help="вместе с --cleanup: удалить также базу, настройки, копии и журналы")
    return p.parse_args(argv)


def _fatal(title: str, text: str) -> None:
    """Сообщение об ошибке запуска без зависимости от остального приложения."""
    try:
        from PySide6.QtWidgets import QApplication, QMessageBox
        app = QApplication.instance() or QApplication(sys.argv)
        QMessageBox.critical(None, title, text)
        del app
    except Exception:
        sys.stderr.write(f"{title}\n{text}\n")


def _selftest(win) -> int:
    """Открывает каждую страницу; ошибка создания любой страницы = провал."""
    from ui.main_window import PAGES
    failed: list[str] = []
    for pid, *_rest in PAGES:
        win.show_page(pid)
        if pid not in win.pages:
            failed.append(pid)
            print(f"[FAIL] {pid}: страница не создана (см. журнал)")
        else:
            print(f"[ OK ] {pid}")
    return 1 if failed else 0


def _cleanup(delete_data: bool) -> int:
    """Работает без Qt, без базы и без журнала — ничего не создаёт на диске."""
    from modules import cleanup
    steps = cleanup.run(delete_data)
    out = sys.stdout
    if out is not None:                       # в сборке без консоли stdout может отсутствовать
        try:
            out.reconfigure(errors="replace")  # type: ignore[attr-defined]
        except (AttributeError, ValueError):
            pass
        for st in steps:
            print(st.line())
    return 0 if all(st.ok for st in steps) else 1


def main(argv: list[str] | None = None) -> int:
    args = _parse(sys.argv[1:] if argv is None else argv)

    if args.cleanup:
        return _cleanup(args.delete_data)
    if args.delete_data:
        sys.stderr.write("--delete-data работает только вместе с --cleanup\n")
        return 2

    if args.selftest:
        # временная папка данных и офскрин-платформа: пользовательские данные не затрагиваются
        os.environ.setdefault("VIBEHUB_DATA_DIR", tempfile.mkdtemp(prefix="vibehub-selftest-"))
        os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")

    try:
        from PySide6.QtCore import Qt, QTimer
        from PySide6.QtGui import QGuiApplication
        from PySide6.QtWidgets import QApplication
    except ImportError as exc:
        sys.stderr.write(f"Не установлен PySide6: {exc}\nЗапустите install.bat или: pip install -r requirements.txt\n")
        return 2

    from config import settings as cfg
    from utils.logger import setup_logging

    try:
        setup_logging(args.debug)
        log.info("Запуск %s %s", cfg.APP_NAME, cfg.APP_VERSION)

        if os.name == "nt":      # своя иконка в панели задач, а не python.exe
            try:
                import ctypes
                ctypes.windll.shell32.SetCurrentProcessExplicitAppUserModelID("VibeHub.App")  # type: ignore[attr-defined]
            except Exception:
                log.debug("AppUserModelID не установлен", exc_info=True)

        QGuiApplication.setHighDpiScaleFactorRoundingPolicy(Qt.HighDpiScaleFactorRoundingPolicy.PassThrough)
        app = QApplication(sys.argv[:1])
        app.setApplicationName(cfg.APP_NAME)
        app.setApplicationVersion(cfg.APP_VERSION)
        app.setOrganizationName(cfg.APP_ID)

        from ui.common.guard import StrayWindowGuard
        guard = StrayWindowGuard(app)      # страховка от мигающих окон (виджет без родителя + show())
        app.installEventFilter(guard)

        # второй экземпляр не должен трогать базу — проверяем до её открытия
        single = None
        if not args.selftest:
            from utils.single_instance import SingleInstance
            single = SingleInstance(cfg.data_dir())
            if not single.acquire():
                if single.notify_existing():
                    log.info("VIBE HUB уже запущен — окно показано")
                    return 0
                log.warning("Блокировка занята, но окно не отвечает — продолжаю запуск")

        from database.db import Database
        from modules import workers
        from modules.context import AppContext
        from ui import theme
        from utils import i18n
        from utils.i18n import _

        settings = cfg.Settings()
        db = Database.open_with_recovery(cfg.db_path(), cfg.backup_dir())
        workers.init()
        if not args.selftest and not db.recovered_from:
            try:       # одна авто-копия в сутки, хранятся последние 7
                db.auto_backup(cfg.backup_dir())
            except Exception:
                log.exception("Не удалось создать авто-копию базы")
        i18n.set_language(settings.get("language") or "ru")
        tm = theme.init(settings)
        from utils import winstyle
        tm.glass_mode = "off" if args.no_glass else winstyle.effective_glass_mode(settings.get("glass"))
        tm.apply(app)

        crashed = not bool(settings.get("clean_shutdown"))
        settings.set("clean_shutdown", False, notify=False)

        ctx = AppContext(settings, db)
        ctx.theme = tm

        from ui.main_window import MainWindow
        win = MainWindow(ctx)

        def _quit() -> None:
            try:
                ctx.shutdown()
            except Exception:
                log.exception("Ошибка при остановке")
            try:
                settings.set("clean_shutdown", True, notify=False)
                db.close()
            except Exception:
                log.exception("Ошибка при закрытии базы")
            if single is not None:
                single.release()
            log.info("Выход")

        app.aboutToQuit.connect(_quit)

        if args.selftest:
            rc = _selftest(win)
            win.close()
            QTimer.singleShot(0, app.quit)
            app.exec()
            print("SELFTEST:", "провал" if rc else "ok")
            return rc

        def _raise_window() -> None:
            win.showNormal()
            win.raise_()
            win.activateWindow()

        if single is not None:
            single.listen(_raise_window)

        win.open_initial_page()
        if args.minimized:
            win.showMinimized()
        else:
            win.show()

        if db.recovered_from:
            ctx.notify("warning", _("База данных восстановлена"), db.recovered_from)
        elif crashed:
            ctx.notify("info", _("Предыдущий сеанс завершился некорректно"),
                       _("Проверка локальной базы данных пройдена, данные на месте."))

        ctx.start()
        return app.exec()
    except Exception as exc:
        log.critical("Критическая ошибка запуска", exc_info=True)
        _fatal("VIBE HUB — ошибка запуска",
               f"Не удалось запустить приложение:\n{exc}\n\nПодробности: {cfg.log_dir() / 'vibehub.log'}")
        return 1


if __name__ == "__main__":
    sys.exit(main())
