"""Базовые виджеты дизайн-системы: Card, Chip, StatTile, EmptyState, SegmentedControl, Page и др."""
from __future__ import annotations

from typing import Callable, Iterable

from PySide6.QtCore import QEvent, QSize, Qt, Signal
from PySide6.QtGui import QMouseEvent
from PySide6.QtWidgets import (QButtonGroup, QFrame, QHBoxLayout, QLabel, QPushButton, QSizePolicy,
                               QToolButton, QVBoxLayout, QWidget)

from ui import icons, theme
from ui.common.util import set_prop, set_shown


# ---------------------------------------------------------------- простые фабрики
def label(text: str = "", role: str | None = None, *, wrap: bool = False, align: Qt.AlignmentFlag | None = None,
          selectable: bool = False, tone: str | None = None) -> QLabel:
    """role: H1 | H2 | H3 | Muted | Big | Value | CardTitle. tone: success | danger | warning | accent | muted."""
    lb = QLabel(text)
    if role:
        lb.setObjectName(role)
    if tone:
        lb.setProperty("tone", tone)
    lb.setWordWrap(wrap)
    if align is not None:
        lb.setAlignment(align)
    if selectable:
        lb.setTextInteractionFlags(Qt.TextInteractionFlag.TextSelectableByMouse)
    return lb


def set_tone(lb: QLabel, tone: str | None) -> None:
    set_prop(lb, "tone", tone or "")


def hline() -> QFrame:
    f = QFrame()
    f.setObjectName("Line")
    f.setFrameShape(QFrame.Shape.NoFrame)
    f.setFixedHeight(1)
    return f


def button(text: str = "", kind: str | None = None, icon: str | None = None, on_click: Callable | None = None,
           tooltip: str = "", icon_color: str | None = None) -> QPushButton:
    """kind: primary | danger | ghost | tile | None."""
    b = QPushButton(text)
    if kind:
        b.setProperty("kind", kind)
    if icon:
        col = icon_color or ("#FFFFFF" if kind == "primary" else theme.get().colors["text"])
        b.setIcon(icons.icon(icon, col, 18))
        b.setIconSize(QSize(18, 18))
    if tooltip:
        b.setToolTip(tooltip)
    if on_click:
        b.clicked.connect(lambda _=False: on_click())
    b.setCursor(Qt.CursorShape.PointingHandCursor)
    return b


class IconButton(QToolButton):
    """Кнопка-иконка, перекрашивается при смене темы."""

    def __init__(self, name: str, tooltip: str = "", *, size: int = 18, role: str = "muted", checkable: bool = False,
                 on_click: Callable | None = None, parent: QWidget | None = None):
        super().__init__(parent)
        self._name, self._size, self._role = name, size, role
        self.setCheckable(checkable)
        self.setToolTip(tooltip)
        self.setCursor(Qt.CursorShape.PointingHandCursor)
        self.setIconSize(QSize(size, size))
        self.setAutoRaise(True)
        self._paint_icon()
        theme.get().changed.connect(self._paint_icon)
        if on_click:
            self.clicked.connect(lambda _=False: on_click())

    def set_icon_name(self, name: str) -> None:
        self._name = name
        self._paint_icon()

    def _paint_icon(self) -> None:
        c = theme.get().colors
        self.setIcon(icons.icon(self._name, c.get(self._role, c["muted"]), self._size, on_color=c["text"]))


# ---------------------------------------------------------------- Card
class Card(QFrame):
    """Закруглённая полупрозрачная карточка. Содержимое добавляется в self.body."""
    clicked = Signal()

    def __init__(self, title: str = "", icon: str | None = None, *, clickable: bool = False,
                 parent: QWidget | None = None, margins: tuple[int, int, int, int] = (18, 16, 18, 16)):
        super().__init__(parent)
        self.setObjectName("Card")
        self._clickable = clickable
        self.setProperty("clickable", clickable)
        if clickable:
            self.setCursor(Qt.CursorShape.PointingHandCursor)
        self.root = QVBoxLayout(self)
        self.root.setContentsMargins(*margins)
        self.root.setSpacing(12)

        self.header = QHBoxLayout()
        self.header.setSpacing(8)
        self.icon_label = QLabel()
        self.icon_label.setFixedSize(18, 18)
        self.title_label = QLabel(title.upper() if title else "")
        self.title_label.setObjectName("CardTitle")
        self._icon_name = icon
        self.header.addWidget(self.icon_label)
        self.header.addWidget(self.title_label)
        self.header.addStretch(1)
        self._header_widget = QWidget(self)      # с родителем: без него setVisible(True) открыло бы отдельное окно
        self._header_widget.setLayout(self.header)
        self.root.addWidget(self._header_widget)
        self._header_widget.setVisible(bool(title or icon))
        self._paint_icon()
        theme.get().changed.connect(self._paint_icon)

        self.body = QVBoxLayout()
        self.body.setSpacing(10)
        self.root.addLayout(self.body, 1)

    def _paint_icon(self) -> None:
        if self._icon_name:
            self.icon_label.setPixmap(icons.pixmap(self._icon_name, theme.get().colors["muted"], 18))
            self.icon_label.show()
        else:
            self.icon_label.hide()

    def set_title(self, title: str) -> None:
        self.title_label.setText(title.upper())
        self._header_widget.setVisible(True)

    def add_header_widget(self, w: QWidget) -> None:
        self.header.addWidget(w)
        self._header_widget.setVisible(True)

    def mouseReleaseEvent(self, e: QMouseEvent) -> None:
        if self._clickable and e.button() == Qt.MouseButton.LeftButton and self.rect().contains(e.position().toPoint()):
            self.clicked.emit()
        super().mouseReleaseEvent(e)


class Inset(QFrame):
    """Внутренний блок (вложенная «плашка»)."""

    def __init__(self, parent: QWidget | None = None, margins: tuple[int, int, int, int] = (12, 10, 12, 10)):
        super().__init__(parent)
        self.setObjectName("Inset")
        self.root = QVBoxLayout(self)
        self.root.setContentsMargins(*margins)
        self.root.setSpacing(4)


class Chip(QLabel):
    """Маленький статус-ярлык. kind: neutral | success | warning | danger | accent."""

    def __init__(self, text: str = "", kind: str = "neutral", parent: QWidget | None = None):
        super().__init__(text, parent)
        self.setObjectName("Chip")
        self.setProperty("kind", kind)
        self.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.setSizePolicy(QSizePolicy.Policy.Maximum, QSizePolicy.Policy.Fixed)

    def set_kind(self, kind: str) -> None:
        set_prop(self, "kind", kind)

    def set(self, text: str, kind: str = "neutral") -> None:
        self.setText(text)
        self.set_kind(kind)


class StatTile(QFrame):
    """Плитка показателя: подпись, крупное значение, вторичная строка."""

    def __init__(self, caption: str, value: str = "—", sub: str = "", parent: QWidget | None = None):
        super().__init__(parent)
        self.setObjectName("Inset")
        lay = QVBoxLayout(self)
        lay.setContentsMargins(14, 12, 14, 12)
        lay.setSpacing(2)
        self.caption = label(caption, "Muted")
        self.value = label(value, "Value")
        self.sub = label(sub, "Muted")
        lay.addWidget(self.caption)
        lay.addWidget(self.value)
        lay.addWidget(self.sub)
        self.sub.setVisible(bool(sub))           # только после addWidget: у виджета уже есть родитель

    def set_value(self, value: str, sub: str = "", tone: str | None = None) -> None:
        self.value.setText(value)
        set_tone(self.value, tone)
        self.sub.setText(sub)
        self.sub.setVisible(bool(sub))


class EmptyState(QWidget):
    """Аккуратное состояние «нет данных»: иконка, заголовок, пояснение, опциональная кнопка."""

    def __init__(self, title: str, text: str = "", icon: str = "info", button_text: str = "",
                 on_click: Callable | None = None, parent: QWidget | None = None, compact: bool = False):
        super().__init__(parent)
        lay = QVBoxLayout(self)
        lay.setContentsMargins(16, 12 if compact else 28, 16, 12 if compact else 28)
        lay.setSpacing(8)
        lay.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.icon_label = QLabel()
        self.icon_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self._icon = icon
        self._size = 28 if compact else 40
        self.title = label(title, "H3", align=Qt.AlignmentFlag.AlignCenter, wrap=True)
        self.text = label(text, "Muted", align=Qt.AlignmentFlag.AlignCenter, wrap=True)
        lay.addWidget(self.icon_label)
        lay.addWidget(self.title)
        lay.addWidget(self.text)
        self.text.setVisible(bool(text))
        self.button: QPushButton | None = None
        if button_text:
            self.button = button(button_text, "primary", on_click=on_click)
            lay.addSpacing(4)
            lay.addWidget(self.button, 0, Qt.AlignmentFlag.AlignCenter)
        self._paint()
        theme.get().changed.connect(self._paint)

    def _paint(self) -> None:
        self.icon_label.setPixmap(icons.pixmap(self._icon, theme.get().colors["muted"], self._size))

    def set_texts(self, title: str, text: str = "") -> None:
        self.title.setText(title)
        self.text.setText(text)
        self.text.setVisible(bool(text))


class Banner(QFrame):
    """Полоса с пояснением (предупреждение / информация / ошибка)."""

    def __init__(self, text: str = "", kind: str = "warning", parent: QWidget | None = None):
        super().__init__(parent)
        self.setObjectName("Banner")
        self.setProperty("kind", kind)
        lay = QHBoxLayout(self)
        lay.setContentsMargins(12, 8, 12, 8)
        lay.setSpacing(10)
        self.icon_label = QLabel()
        self.icon_label.setFixedSize(18, 18)
        self.text = label(text, wrap=True)
        lay.addWidget(self.icon_label, 0, Qt.AlignmentFlag.AlignTop)
        lay.addWidget(self.text, 1)
        self._kind = kind
        self._paint()
        self._wanted = bool(text)
        if not text:
            self.hide()      # показывать (setVisible(True)) без родителя нельзя — откроется отдельное окно

    def event(self, e) -> bool:
        # баннер получил текст до того, как его положили в layout: показываем, когда появится родитель
        if e.type() == QEvent.Type.ParentChange and self._wanted and self.isHidden() and self.parentWidget() is not None:
            self.setVisible(True)
        return super().event(e)

    def _paint(self) -> None:
        c = theme.get().colors
        col = {"warning": c["warning"], "error": c["danger"], "info": c["accent2"]}.get(self._kind, c["warning"])
        self.icon_label.setPixmap(icons.pixmap("info" if self._kind == "info" else "alert", col, 18))

    def set_text(self, text: str, kind: str | None = None) -> None:
        if kind and kind != self._kind:
            self._kind = kind
            set_prop(self, "kind", kind)
            self._paint()
        self.text.setText(text)
        self._wanted = bool(text)
        set_shown(self, self._wanted)


class SegmentedControl(QFrame):
    """Переключатель режимов (вкладки-таблетки). Сигнал changed(key)."""
    changed = Signal(str)

    def __init__(self, options: Iterable[tuple[str, str]], current: str | None = None, parent: QWidget | None = None):
        super().__init__(parent)
        self.setObjectName("Seg")
        lay = QHBoxLayout(self)
        lay.setContentsMargins(3, 3, 3, 3)
        lay.setSpacing(2)
        self._group = QButtonGroup(self)
        self._group.setExclusive(True)
        self._buttons: dict[str, QPushButton] = {}
        for key, text in options:
            b = QPushButton(text)
            b.setProperty("kind", "seg")
            b.setCheckable(True)
            b.setCursor(Qt.CursorShape.PointingHandCursor)
            b.clicked.connect(lambda _=False, k=key: self._on_click(k))
            self._group.addButton(b)
            lay.addWidget(b)
            self._buttons[key] = b
        self._current = ""
        first = current or next(iter(self._buttons), "")
        if first:
            self.set_current(first)

    def _on_click(self, key: str) -> None:
        if key != self._current:
            self._current = key
            self.changed.emit(key)

    def set_current(self, key: str, emit: bool = False) -> None:
        if key not in self._buttons:
            return
        self._buttons[key].setChecked(True)
        if emit and key != self._current:
            self._current = key
            self.changed.emit(key)
        else:
            self._current = key

    def current(self) -> str:
        return self._current


class ClickableLabel(QLabel):
    clicked = Signal()

    def __init__(self, text: str = "", parent: QWidget | None = None):
        super().__init__(text, parent)
        self.setCursor(Qt.CursorShape.PointingHandCursor)

    def mouseReleaseEvent(self, e: QMouseEvent) -> None:
        if e.button() == Qt.MouseButton.LeftButton and self.rect().contains(e.position().toPoint()):
            self.clicked.emit()
        super().mouseReleaseEvent(e)


# ---------------------------------------------------------------- Page
class Page(QWidget):
    """Базовый класс страницы.

    Жизненный цикл: MainWindow вызывает on_show()/on_hide(). Данные обновляются лениво — только когда страница
    видна (mark_dirty() из обработчиков сигналов). Подклассы переопределяют refresh() и, при необходимости,
    activated()/deactivated() (подписка на датчики, таймеры).
    """

    #: True — MainWindow оборачивает страницу в область прокрутки; False — страница сама управляет прокруткой
    scrollable = True

    def __init__(self, ctx, parent: QWidget | None = None):
        super().__init__(parent)
        self.ctx = ctx
        self._shown = False
        self._entered = False
        self._dirty = True
        self._built = False

    # --- вызывается MainWindow ---
    def on_show(self) -> None:
        first = not self._entered
        self._shown = True
        if self._dirty:
            self._do_refresh()
        self.activated()
        if first:
            self._entered = True
            from ui import anim
            anim.cascade(self.entrance_targets(), start_delay=60)

    def entrance_targets(self) -> list[QWidget]:
        """Блоки, которые плавно появляются по очереди при первом открытии страницы (по умолчанию — верхний уровень layout)."""
        lay = self.layout()
        out: list[QWidget] = []
        if lay is not None:
            for i in range(lay.count()):
                w = lay.itemAt(i).widget()
                if w is not None:
                    out.append(w)
        return out

    def on_hide(self) -> None:
        self._shown = False
        self.deactivated()

    @property
    def is_shown(self) -> bool:
        return self._shown

    # --- для подклассов ---
    def mark_dirty(self) -> None:
        self._dirty = True
        if self._shown:
            self._do_refresh()

    def _do_refresh(self) -> None:
        self._dirty = False
        try:
            self.refresh()
        except Exception:
            import logging
            logging.getLogger("vibehub.ui").exception("Ошибка обновления страницы %s", type(self).__name__)

    def refresh(self) -> None:  # pragma: no cover - переопределяется
        pass

    def activated(self) -> None:
        pass

    def deactivated(self) -> None:
        pass

    def handle_action(self, action: str) -> None:
        """Внешняя команда странице (например, 'add_match' из быстрых действий Dashboard)."""

    def page_header(self, title: str, subtitle: str = "") -> tuple[QHBoxLayout, QVBoxLayout]:
        """Стандартный заголовок страницы. Возвращает (строка заголовка, колонка текста); справа можно добавлять кнопки."""
        row = QHBoxLayout()
        row.setSpacing(12)
        col = QVBoxLayout()
        col.setSpacing(2)
        col.addWidget(label(title, "H1"))
        if subtitle:
            col.addWidget(label(subtitle, "Muted"))
        row.addLayout(col, 1)
        return row, col
