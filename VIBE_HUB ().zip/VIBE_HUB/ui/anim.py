"""Анимации интерфейса. Все работают только при включённой настройке «Плавные анимации» (theme.animations)."""
from __future__ import annotations

from collections.abc import Iterable

from PySide6.QtCore import (QAbstractAnimation, QEasingCurve, QParallelAnimationGroup, QPauseAnimation, QPoint,
                            QPropertyAnimation, QRect, QSequentialAnimationGroup, QTimer)
from PySide6.QtWidgets import QGraphicsOpacityEffect, QProgressBar, QWidget

from ui import theme


def enabled() -> bool:
    try:
        return bool(theme.get().animations)
    except RuntimeError:         # тема ещё не инициализирована
        return False


def _drop_effect(widget: QWidget, effect: QGraphicsOpacityEffect) -> None:
    """Снимает эффект после анимации (постоянный эффект тормозит перерисовку) — но только свой:
    если за это время запущена новая анимация, её эффект не трогаем."""
    try:
        if widget.graphicsEffect() is effect:
            widget.setGraphicsEffect(None)
    except RuntimeError:                     # виджет уже удалён
        pass


def _stop(anim: QAbstractAnimation | None) -> None:
    if anim is None:
        return
    try:
        anim.stop()
    except RuntimeError:
        pass


def fade_in(widget: QWidget, ms: int = 240, *, delay: int = 0, slide: int = 0) -> None:
    """Плавное появление: прозрачность 0→1 и (по желанию) подъём снизу на `slide` пикселей."""
    if not enabled():
        return
    _stop(getattr(widget, "_fade_group", None))
    eff = QGraphicsOpacityEffect(widget)
    eff.setOpacity(0.0)
    widget.setGraphicsEffect(eff)

    par = QParallelAnimationGroup(widget)
    fade = QPropertyAnimation(eff, b"opacity", par)
    fade.setDuration(ms)
    fade.setStartValue(0.0)
    fade.setEndValue(1.0)
    fade.setEasingCurve(QEasingCurve.Type.OutCubic)
    par.addAnimation(fade)
    if slide:
        end = QPoint(widget.pos())
        move = QPropertyAnimation(widget, b"pos", par)
        move.setDuration(ms)
        move.setStartValue(QPoint(end.x(), end.y() + slide))
        move.setEndValue(end)
        move.setEasingCurve(QEasingCurve.Type.OutCubic)
        par.addAnimation(move)

    group: QAbstractAnimation = par
    if delay > 0:
        seq = QSequentialAnimationGroup(widget)
        seq.addAnimation(QPauseAnimation(delay))
        seq.addAnimation(par)
        group = seq
    group.finished.connect(lambda: QTimer.singleShot(0, lambda: _drop_effect(widget, eff)))
    widget._fade_group = group              # держим ссылку, иначе анимацию соберёт сборщик мусора
    group.start()


def cascade(widgets: Iterable[QWidget], *, step: int = 45, ms: int = 260, start_delay: int = 0, max_items: int = 12) -> None:
    """Появление группы виджетов по очереди (каждый следующий — на `step` мс позже)."""
    if not enabled():
        return
    shown = [w for w in widgets if w is not None and not w.isHidden()]
    for i, w in enumerate(shown[:max_items]):
        fade_in(w, ms, delay=start_delay + i * step)


def animate_geometry(widget: QWidget, target: QRect, ms: int = 180) -> None:
    """Плавно переносит виджет в новую геометрию; при выключенных анимациях — мгновенно."""
    prev: QPropertyAnimation | None = getattr(widget, "_geo_anim", None)
    if not enabled() or not widget.isVisible():
        _stop(prev)
        widget.setGeometry(target)
        return
    if prev is not None and prev.state() == QAbstractAnimation.State.Running and prev.endValue() == target:
        return                                # уже едем в нужное место
    if widget.geometry() == target:
        _stop(prev)
        return
    _stop(prev)
    anim = QPropertyAnimation(widget, b"geometry", widget)
    anim.setDuration(ms)
    anim.setStartValue(widget.geometry())
    anim.setEndValue(target)
    anim.setEasingCurve(QEasingCurve.Type.OutCubic)
    widget._geo_anim = anim
    anim.start()


def stop_geometry(widget: QWidget) -> None:
    _stop(getattr(widget, "_geo_anim", None))


def set_progress(bar: QProgressBar, value: int, ms: int = 420, *, start: int | None = None) -> None:
    """Плавно доводит индикатор до значения. `start` — откуда начать (например, прежнее значение
    пересозданной строки или 0 при первом появлении); без него — с текущего положения."""
    value = int(value)
    _stop(getattr(bar, "_val_anim", None))
    if start is not None:
        bar.setValue(int(start))
    if not enabled() or bar.value() == value:
        bar.setValue(value)
        return
    anim = QPropertyAnimation(bar, b"value", bar)
    anim.setDuration(ms)
    anim.setStartValue(bar.value())
    anim.setEndValue(value)
    anim.setEasingCurve(QEasingCurve.Type.OutCubic)
    bar._val_anim = anim
    anim.start()
