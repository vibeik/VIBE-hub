"""PC Monitor: показатели в реальном времени + история из SQLite. Чего нет — показывается как «нет данных»."""
from __future__ import annotations

import logging
from datetime import datetime, timedelta

from PySide6.QtWidgets import QComboBox, QGridLayout, QHBoxLayout, QProgressBar, QVBoxLayout, QWidget

from ui import anim
from ui.common.base import Banner, Card, Page, SegmentedControl, button, label
from ui.common.charts import ChartWidget
from ui.common.util import clear_layout, disconnect_quiet
from ui.dashboard.cards import PCMetricCard
from utils.format import fmt_bytes, fmt_pct, fmt_rate
from utils.i18n import _
from utils.timeutil import parse_iso

log = logging.getLogger("vibehub.pcmonitor")

INTERVALS = [(500, "0,5 с"), (1000, "1 с"), (2000, "2 с"), (5000, "5 с")]
RANGES = {"1h": 1, "6h": 6, "24h": 24}
MAX_HISTORY_POINTS = 1500


class MonitorPage(Page):
    def __init__(self, ctx, parent=None):
        super().__init__(ctx, parent)
        self.range = "live"
        self._live_ok: dict[str, bool] = {}
        self._disk_rows: dict[str, tuple] = {}
        root = QVBoxLayout(self)
        root.setContentsMargins(28, 22, 28, 28)
        root.setSpacing(16)

        head, _col = self.page_header("PC Monitor", _("Нагрузка, температуры и сеть вашего ПК"))
        self.range_seg = SegmentedControl([("live", _("Сейчас")), ("1h", _("1 час")), ("6h", _("6 часов")), ("24h", _("24 часа"))])
        self.range_seg.changed.connect(self._set_range)
        self.interval = QComboBox()
        for ms, text in INTERVALS:
            self.interval.addItem(_(text), ms)
        cur = int(ctx.settings.get("monitor_interval_ms") or 1000)
        self.interval.setCurrentIndex(max(0, self.interval.findData(cur)))
        self.interval.setToolTip(_("Частота опроса датчиков"))
        self.interval.currentIndexChanged.connect(lambda _i: ctx.settings.set("monitor_interval_ms", self.interval.currentData()))
        self.btn_pause = button(_("Пауза"), icon="pause", on_click=self._toggle_pause)
        head.addWidget(self.range_seg)
        head.addWidget(self.interval)
        head.addWidget(self.btn_pause)
        root.addLayout(head)

        self.note_cpu = Banner("", "warning")
        self.note_gpu = Banner("", "warning")
        root.addWidget(self.note_cpu)
        root.addWidget(self.note_gpu)

        grid = QGridLayout()
        grid.setSpacing(14)
        self.gauges = {}
        for i, key in enumerate(("cpu", "gpu", "ram", "cpu_temp", "gpu_temp", "disk")):
            card = PCMetricCard(ctx, key, clickable=False)
            card.setMinimumHeight(210)
            self.gauges[key] = card
            grid.addWidget(card, 0, i)
            grid.setColumnStretch(i, 1)
        root.addLayout(grid)

        # подробности
        self.details = Card(_("Подробности"), "info")
        self.detail_grid = QGridLayout()
        self.detail_grid.setHorizontalSpacing(24)
        self.detail_grid.setVerticalSpacing(6)
        self._detail_labels: dict[str, tuple] = {}
        for i, (key, title) in enumerate((("cpu", _("Процессор")), ("ram", _("Память")), ("gpu", _("Видеокарта")),
                                          ("net", _("Сеть")), ("disk_io", _("Диск (чтение / запись)")))):
            t, v = label(title, "Muted"), label("—", wrap=True)
            self.detail_grid.addWidget(t, i, 0)
            self.detail_grid.addWidget(v, i, 1)
            self._detail_labels[key] = (t, v)
        self.detail_grid.setColumnStretch(1, 1)
        self.details.body.addLayout(self.detail_grid)
        root.addWidget(self.details)

        # графики
        self.c_load = ChartWidget(min_height=210, date_axis=True, empty_text=_("Ожидание данных…"))
        self.c_temp = ChartWidget(min_height=210, date_axis=True, empty_text=_("Нет данных о температуре"))
        self.c_net = ChartWidget(min_height=210, date_axis=True, y_axis_width=78, empty_text=_("Ожидание данных…"))
        self.c_net.set_y_formatter(lambda v: fmt_rate(v))
        for title, ch, icon in ((_("Загрузка, %"), self.c_load, "activity"), (_("Температура, °C"), self.c_temp, "thermometer"),
                                (_("Сеть"), self.c_net, "network")):
            card = Card(title, icon)
            card.body.addWidget(ch, 1)
            root.addWidget(card)
        self.hist_note = label("", "Muted")
        root.addWidget(self.hist_note)

        # диски
        self.disks_card = Card(_("Диски"), "hard-drive")
        self.disks_lay = QVBoxLayout()
        self.disks_lay.setSpacing(10)
        self.disks_card.body.addLayout(self.disks_lay)
        root.addWidget(self.disks_card)
        root.addStretch(1)

    # ------------------------------------------------------------------ жизненный цикл
    def activated(self) -> None:
        self.ctx.monitor.snapshot.connect(self._on_snap)
        self._prepare_live()
        latest = self.ctx.monitor.latest
        if latest is not None:
            self._on_snap(latest)

    def deactivated(self) -> None:
        disconnect_quiet(self.ctx.monitor.snapshot, self._on_snap)

    def refresh(self) -> None:
        pass

    # ------------------------------------------------------------------ управление
    def _toggle_pause(self) -> None:
        m = self.ctx.monitor
        m.paused = not m.paused
        self.btn_pause.setText(_("Продолжить") if m.paused else _("Пауза"))

    def _set_range(self, key: str) -> None:
        self.range = key
        self.interval.setEnabled(key == "live")
        self.btn_pause.setEnabled(key == "live")
        if key == "live":
            self.hist_note.setVisible(False)
            self._prepare_live()
            if self.ctx.monitor.latest is not None:
                self._on_snap(self.ctx.monitor.latest)
        else:
            self._load_history(RANGES[key])

    # ------------------------------------------------------------------ живые данные
    def _prepare_live(self) -> None:
        if self.range != "live":
            return
        self.c_load.prepare_live([{"name": "CPU", "color": "accent"}, {"name": "GPU", "color": "accent2"},
                                  {"name": "RAM", "color": "success"}], (0, 100))
        self.c_temp.prepare_live([{"name": "CPU", "color": "warning"}, {"name": "GPU", "color": "danger"}], (20, 100))
        self.c_net.prepare_live([{"name": _("Загрузка"), "color": "accent2"}, {"name": _("Отдача"), "color": "accent"}], (0, 1024))
        self._live_ok = {"temp": True}

    def _on_snap(self, snap) -> None:
        for card in self.gauges.values():
            card.on_sensors(snap)
        self._update_details(snap)
        self._update_notes(snap)
        self._update_disks(snap)
        if self.range != "live":
            return
        hist = list(self.ctx.monitor.history)
        if len(hist) < 2:
            return
        xs = [h.ts for h in hist]
        self.c_load.update_live(xs, [[h.cpu for h in hist], [h.gpu for h in hist], [h.ram for h in hist]])
        cpu_t, gpu_t = [h.cpu_temp for h in hist], [h.gpu_temp for h in hist]
        has_t = any(v is not None for v in cpu_t + gpu_t)
        if has_t:
            if not self._live_ok.get("temp"):
                self.c_temp.prepare_live([{"name": "CPU", "color": "warning"}, {"name": "GPU", "color": "danger"}], (20, 100))
                self._live_ok["temp"] = True
            self.c_temp.update_live(xs, [cpu_t, gpu_t])
        elif self._live_ok.get("temp"):
            self.c_temp.show_empty(snap.cpu_temp_note or snap.gpu_note or _("Нет данных о температуре"))
            self._live_ok["temp"] = False
        down = [h.net_down_bps for h in hist]
        up = [h.net_up_bps for h in hist]
        peak = max([v for v in down + up if v is not None] or [1024.0])
        self.c_net.set_y_range(0, max(peak * 1.2, 1024.0))
        self.c_net.update_live(xs, [down, up])

    def _update_details(self, s) -> None:
        d = self._detail_labels
        cpu = []
        if s.cpu_freq_mhz:
            cpu.append(f"{s.cpu_freq_mhz / 1000:.2f} ГГц")
        if s.cpu_per_core:
            cpu.append(f"{len(s.cpu_per_core)} {_('потоков')}")
        d["cpu"][1].setText(" · ".join(cpu) or "—")
        d["ram"][1].setText(f"{fmt_bytes(s.ram_used)} / {fmt_bytes(s.ram_total)} ({fmt_pct(s.ram, 0)})" if s.ram_total else "—")
        gpu = []
        if s.gpu_name:
            gpu.append(s.gpu_name)
        if s.vram_used_mb is not None and s.vram_total_mb:
            gpu.append(f"VRAM {s.vram_used_mb / 1024:.1f} / {s.vram_total_mb / 1024:.1f} ГБ")
        d["gpu"][1].setText(" · ".join(gpu) or _("нет данных"))
        d["net"][1].setText(f"↓ {fmt_rate(s.net_down_bps)}   ↑ {fmt_rate(s.net_up_bps)}")
        d["disk_io"][1].setText(f"{fmt_rate(s.disk_read_bps)} / {fmt_rate(s.disk_write_bps)}")

    def _update_notes(self, s) -> None:
        self.note_cpu.set_text(f"{_('Температура CPU')}: {s.cpu_temp_note}" if s.cpu_temp is None and s.cpu_temp_note else "")
        self.note_gpu.set_text(f"GPU: {s.gpu_note}" if s.gpu is None and s.gpu_note else "")

    def _update_disks(self, s) -> None:
        mounts = tuple(d["mount"] for d in s.disks)
        if mounts != tuple(self._disk_rows):
            clear_layout(self.disks_lay)
            self._disk_rows = {}
            for d in s.disks:
                head = QHBoxLayout()
                name, info = label(d["mount"], "H3"), label("", "Muted")
                head.addWidget(name)
                head.addStretch(1)
                head.addWidget(info)
                bar = QProgressBar()
                bar.setRange(0, 100)
                bar.setTextVisible(False)
                w = QWidget()
                v = QVBoxLayout(w)
                v.setContentsMargins(0, 0, 0, 0)
                v.setSpacing(4)
                v.addLayout(head)
                v.addWidget(bar)
                self.disks_lay.addWidget(w)
                self._disk_rows[d["mount"]] = (info, bar)
            self.disks_card.setVisible(bool(s.disks))
        for d in s.disks:
            info, bar = self._disk_rows[d["mount"]]
            info.setText(f"{fmt_bytes(d['used'])} / {fmt_bytes(d['total'])} · {_('свободно')} {fmt_bytes(d['free'])} ({d['percent']:.0f}%)")
            anim.set_progress(bar, int(d["percent"]))

    # ------------------------------------------------------------------ история
    def _load_history(self, hours: int) -> None:
        rows = self.ctx.repos.pc.since(datetime.now() - timedelta(hours=hours))
        if not self.ctx.settings.get("monitor_history") and not rows:
            for ch in (self.c_load, self.c_temp, self.c_net):
                ch.show_empty(_("Запись истории выключена в настройках"))
            self.hist_note.setText(_("Включите «Записывать историю» в Настройках → Мониторинг."))
            self.hist_note.setVisible(True)
            return
        if len(rows) < 2:
            for ch in (self.c_load, self.c_temp, self.c_net):
                ch.show_empty(_("Истории за этот период пока нет"))
            self.hist_note.setText(_("История записывается раз в 10 секунд, пока приложение запущено."))
            self.hist_note.setVisible(True)
            return
        step = max(1, len(rows) // MAX_HISTORY_POINTS)
        rows = rows[::step]
        xs = [parse_iso(r["ts"]).timestamp() for r in rows]

        def col(k):
            return [r[k] for r in rows]
        self.c_load.plot_lines([{"name": "CPU", "x": xs, "y": col("cpu"), "color": "accent", "fmt": "{:.0f}%"},
                                {"name": "GPU", "x": xs, "y": col("gpu"), "color": "accent2", "fmt": "{:.0f}%"},
                                {"name": "RAM", "x": xs, "y": col("ram"), "color": "success", "fmt": "{:.0f}%"}], y_range=(0, 100))
        self.c_temp.plot_lines([{"name": "CPU", "x": xs, "y": col("cpu_temp"), "color": "warning", "fmt": "{:.0f}°C"},
                                {"name": "GPU", "x": xs, "y": col("gpu_temp"), "color": "danger", "fmt": "{:.0f}°C"}])
        self.c_net.plot_lines([{"name": _("Загрузка"), "x": xs, "y": col("net_down"), "color": "accent2", "fmt": fmt_rate},
                               {"name": _("Отдача"), "x": xs, "y": col("net_up"), "color": "accent", "fmt": fmt_rate}])
        self.hist_note.setText(f"{_('Точек на графике')}: {len(rows)}")
        self.hist_note.setVisible(True)
