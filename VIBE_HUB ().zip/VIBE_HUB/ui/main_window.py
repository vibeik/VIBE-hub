"""Главное окно: верхняя панель, боковая навигация, страницы (создаются лениво), toast-уведомления."""
from __future__ import annotations

import importlib
import logging
import os
from datetime import datetime

from PySide6.QtCore import QByteArray, QEvent, QPoint, QSize, Qt, QTimer, Signal
from PySide6.QtWidgets import (QApplication, QFrame, QHBoxLayout, QLabel, QMainWindow, QPushButton, QScrollArea,
                               QStackedWidget, QVBoxLayout, QWidget)

from config.settings import APP_NAME, APP_VERSION
from ui import anim, icons, theme
from ui.common.base import EmptyState, IconButton, Page, button, label
from ui.common.images import AsyncImage
from ui.common.toast import ToastHost
from ui.common.util import fmt_dt
from utils import i18n
from utils.i18n import _

log = logging.getLogger("vibehub.window")

# id -> (заголовок, иконка, модуль, класс)
PAGES: list[tuple[str, str, str, str, str]] = [
    ("dashboard", "Dashboard", "dashboard", "ui.dashboard.page", "DashboardPage"),
    ("cs2_tracker", "CS2 Tracker", "crosshair", "ui.cs2_tracker.page", "TrackerPage"),
    ("pc_monitor", "PC Monitor", "cpu", "ui.pc_monitor.page", "MonitorPage"),
    ("steam", "Steam", "gamepad", "ui.steam.page", "SteamPage"),
    ("faceit", "FACEIT", "trophy", "ui.faceit.page", "FaceitPage"),
    ("spotify", "Spotify", "headphones", "ui.spotify.page", "SpotifyPage"),
    ("goals", "Цели", "target", "ui.goals.page", "GoalsPage"),
    ("music", "Music", "music", "ui.music.page", "MusicPage"),
    ("accounts", "Подключённые аккаунты", "link", "ui.accounts.page", "AccountsPage"),
    ("settings", "Настройки", "settings", "ui.settings.page", "SettingsPage"),
]
PAGE_IDS = [p[0] for p in PAGES]
ACTION_PAGE = {"add_match": "cs2_tracker", "create_goal": "goals"}

_WEEK = {"ru": ["пн", "вт", "ср", "чт", "пт", "сб", "вс"], "en": ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"]}
_MONTH = {"ru": ["января", "февраля", "марта", "апреля", "мая", "июня", "июля", "августа", "сентября", "октября",
                 "ноября", "декабря"],
          "en": ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"]}


def fmt_clock(now: datetime, lang: str = "ru") -> str:
    lang = lang if lang in _WEEK else "ru"
    return f"{_WEEK[lang][now.weekday()]}, {now.day} {_MONTH[lang][now.month - 1]} · {now:%H:%M}"


def greeting_for(hour: int) -> str:
    if 5 <= hour < 12:
        return _("Доброе утро")
    if 12 <= hour < 18:
        return _("Добрый день")
    if 18 <= hour < 23:
        return _("Добрый вечер")
    return _("Доброй ночи")


class ClickableAvatar(AsyncImage):
    clicked = Signal()

    def mouseReleaseEvent(self, e) -> None:
        if e.button() == Qt.MouseButton.LeftButton:
            self.clicked.emit()
        super().mouseReleaseEvent(e)


class MainWindow(QMainWindow):
    def __init__(self, ctx):
        super().__init__()
        self.ctx = ctx
        self.pages: dict[str, Page] = {}
        self._containers: dict[str, QWidget] = {}
        self.current_id: str | None = None
        self._nav: dict[str, QPushButton] = {}
        self._theme_pending = False
        self._title_styled = False
        if theme.get().glass_mode != "off":
            # прозрачная подложка нужна до создания окна; сам эффект включается в showEvent
            self.setAttribute(Qt.WidgetAttribute.WA_TranslucentBackground, True)
        self.setWindowTitle(APP_NAME)
        self.setWindowIcon(icons.app_icon(ctx.settings.get("logo_style")))
        self.setMinimumSize(1100, 680)

        root = QWidget()
        root.setObjectName("Root")
        self.setCentralWidget(root)
        outer = QVBoxLayout(root)
        outer.setContentsMargins(0, 0, 0, 0)
        outer.setSpacing(0)
        outer.addWidget(self._build_topbar())
        body = QHBoxLayout()
        body.setSpacing(0)
        body.addWidget(self._build_sidebar())
        self.stack = QStackedWidget()
        body.addWidget(self.stack, 1)
        outer.addLayout(body, 1)
        self.toasts = ToastHost(root)

        self._restore_geometry()
        self._connect_signals()
        self._tick_clock()
        self._refresh_avatar()
        self._update_badge()
        self._clock = QTimer(self)
        self._clock.setInterval(1000)
        self._clock.timeout.connect(self._tick_clock)
        self._clock.start()
        theme.get().changed.connect(self._repaint_icons)
        self._repaint_icons()

    # ------------------------------------------------------------------ построение
    def _build_topbar(self) -> QFrame:
        bar = QFrame()
        bar.setObjectName("Topbar")
        bar.setFixedHeight(68)
        lay = QHBoxLayout(bar)
        lay.setContentsMargins(20, 8, 20, 8)
        lay.setSpacing(14)
        self.logo_lbl = QLabel()
        self.logo_lbl.setPixmap(icons.app_logo(38, self.ctx.settings.get("logo_style")))
        self.logo_lbl.setFixedSize(38, 38)
        lay.addWidget(self.logo_lbl)
        lay.addWidget(label(APP_NAME, "H2"))
        lay.addSpacing(18)
        col = QVBoxLayout()
        col.setSpacing(0)
        self.greeting = label("", "H3")
        self.clock = label("", "Muted")
        col.addWidget(self.greeting)
        col.addWidget(self.clock)
        lay.addLayout(col)
        lay.addStretch(1)

        self.bell = IconButton("bell", _("Уведомления"), size=20, role="text", on_click=self._show_notifications)
        self.badge = QLabel("0", self.bell)
        self.badge.setObjectName("Badge")
        self.badge.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.badge.setFixedHeight(16)
        self.badge.move(20, 2)
        self.badge.hide()
        self.btn_settings = IconButton("settings", _("Настройки"), size=20, role="text", on_click=lambda: self.show_page("settings"))
        self.avatar = ClickableAvatar(36)
        self.avatar.setCursor(Qt.CursorShape.PointingHandCursor)
        self.avatar.setToolTip(_("Подключённые аккаунты"))
        self.avatar.clicked.connect(lambda: self.show_page("accounts"))
        for w in (self.bell, self.btn_settings, self.avatar):
            lay.addWidget(w)
        return bar

    def _build_sidebar(self) -> QFrame:
        side = QFrame()
        side.setObjectName("Sidebar")
        side.setFixedWidth(232)
        lay = QVBoxLayout(side)
        lay.setContentsMargins(12, 14, 12, 12)
        lay.setSpacing(4)
        for pid, title, _icon_name, _m, _c in PAGES:
            if pid == "settings":
                continue
            lay.addWidget(self._nav_button(pid, title))
        lay.addStretch(1)
        lay.addWidget(self._nav_button("settings", "Настройки"))
        ver = label(f"v{APP_VERSION}", "Muted", align=Qt.AlignmentFlag.AlignCenter)
        lay.addWidget(ver)
        return side

    def _nav_button(self, pid: str, title: str) -> QPushButton:
        b = QPushButton(_(title))
        b.setProperty("nav", True)
        b.setCheckable(True)
        b.setCursor(Qt.CursorShape.PointingHandCursor)
        b.setIconSize(QSize(20, 20))
        b.clicked.connect(lambda _c=False, p=pid: self.show_page(p))
        self._nav[pid] = b
        return b

    def _repaint_icons(self) -> None:
        c = theme.get().colors
        for pid, _t, icon_name, _m, _c in PAGES:
            b = self._nav.get(pid)
            if b is not None:
                b.setIcon(icons.icon(icon_name, c["muted"], 20, on_color=c["text"]))

    # ------------------------------------------------------------------ сигналы
    def _connect_signals(self) -> None:
        ctx, b = self.ctx, self.ctx.bus
        b.navigate.connect(self.show_page)
        b.request_action.connect(self._on_action)
        b.notified.connect(lambda kind, title, text: self.toasts.show_toast(kind, title, text))
        b.settings_changed.connect(self._on_setting)
        b.accounts_changed.connect(self._refresh_avatar)
        ctx.notifications.changed.connect(self._update_badge)
        for name, ctl in (("FACEIT", ctx.faceit), ("Steam", ctx.steam), ("Spotify", ctx.spotify)):
            ctl.error.connect(lambda msg, n=name: ctx.notify("error", n, msg))
        ctx.player.error.connect(lambda msg: ctx.notify("warning", "Music", msg))

    def _on_setting(self, key: str, _value) -> None:
        if key in ("theme", "accent", "accent2", "animations", "glass_transparency"):
            if not self._theme_pending:
                self._theme_pending = True
                QTimer.singleShot(0, self._apply_theme)
        elif key == "logo_style":
            self._apply_logo()
        elif key == "user_name":
            self._tick_clock(force=True)

    def _apply_theme(self) -> None:
        self._theme_pending = False
        tm = theme.get()
        tm.reload()
        app = QApplication.instance()
        if app is not None:
            tm.apply(app)
        self._style_titlebar()

    def _apply_logo(self) -> None:
        style = self.ctx.settings.get("logo_style")
        self.setWindowIcon(icons.app_icon(style))
        self.logo_lbl.setPixmap(icons.app_logo(38, style))

    def _style_titlebar(self) -> None:
        """Заголовок окна: под цвет темы; при стекле — системный, чтобы он просвечивал вместе с остальным окном."""
        if os.name != "nt" or not self._title_styled:
            return
        from utils import winstyle
        tm = theme.get()
        glass = tm.glass_mode != "off"
        winstyle.apply_dark_titlebar(int(self.winId()), None if glass else tm.colors["bg"], None if glass else tm.colors["text"])

    def _enable_glass(self) -> None:
        tm = theme.get()
        if tm.glass_mode == "off":
            return
        from utils import winstyle
        if not winstyle.apply_glass(int(self.winId()), tm.glass_mode):
            log.warning("Эффект стекла не включился — используется обычный фон")
            tm.glass_mode = "off"
            self._apply_theme()

    # ------------------------------------------------------------------ верхняя панель
    def _display_name(self) -> str:
        name = (self.ctx.settings.get("user_name") or "").strip()
        if name:
            return name
        for service in ("faceit", "steam"):
            acc = self.ctx.repos.accounts.get(service)
            if acc and acc.get("username"):
                return acc["username"]
        return ""

    def _tick_clock(self, force: bool = False) -> None:
        now = datetime.now()
        text = fmt_clock(now, i18n.current())
        if force or text != self.clock.text():
            self.clock.setText(text)
            name = self._display_name()
            self.greeting.setText(f"{greeting_for(now.hour)}, {name}" if name else greeting_for(now.hour))

    def _refresh_avatar(self) -> None:
        url = None
        for service in ("faceit", "steam"):
            acc = self.ctx.repos.accounts.get(service)
            if acc and acc.get("avatar_url"):
                url = acc["avatar_url"]
                break
        self.avatar.set_url(url)
        self._tick_clock(force=True)

    def _update_badge(self) -> None:
        n = self.ctx.notifications.unread
        self.badge.setText(str(n) if n < 100 else "99+")
        self.badge.adjustSize()
        self.badge.setMinimumWidth(16)
        self.badge.setVisible(n > 0)

    def _show_notifications(self) -> None:
        nc = self.ctx.notifications
        pop = QFrame(self, Qt.WindowType.Popup)
        pop.setObjectName("Popup")
        pop.setFixedWidth(380)
        lay = QVBoxLayout(pop)
        lay.setContentsMargins(14, 12, 14, 12)
        lay.setSpacing(8)
        head = QHBoxLayout()
        head.addWidget(label(_("Уведомления"), "H3"), 1)
        head.addWidget(button(_("Очистить"), "ghost", None, lambda: (nc.clear(), pop.close())))
        lay.addLayout(head)
        if not nc.items:
            lay.addWidget(EmptyState(_("Уведомлений нет"), _("Здесь появятся подключения аккаунтов, выполненные цели и ошибки."),
                                     icon="bell", compact=True))
        else:
            scroll = QScrollArea()
            scroll.setWidgetResizable(True)
            scroll.setFixedHeight(min(380, 78 * len(nc.items[:8]) + 8))
            host = QWidget()
            v = QVBoxLayout(host)
            v.setContentsMargins(0, 0, 0, 0)
            v.setSpacing(8)
            icon_for = {"success": "check-circle", "warning": "alert", "error": "alert", "info": "info"}
            col_for = {"success": "success", "warning": "warning", "error": "danger", "info": "accent2"}
            c = theme.get().colors
            for it in nc.items[:30]:
                row = QHBoxLayout()
                row.setSpacing(10)
                ic = QLabel()
                ic.setPixmap(icons.pixmap(icon_for.get(it["kind"], "info"), c[col_for.get(it["kind"], "accent2")], 18))
                ic.setFixedSize(18, 18)
                txt = QVBoxLayout()
                txt.setSpacing(1)
                txt.addWidget(label(it["title"], "H3", wrap=True))
                if it["text"]:
                    txt.addWidget(label(it["text"], "Muted", wrap=True))
                txt.addWidget(label(fmt_dt(it["ts"].strftime("%Y-%m-%d %H:%M:%S")), "Muted"))
                row.addWidget(ic, 0, Qt.AlignmentFlag.AlignTop)
                row.addLayout(txt, 1)
                w = QWidget()
                w.setLayout(row)
                v.addWidget(w)
            v.addStretch(1)
            scroll.setWidget(host)
            lay.addWidget(scroll)
        pop.adjustSize()
        pop.move(self.bell.mapToGlobal(QPoint(self.bell.width() - pop.width(), self.bell.height() + 8)))
        pop.show()
        nc.mark_all_read()
        pop.setAttribute(Qt.WidgetAttribute.WA_DeleteOnClose, True)

    # ------------------------------------------------------------------ страницы
    def _create_page(self, pid: str) -> QWidget:
        _pid, title, _icon, mod, cls = next(p for p in PAGES if p[0] == pid)
        try:
            page: Page = getattr(importlib.import_module(mod), cls)(self.ctx)
        except Exception:
            log.exception("Не удалось создать страницу %s", pid)
            fail = EmptyState(_("Не удалось открыть раздел"),
                              _("Раздел временно недоступен. Подробности записаны в журнал (Настройки → Открыть папку журналов)."),
                              icon="alert")
            holder = QWidget()
            lay = QVBoxLayout(holder)
            lay.addWidget(fail)
            self.stack.addWidget(holder)
            self._containers[pid] = holder
            return holder
        self.pages[pid] = page
        if page.scrollable:
            sc = QScrollArea()
            sc.setWidgetResizable(True)
            sc.setFrameShape(QFrame.Shape.NoFrame)
            sc.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)
            sc.setWidget(page)
            container: QWidget = sc
        else:
            container = page
        self.stack.addWidget(container)
        self._containers[pid] = container
        return container

    def show_page(self, pid: str) -> None:
        if pid not in PAGE_IDS:
            log.warning("Неизвестная страница: %s", pid)
            return
        if pid == self.current_id:
            return
        old = self.pages.get(self.current_id) if self.current_id else None
        if old is not None:
            try:
                old.on_hide()
            except Exception:
                log.exception("Ошибка при скрытии страницы")
        holder = self._containers.get(pid) or self._create_page(pid)
        self.stack.setCurrentWidget(holder)
        self.current_id = pid
        for key, b in self._nav.items():
            b.setChecked(key == pid)
        new = self.pages.get(pid)
        if new is not None:
            try:
                new.on_show()
            except Exception:
                log.exception("Ошибка при показе страницы %s", pid)
        anim.fade_in(holder, 300, slide=18)
        self.ctx.settings.set("last_page", pid, notify=False)

    def _on_action(self, action: str) -> None:
        pid = ACTION_PAGE.get(action)
        if pid is None:
            return
        self.show_page(pid)
        page = self.pages.get(pid)
        if page is not None:
            QTimer.singleShot(0, lambda: page.handle_action(action))

    # ------------------------------------------------------------------ окно
    def _restore_geometry(self) -> None:
        geo = self.ctx.settings.get("window_geometry")
        ok = False
        if isinstance(geo, str) and geo:
            try:
                ok = self.restoreGeometry(QByteArray.fromBase64(geo.encode("ascii")))
            except Exception:
                ok = False
        if not ok:
            self.resize(1366, 820)

    def changeEvent(self, e) -> None:
        if e.type() in (QEvent.Type.ActivationChange, QEvent.Type.WindowStateChange):
            # неактивное, но видимое окно работает как обычно; реже опрашиваем только свёрнутое
            minimized = self.isMinimized()
            self.ctx.minimized = minimized
            self.ctx.monitor.background = minimized
        super().changeEvent(e)

    def resizeEvent(self, e) -> None:
        super().resizeEvent(e)
        toasts = getattr(self, "toasts", None)
        if toasts is not None:
            toasts.reposition()

    def showEvent(self, e) -> None:
        super().showEvent(e)
        if not self._title_styled and os.name == "nt":
            self._title_styled = True
            try:
                self._enable_glass()
                self._style_titlebar()
            except Exception:
                log.debug("Не удалось оформить заголовок окна", exc_info=True)

    def closeEvent(self, e) -> None:
        try:
            self.ctx.settings.set("window_geometry", bytes(self.saveGeometry().toBase64()).decode("ascii"), notify=False)
            if self.current_id:
                self.ctx.settings.set("last_page", self.current_id, notify=False)
        except Exception:
            log.exception("Не удалось сохранить положение окна")
        super().closeEvent(e)

    def open_initial_page(self) -> None:
        pid = self.ctx.settings.get("last_page")
        self.show_page(pid if pid in PAGE_IDS else "dashboard")

