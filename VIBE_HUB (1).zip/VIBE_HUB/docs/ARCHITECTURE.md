# VIBE HUB — архитектура

## 1. Слои

```
ui/            окна и виджеты (PySide6)                       ← знает про всё ниже
modules/       логика приложения: сервисы без Qt + контроллеры, AppContext, шина событий
api/           HTTP-клиенты Steam / FACEIT / Spotify, OAuth-сервер на 127.0.0.1
database/      SQLite: подключение, миграции, бэкап, репозитории
config/, utils/  настройки, пути, логи, секреты, i18n, форматирование
```

Зависимости идут сверху вниз: `ui → modules → api / database → config / utils`. Нижние слои не импортируют `ui`.
Бизнес-логика (`*_service.py`, `stats`, `goals`, `goal_service`, `sensors`, `playqueue`, `music_scan`, `dashboard_data`) не использует Qt —
поэтому покрыта тестами без графической среды. Qt появляется только в «клеевых» классах: контроллеры, `MonitorService`,
`MusicPlayer`, `NotificationCenter`, `workers`.

## 2. Запуск (`main.py`)

1. разбор аргументов (`--minimized`, `--debug`, `--selftest`, `--cleanup [--delete-data]`). `--cleanup` обрабатывается сразу, до Qt, базы и журнала
   (`modules/cleanup.py`: автозапуск → ключи в Credential Manager → кэш или вся папка данных; папка данных удаляется только если опознана как своя);
2. логирование с маскированием секретов (`utils/logger.py`), `QApplication`;
3. **проверка единственного экземпляра** (`utils/single_instance.py`: `QLockFile` + локальный сокет) — до открытия базы;
4. `Settings` (JSON) → `Database.open_with_recovery` (при повреждении — переименование и восстановление из автобэкапа) → авто-копия за сутки;
5. язык (`utils/i18n`) → тема (`ui/theme`) → `AppContext` → `MainWindow`;
6. флаг `clean_shutdown`: ставится в `False` при старте и в `True` при штатном выходе; если при запуске он `False` — показывается уведомление о некорректном завершении;
7. `ctx.start()` запускает фоновые задачи: монитор ПК, опрос FACEIT / Steam / Spotify, синхронизацию целей.

## 3. AppContext и шина событий

`modules/context.py::AppContext` создаётся один раз и передаётся страницам. Содержит: `settings`, `db`, `repos`, `store` (секреты),
`bus`, `notifications`, `monitor`, контроллеры `faceit` / `steam` / `spotify`, `player`, `theme`. Методы `notify(...)`, `log_activity(...)`, `sync_goals()`.

`modules/events.py::Bus` — сигналы Qt для слабой связности: `matches_changed`, `goals_changed`, `activity_changed`, `accounts_changed`,
`settings_changed(key, value)`, `navigate(page_id)`, `request_action(action)`, `notified(kind, title, text)`, `sensors`, `theme_changed`.
Страница подписывается на нужные сигналы и **лениво** обновляется: `Page.mark_dirty()` обновляет её сразу, если она на экране,
иначе — при следующем показе.

## 4. Интеграции

Для каждого сервиса три слоя: клиент (`api/*_api.py`) → сервис без Qt (`modules/*_service.py`) → контроллер (`modules/controllers.py`).

| Слой | Ответственность |
|---|---|
| `api/http.py` | только HTTPS, таймауты, повторы с задержкой, лимит частоты, безопасные тексты ошибок (без секретов) |
| `*_service.py` | состояние подключения, обновление данных, запись в БД, ключи в `SecretStore` |
| контроллер | таймеры опроса (только когда окно активно), фоновые задачи через `workers.run_async`, сигналы `updated` / `busy_changed` / `error` |

* **Steam** — OpenID 2.0 через одноразовый сервер `127.0.0.1:8889`; подлинность ответа проверяется обратным запросом к Steam. Web API — по ключу пользователя.
* **FACEIT** — Data API v4, ник + ключ пользователя. ELO по матчам API не отдаёт — история ELO накапливается из снимков (`faceit_snapshots` в БД).
* **Spotify** — Authorization Code + PKCE, `127.0.0.1:8888/callback`, `state` проверяется; Premium-ограничения превращаются в понятные сообщения.
* **Секреты** — `utils/secrets.py::SecretStore` поверх `keyring` (Windows Credential Manager). Если хранилище недоступно, ключ живёт только в памяти, и интерфейс об этом говорит.

## 5. База данных

SQLite, одно соединение под `RLock`, WAL. Миграции — `PRAGMA user_version` + список `MIGRATIONS` в `database/db.py` (применяются транзакционно;
база более новой версии не открывается). Таблицы: `matches`, `goals`, `goal_history`, `activity`, `accounts`, `faceit_snapshots`, `steam_games`,
`pc_history`, `music_folders`, `tracks`, `playlists`, `playlist_tracks`, `cache`. Репозитории (`database/repos.py`) — тонкий слой без Qt; время хранится как локальная ISO-строка.
Резервные копии: `backup_to`, `auto_backup` (раз в сутки, хранятся 7), `validate_backup` (integrity_check + проверка схемы), `restore_from` (со страховочной копией текущей базы).

## 6. Потоки

Всё, что ходит в сеть, читает диск или считает долго, выполняется в `QThreadPool` (`modules/workers.py::run_async(fn, ok, err, owner=...)`).
Результат доставляется в GUI-поток; если `owner` (страница) к этому моменту удалён, результат отбрасывается.
Датчики ПК опрашиваются отдельным потоком (`MonitorService`). Частота считается в `modules/polling.py::poll_interval_ms`: часто (1–2 с) только пока видна страница с живыми показаниями
(Dashboard и PC Monitor вызывают `monitor.watch()` в `activated()` и `unwatch()` в `deactivated()`), иначе раз в 5 с. Дорогие источники внутри `SensorReader` (`nvidia-smi`, PowerShell, диски) ограничены по времени
через `sensors.Throttle` — чем дольше вызов, тем реже повтор.

**Диагностика задержек.** `ui/perf_watch.py::LoopWatchdog` — таймер раз в 50 мс; его опоздание = время, когда цикл событий был занят. Накопление и отчёт — `utils/perf.py` (без Qt, покрыто тестами);
хранится в `ctx.perf`. `MainWindow` помечает контекст («page:…», «switch:…», «theme-apply») и записывает время создания/показа страниц; отчёт копируется из Настроек.

## 7. Интерфейс

* `ui/main_window.py` — верхняя панель, боковая навигация, `QStackedWidget`. **Страницы создаются лениво** при первом открытии; если страница
  не создаётся, показывается заглушка, а остальное приложение работает.
* `ui/common/` — `Card`, `EmptyState`, `Banner`, `Chip`, `StatTile`, `SegmentedControl`, `Page`; `charts.py` (обёртка над PyQtGraph, `RingGauge`, `Sparkline`),
  `tables.py`, `dialogs.py`, `toast.py`, `images.py` (асинхронные картинки с дисковым кэшем).
* `ui/theme.py` — палитры (violet / blue / midnight), акцентные цвета, QSS из шаблона; смена темы применяется без перезапуска.
* `ui/dashboard/` — `layout_engine.py` (чистая логика сетки 12 колонок: перемещение, изменение размера, вытеснение, «гравитация», сериализация;
  покрыта тестами), `grid_canvas.py` (холст с перетаскиванием), `cards.py` (карточки и реестр виджетов), `page.py`.
  Раскладка хранится в настройке `dashboard_layout`.
* Пустые состояния вместо выдуманных данных: если данных нет, карточка говорит, что нужно сделать, чтобы они появились.
* `ui/palettes.py` — палитры тем и математика цвета (контраст, смешивание), `ui/qss.py` — QSS из шаблона; оба без Qt и покрыты тестами.
  `ui/theme.py` — `ThemeManager` (цвета, режим стекла) и применение QSS к приложению.
* **Стекло**: `utils/winstyle.py` (DWM: `DWMWA_SYSTEMBACKDROP_TYPE` для Acrylic/Mica, `DwmExtendFrameIntoClientArea`, скруглённые углы). Режим выбирается при запуске
  (`effective_glass_mode` по номеру сборки Windows); при включённом стекле главное окно получает `WA_TranslucentBackground`, фон `#Root` становится полупрозрачным
  (альфа 0.30–0.90), диалоги и всплывающие окна остаются непрозрачными. Если Windows не приняла настройку, окно переключается на обычный фон.
* Фоновая работа: контроллеры опрашивают сервисы всегда (`ctx.minimized` лишь замедляет Spotify и датчики), закрытие окна завершает приложение.
* `ui/anim.py` — все анимации в одном месте: `fade_in` (прозрачность + подъём), `cascade`, `animate_geometry`, `set_progress`.
  Каждая функция сначала проверяет настройку «Плавные анимации» (`theme.get().animations`) и при выключенной ничего не делает.
  `QGraphicsOpacityEffect` живёт только на время анимации (постоянный эффект замедляет перерисовку).
* **Виджеты без родителя.** `show()` / `setVisible(True)` для виджета без родителя превращает его в отдельное окно — отсюда «мигающие окна»
  при переходах между разделами. Правило: сначала `addWidget`, потом `setVisible`; для условной видимости — `ui.common.util.set_shown`.
  Страховка — `ui/common/guard.py::StrayWindowGuard` (фильтр событий приложения): скрывает такое окно и один раз пишет в журнал имя класса.
* Логотип — `utils/logo.py` (SVG-строка, варианты `violet` / `yellow`, настройка `logo_style`); `icons.app_logo()` и `icons.app_icon()` рисуют его из того же SVG.
  Значки сервисов — `icons.service_logo()`: `%APPDATA%\VibeHub\logos\<сервис>.png|svg|jpg` → `assets/images/logos` → монограмма.

## 8. Локализация

`utils/i18n.py::_()` — ключ это русская строка; для `en` берётся `assets/lang/en.json`, нет перевода — показывается оригинал.
`tools/collect_strings.py` собирает строки из исходников, `tests/test_i18n_coverage.py` падает, если у какой-то нет перевода.
Записи, сохранённые в БД (журнал активности), не переводятся.

## 9. Тесты и проверки

`python -m pytest` — API на подставных ответах, БД и миграции, статистика, цели, очередь плеера, разбор `nvidia-smi`, форматирование,
сетка Dashboard, покрытие перевода. GUI-тестов нет; `python main.py --selftest` — быстрая проверка, что окно и все страницы создаются.

## 10. Как добавить

* **Новая страница**: класс-наследник `Page` в `ui/<имя>/page.py` + строка в `PAGES` в `ui/main_window.py`.
* **Новая карточка Dashboard**: класс-наследник `DashCard` + запись в `cards.registry()` (id, заголовок, геометрия, минимальный размер).
* **Новый сервис**: клиент в `api/`, сервис без Qt в `modules/`, контроллер в `controllers.py`, поле в `AppContext`, карточка на странице аккаунтов.
* **Новая миграция БД**: добавить скрипт в конец списка `MIGRATIONS` и поднять `SCHEMA_VERSION`; написать тест на миграцию с предыдущей версии.
