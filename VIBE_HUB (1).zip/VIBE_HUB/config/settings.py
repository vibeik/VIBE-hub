"""Настройки приложения и пути к данным.

Секреты (API-ключи, токены) здесь НЕ хранятся — только в Windows Credential Manager
(см. utils/secrets.py).
"""
from __future__ import annotations

import copy
import json
import logging
import os
import sys
import threading
from pathlib import Path
from typing import Any, Callable

APP_NAME = "VIBE HUB"
APP_ID = "VibeHub"
APP_VERSION = "1.4"

log = logging.getLogger("vibehub.settings")


def app_root() -> Path:
    """Папка с ресурсами: работает из исходников и из PyInstaller-сборки."""
    if getattr(sys, "frozen", False):
        return Path(getattr(sys, "_MEIPASS", Path(sys.executable).parent))
    return Path(__file__).resolve().parent.parent


def data_dir_path() -> Path:
    """Где лежат пользовательские данные — без создания папки (нужно для удаления и проверок)."""
    override = os.environ.get("VIBEHUB_DATA_DIR")
    if override:
        return Path(override)
    if os.name == "nt":
        return Path(os.environ.get("APPDATA", str(Path.home() / "AppData" / "Roaming"))) / APP_ID
    return Path.home() / ".local" / "share" / APP_ID


def data_dir() -> Path:
    """Папка пользовательских данных (БД, логи, бэкапы, кэш)."""
    base = data_dir_path()
    base.mkdir(parents=True, exist_ok=True)
    return base


def logos_dir() -> Path:
    """Сюда пользователь кладёт свои логотипы сервисов: steam.png / faceit.svg / spotify.png …"""
    p = data_dir() / "logos"
    p.mkdir(parents=True, exist_ok=True)
    return p


def db_path() -> Path:
    return data_dir() / "vibehub.db"


def log_dir() -> Path:
    p = data_dir() / "logs"
    p.mkdir(parents=True, exist_ok=True)
    return p


def backup_dir() -> Path:
    p = data_dir() / "backups"
    p.mkdir(parents=True, exist_ok=True)
    return p


def cache_dir(sub: str = "") -> Path:
    p = data_dir() / "cache" / sub if sub else data_dir() / "cache"
    p.mkdir(parents=True, exist_ok=True)
    return p


DEFAULTS: dict[str, Any] = {
    "language": "ru",
    "theme": "violet",
    "accent": "#8B5CF6",
    "accent2": "#38BDF8",
    "animations": True,
    "logo_style": "violet",
    "glass": "acrylic",             # эффект стекла Windows 11: "acrylic" | "mica" | "off" (применяется при запуске)
    "glass_transparency": 30,       # насколько фон окна просвечивает в режиме стекла, % (10–70)
    "autostart": False,
    "monitor_interval_ms": 1000,
    "monitor_history": True,
    "user_name": "",
    "dashboard_layout": None,
    "dashboard_source": "all",
    "faceit_nickname": "",
    "spotify_client_id": "",
    "spotify_port": 8888,
    "steam_port": 8889,
    "window_geometry": None,
    **{
        "last_page": "dashboard",
        "music_volume": 70,
        "music_shuffle": False,
        "music_repeat": "off",
        "clean_shutdown": True,
        "sidebar_collapsed": False,
        "steam_poll_min": 5,
        "faceit_poll_min": 10,
    },
}


class Settings:
    """JSON-настройки с атомарной записью и подписчиками на изменения."""

    def __init__(self, path: Path | str | None = None):
        self._path = Path(path) if path else data_dir() / "settings.json"
        self._lock = threading.RLock()
        self._data: dict[str, Any] = copy.deepcopy(DEFAULTS)
        self._listeners: list[Callable[[str, Any], None]] = []
        self.load()

    def load(self) -> None:
        with self._lock:
            if not self._path.exists():
                return
            try:
                raw = json.loads(self._path.read_text(encoding="utf-8"))
                if not isinstance(raw, dict):
                    raise ValueError("settings.json: ожидался объект")
                self._data.update(raw)
            except Exception as exc:  # noqa: BLE001
                log.error("Не удалось прочитать настройки (%s). Файл сохранён как .bad", exc)
                try:
                    self._path.replace(self._path.with_suffix(".json.bad"))
                except OSError:
                    pass

    def save(self) -> None:
        with self._lock:
            tmp = self._path.with_suffix(".json.tmp")
            tmp.write_text(json.dumps(self._data, ensure_ascii=False, indent=2), encoding="utf-8")
            os.replace(tmp, self._path)

    def get(self, key: str, default: Any = None) -> Any:
        with self._lock:
            if key in self._data:
                return copy.deepcopy(self._data[key])
        if default is None:
            return DEFAULTS.get(key, default)
        return default

    def set(self, key: str, value: Any, *, notify: bool = True) -> None:
        with self._lock:
            if self._data.get(key) == value and key in self._data:
                return
            self._data[key] = value
            self.save()
        if notify:
            for cb in list(self._listeners):
                try:
                    cb(key, value)
                except Exception:  # noqa: BLE001
                    log.exception("Ошибка в подписчике настроек")

    def on_change(self, cb: Callable[[str, Any], None]) -> None:
        self._listeners.append(cb)
