"""HTTP-клиент: только HTTPS, таймауты, повторы с задержкой, лимит частоты, безопасные ошибки.

Сообщения об ошибках никогда не содержат URL с query-строкой (там бывают ключи API).
"""
from __future__ import annotations

import logging
import threading
import time
from typing import Any, Callable
from urllib.parse import urlsplit

import requests

log = logging.getLogger("vibehub.http")

USER_AGENT = "VibeHub/1.0 (Windows desktop app)"


class ApiError(Exception):
    def __init__(self, message: str, status: int | None = None, reason: str | None = None, body: Any = None):
        super().__init__(message)
        self.message = message
        self.status = status
        self.reason = reason
        self.body = body

    def __str__(self) -> str:
        return self.message


class NetworkError(ApiError):
    """Нет соединения / таймаут."""


class AuthError(ApiError):
    """401/403: неверный ключ, истёк токен, нет прав."""


class NotFoundError(ApiError):
    pass


class RateLimitError(ApiError):
    def __init__(self, message: str, retry_after: float | None = None):
        super().__init__(message, 429)
        self.retry_after = retry_after


def safe_url(url: str) -> str:
    p = urlsplit(url)
    return f"{p.scheme}://{p.netloc}{p.path}"


def _retry_after(resp) -> float | None:
    v = resp.headers.get("Retry-After")
    try:
        return float(v) if v is not None else None
    except ValueError:
        return None


class HttpClient:
    def __init__(self, base_url: str = "", *, headers: dict | None = None, session=None,
                 timeout: tuple[float, float] = (6.0, 20.0), min_interval: float = 0.0,
                 retries: int = 2, sleep: Callable[[float], None] = time.sleep):
        self.base_url = base_url.rstrip("/")
        self.headers = {"User-Agent": USER_AGENT, **(headers or {})}
        self._session = session or requests.Session()
        self.timeout = timeout
        self.min_interval = min_interval
        self.retries = retries
        self._sleep = sleep
        self._lock = threading.Lock()
        self._last = 0.0

    # --- внутреннее ---
    def _full(self, url: str) -> str:
        if url.startswith("http://") or url.startswith("https://"):
            return url
        return f"{self.base_url}/{url.lstrip('/')}"

    def _throttle(self) -> None:
        if self.min_interval <= 0:
            return
        with self._lock:
            wait = self._last + self.min_interval - time.monotonic()
            if wait > 0:
                self._sleep(wait)
            self._last = time.monotonic()

    @staticmethod
    def _parse_body(resp) -> Any:
        try:
            return resp.json()
        except Exception:
            return None

    def _error_for(self, resp) -> ApiError:
        code = resp.status_code
        body = self._parse_body(resp)
        reason = None
        detail = ""
        if isinstance(body, dict):
            err = body.get("error")
            if isinstance(err, dict):
                reason = err.get("reason")
                detail = str(err.get("message") or "")
            elif isinstance(err, str):
                reason = err
                detail = str(body.get("error_description") or "")
            elif isinstance(body.get("errors"), list) and body["errors"]:
                first = body["errors"][0]
                detail = str(first.get("message") if isinstance(first, dict) else first)
        if code == 401:
            return AuthError("Доступ не авторизован: ключ или токен недействителен." + (f" {detail}" if detail else ""),
                             code, reason, body)
        if code == 403:
            return AuthError("Доступ запрещён." + (f" {detail}" if detail else ""), code, reason, body)
        if code == 404:
            return NotFoundError("Ничего не найдено (404).", code, reason, body)
        return ApiError(f"Сервер вернул ошибку {code}." + (f" {detail}" if detail else ""), code, reason, body)

    # --- публичное ---
    def request(self, method: str, url: str, *, params=None, data=None, json=None,
                headers: dict | None = None, ok: tuple[int, ...] = (200,)):
        full = self._full(url)
        if not full.lower().startswith("https://"):
            raise ApiError("Разрешены только HTTPS-запросы.")
        merged = {**self.headers, **(headers or {})}
        attempt = 0
        while True:
            self._throttle()
            try:
                resp = self._session.request(method, full, params=params, data=data, json=json,
                                             headers=merged, timeout=self.timeout)
            except (requests.ConnectionError, requests.Timeout):
                if attempt < self.retries:
                    self._sleep(0.5 * (2 ** attempt))
                    attempt += 1
                    continue
                raise NetworkError("Нет соединения с сервером. Проверьте интернет.") from None
            except requests.RequestException as exc:
                # текст исключения requests может содержать URL с ключом — не включаем
                raise NetworkError(f"Ошибка сетевого запроса ({type(exc).__name__}).") from None
            final = getattr(resp, "url", full) or full
            if isinstance(final, str) and not final.lower().startswith("https://"):
                raise ApiError("Сервер перенаправил на незащищённый адрес — запрос отклонён.")
            code = resp.status_code
            if code in ok:
                return resp
            if code == 429:
                ra = _retry_after(resp)
                if attempt < self.retries and ra is not None and ra <= 5:
                    self._sleep(ra)
                    attempt += 1
                    continue
                raise RateLimitError("Превышен лимит запросов API. Попробуйте позже.", ra)
            if code >= 500 and attempt < self.retries:
                self._sleep(0.5 * (2 ** attempt))
                attempt += 1
                continue
            raise self._error_for(resp)

    def get_json(self, url: str, *, params=None, headers: dict | None = None, ok: tuple[int, ...] = (200,)) -> Any:
        return self.json_of(self.request("GET", url, params=params, headers=headers, ok=ok))

    @staticmethod
    def json_of(resp) -> Any:
        try:
            return resp.json()
        except ValueError:
            raise ApiError("Сервер вернул некорректный ответ.") from None

    def download(self, url: str, max_bytes: int = 5_000_000) -> bytes:
        """Скачивание картинки с ограничением размера."""
        full = self._full(url)
        if not full.lower().startswith("https://"):
            raise ApiError("Разрешены только HTTPS-запросы.")
        try:
            with self._session.get(full, stream=True, timeout=self.timeout,
                                   headers={"User-Agent": USER_AGENT}) as resp:
                if resp.status_code != 200:
                    raise ApiError(f"Не удалось загрузить изображение ({resp.status_code}).", resp.status_code)
                ctype = resp.headers.get("Content-Type", "")
                if not ctype.startswith("image/"):
                    raise ApiError("Ответ не является изображением.")
                buf = bytearray()
                for chunk in resp.iter_content(65536):
                    buf.extend(chunk)
                    if len(buf) > max_bytes:
                        raise ApiError("Изображение слишком большое.")
                return bytes(buf)
        except (requests.ConnectionError, requests.Timeout):
            raise NetworkError("Нет соединения с сервером.") from None
        except requests.RequestException as exc:
            raise NetworkError(f"Ошибка загрузки ({type(exc).__name__}).") from None
