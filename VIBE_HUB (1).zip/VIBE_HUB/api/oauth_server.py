"""Одноразовый локальный HTTP-сервер для приёма редиректа OAuth/OpenID (только 127.0.0.1)."""
from __future__ import annotations

import html
import threading
from http.server import BaseHTTPRequestHandler, HTTPServer
from typing import Callable
from urllib.parse import parse_qs, urlsplit


class OAuthError(Exception):
    pass


_PAGE = """<!doctype html><html lang="ru"><head><meta charset="utf-8"><title>VIBE HUB</title>
<style>body{{margin:0;background:#0B0B12;color:#ECECF5;font-family:Segoe UI,Arial,sans-serif;
display:flex;align-items:center;justify-content:center;height:100vh}}
.c{{padding:36px 44px;border-radius:18px;background:#14141f;border:1px solid #2a2a40;text-align:center;max-width:420px}}
h1{{margin:0 0 10px;font-size:22px;background:linear-gradient(90deg,#8B5CF6,#38BDF8);-webkit-background-clip:text;color:transparent}}
p{{margin:0;color:#9a9ab5;line-height:1.5}}</style></head>
<body><div class="c"><h1>VIBE HUB</h1><p>{text}</p></div></body></html>"""


class CallbackServer:
    def __init__(self, port: int, path: str):
        self.port = port
        self.path = path
        self._httpd: HTTPServer | None = None
        self._thread: threading.Thread | None = None
        self._event = threading.Event()
        self._params: dict[str, str] | None = None

    def start(self) -> None:
        outer = self

        class Handler(BaseHTTPRequestHandler):
            def do_GET(self):  # noqa: N802
                parts = urlsplit(self.path)
                if parts.path != outer.path:
                    self.send_response(404)
                    self.end_headers()
                    return
                if outer._params is None:
                    outer._params = {k: v[0] for k, v in parse_qs(parts.query, keep_blank_values=True).items()}
                    ok = "error" not in outer._params
                    text = ("Вход выполнен. Эту вкладку можно закрыть и вернуться в приложение."
                            if ok else "Вход отменён или не удался. Вернитесь в приложение.")
                    outer._event.set()
                else:
                    text = "Ссылка уже использована."
                body = _PAGE.format(text=html.escape(text)).encode("utf-8")
                self.send_response(200)
                self.send_header("Content-Type", "text/html; charset=utf-8")
                self.send_header("Content-Length", str(len(body)))
                self.send_header("Cache-Control", "no-store")
                self.send_header("Referrer-Policy", "no-referrer")
                self.end_headers()
                self.wfile.write(body)

            def log_message(self, *args):  # не пишем URL (в них коды авторизации)
                pass

        HTTPServer.allow_reuse_address = True
        try:
            self._httpd = HTTPServer(("127.0.0.1", self.port), Handler)
        except OSError as exc:
            raise OAuthError(f"Не удалось занять порт {self.port} для приёма ответа ({exc.strerror or exc}). "
                             "Закройте программу, использующую этот порт, или смените порт в настройках.") from None
        self._thread = threading.Thread(target=self._httpd.serve_forever, kwargs={"poll_interval": 0.1},
                                        name="oauth-callback", daemon=True)
        self._thread.start()

    def wait(self, timeout: float = 180.0, cancelled: Callable[[], bool] | None = None) -> dict[str, str]:
        waited = 0.0
        while not self._event.wait(0.2):
            waited += 0.2
            if cancelled and cancelled():
                raise OAuthError("Вход отменён.")
            if waited >= timeout:
                raise OAuthError("Время ожидания входа истекло. Попробуйте ещё раз.")
        assert self._params is not None
        return self._params

    def close(self) -> None:
        if self._httpd is not None:
            try:
                self._httpd.shutdown()
            finally:
                self._httpd.server_close()
            self._httpd = None
        if self._thread is not None:
            self._thread.join(timeout=2)
            self._thread = None

    def __enter__(self):
        self.start()
        return self

    def __exit__(self, *exc):
        self.close()
