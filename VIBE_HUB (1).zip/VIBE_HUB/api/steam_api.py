"""Steam: вход через официальный OpenID + Steam Web API.

Пароль Steam приложение не видит: вход происходит на steamcommunity.com в браузере.
OpenID отдаёт только SteamID. Профиль, уровень, игры и достижения — через Web API
и требуют ключ пользователя (https://steamcommunity.com/dev/apikey).
Без ключа доступны только никнейм/аватар из публичного XML-профиля.
Закрытые профили не обходятся — приложение сообщает об ограничении.
"""
from __future__ import annotations

import re
import xml.etree.ElementTree as ET
from typing import Any
from urllib.parse import urlencode

from api.http import ApiError, AuthError, HttpClient

OPENID_ENDPOINT = "https://steamcommunity.com/openid/login"
API_BASE = "https://api.steampowered.com"
_CLAIMED_RE = re.compile(r"^https://steamcommunity\.com/openid/id/(\d{17})$")


class PrivateProfileError(ApiError):
    """Профиль или данные игры скрыты настройками приватности."""


# ---------------- OpenID ----------------
def build_login_url(return_to: str, realm: str) -> str:
    q = {
        "openid.ns": "http://specs.openid.net/auth/2.0",
        "openid.mode": "checkid_setup",
        "openid.return_to": return_to,
        "openid.realm": realm,
        "openid.identity": "http://specs.openid.net/auth/2.0/identifier_select",
        "openid.claimed_id": "http://specs.openid.net/auth/2.0/identifier_select",
    }
    return f"{OPENID_ENDPOINT}?{urlencode(q)}"


def extract_steam_id(params: dict[str, str], expected_return_to: str) -> str | None:
    """Локальные проверки ответа OpenID. None — ответ не прошёл проверку."""
    if params.get("openid.mode") != "id_res":
        return None
    if params.get("openid.op_endpoint") != OPENID_ENDPOINT:
        return None
    if params.get("openid.return_to") != expected_return_to:
        return None
    m = _CLAIMED_RE.match(params.get("openid.claimed_id", ""))
    if not m or params.get("openid.identity") != params.get("openid.claimed_id"):
        return None
    return m.group(1)


def verify_assertion(params: dict[str, str], http: HttpClient | None = None) -> bool:
    """Просим Steam подтвердить подпись ответа (openid.mode=check_authentication)."""
    http = http or HttpClient()
    data = {k: v for k, v in params.items() if k.startswith("openid.")}
    data["openid.mode"] = "check_authentication"
    resp = http.request("POST", OPENID_ENDPOINT, data=data)
    return any(line.strip() == "is_valid:true" for line in resp.text.splitlines())


# ---------------- публичный XML-профиль (без ключа) ----------------
def parse_profile_xml(text: str) -> dict | None:
    low = text.lower()
    if "<!doctype" in low or "<!entity" in low:  # защита от XML-бомб
        return None
    try:
        root = ET.fromstring(text)
    except ET.ParseError:
        return None
    if root.tag != "profile":
        return None

    def g(tag: str) -> str:
        el = root.find(tag)
        return (el.text or "").strip() if el is not None and el.text else ""

    return {"personaname": g("steamID"), "avatarfull": g("avatarFull"),
            "privacy": g("privacyState"), "online_state": g("onlineState"),
            "profileurl": f"https://steamcommunity.com/profiles/{g('steamID64')}" if g("steamID64") else ""}


class SteamClient:
    def __init__(self, api_key: str | None = None, http: HttpClient | None = None):
        self.api_key = api_key or None
        self.http = http or HttpClient(min_interval=0.2)

    def _need_key(self) -> str:
        if not self.api_key:
            raise AuthError("Нужен Steam API Key (Подключённые аккаунты → Steam → Ключ API).")
        return self.api_key

    def _get(self, path: str, params: dict, ok=(200,)) -> Any:
        params = {**params, "key": self._need_key(), "format": "json"}
        try:
            return self.http.get_json(f"{API_BASE}/{path}", params=params, ok=ok)
        except AuthError as exc:
            raise AuthError("Steam отклонил ключ API (или доступ запрещён). Проверьте ключ.", exc.status) from None

    # ---- профиль ----
    def player_summary(self, steamid: str) -> dict | None:
        data = self._get("ISteamUser/GetPlayerSummaries/v2/", {"steamids": steamid})
        players = (data.get("response") or {}).get("players") or []
        return players[0] if players else None

    def profile_xml(self, steamid: str) -> dict | None:
        resp = self.http.request("GET", f"https://steamcommunity.com/profiles/{steamid}/", params={"xml": 1})
        return parse_profile_xml(resp.text)

    def steam_level(self, steamid: str) -> int | None:
        data = self._get("IPlayerService/GetSteamLevel/v1/", {"steamid": steamid})
        lvl = (data.get("response") or {}).get("player_level")
        return int(lvl) if lvl is not None else None

    # ---- игры ----
    def owned_games(self, steamid: str) -> list[dict] | None:
        """None — Steam не вернул список (игры скрыты приватностью)."""
        data = self._get("IPlayerService/GetOwnedGames/v1/",
                         {"steamid": steamid, "include_appinfo": 1, "include_played_free_games": 1})
        resp = data.get("response") or {}
        if "games" not in resp:
            return None if "game_count" not in resp else []
        return resp["games"]

    def recent_games(self, steamid: str) -> list[dict]:
        data = self._get("IPlayerService/GetRecentlyPlayedGames/v1/", {"steamid": steamid, "count": 10})
        return (data.get("response") or {}).get("games") or []

    # ---- достижения ----
    def achievements(self, steamid: str, appid: int) -> dict:
        data = self._get("ISteamUserStats/GetPlayerAchievements/v0001/",
                         {"steamid": steamid, "appid": appid, "l": "english"}, ok=(200, 400))
        ps = data.get("playerstats") or {}
        if not ps.get("success"):
            err = str(ps.get("error") or "")
            if "not public" in err.lower():
                raise PrivateProfileError("Достижения скрыты настройками приватности профиля.")
            raise ApiError(err or "У этой игры нет достижений или данные недоступны.")
        items = [{"name": a.get("name") or a.get("apiname", ""), "desc": a.get("description", ""),
                  "achieved": bool(a.get("achieved")), "unlock_time": a.get("unlocktime") or 0}
                 for a in ps.get("achievements", [])]
        return {"game": ps.get("gameName", ""), "unlocked": sum(1 for i in items if i["achieved"]),
                "total": len(items), "items": items}
