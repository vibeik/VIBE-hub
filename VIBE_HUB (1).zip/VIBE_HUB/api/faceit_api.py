"""FACEIT Data API v4 (https://docs.faceit.com/api/data).

Ограничение API: история ELO по матчам в Data API не отдаётся — доступно только ТЕКУЩЕЕ значение ELO.
График и «изменение ELO» приложение строит из локальных снимков, которые делает при каждом обновлении.
"""
from __future__ import annotations

import re
from typing import Any

from api.http import ApiError, HttpClient, NotFoundError
from utils.timeutil import from_epoch_ms, to_iso

BASE = "https://open.faceit.com/data/v4"
GAME = "cs2"


def _num(v: Any) -> float | None:
    try:
        return float(str(v).replace("%", "").replace(",", ".").strip())
    except (TypeError, ValueError):
        return None


def _int(v: Any) -> int | None:
    n = _num(v)
    return int(n) if n is not None else None


# ---------------- парсинг (чистые функции) ----------------
def parse_player(p: dict, game: str = GAME) -> dict:
    g = (p.get("games") or {}).get(game)
    if not g:
        raise ApiError(f"У игрока «{p.get('nickname', '?')}» нет профиля {game.upper()} на FACEIT.")
    url = (p.get("faceit_url") or "").replace("{lang}", "ru")
    return {"player_id": p.get("player_id"), "nickname": p.get("nickname"), "avatar": p.get("avatar") or None,
            "country": p.get("country"), "region": g.get("region"),
            "level": _int(g.get("skill_level")), "elo": _int(g.get("faceit_elo")),
            "profile_url": url or None}


def parse_lifetime(stats: dict) -> dict:
    lt = stats.get("lifetime") or {}

    def pick(*keys):
        for k in keys:
            if k in lt:
                return lt[k]
        return None

    matches = _int(pick("Matches"))
    wins = _int(pick("Wins"))
    recent = pick("Recent Results")
    return {
        "matches": matches, "wins": wins,
        "losses": (matches - wins) if matches is not None and wins is not None else None,
        "win_rate": _num(pick("Win Rate %")),
        "kd": _num(pick("Average K/D Ratio", "K/D Ratio")),
        "hs_pct": _num(pick("Average Headshots %", "Total Headshots %")),
        "win_streak": _int(pick("Current Win Streak")),
        "best_streak": _int(pick("Longest Win Streak")),
        "recent_results": [str(x) for x in recent] if isinstance(recent, list) else [],
    }


def _map_name(raw: str | None) -> str:
    if not raw:
        return ""
    return re.sub(r"^de_", "", raw).replace("_", " ").title()


def parse_match(item: dict) -> dict | None:
    """Элемент `items[]` из /players/{id}/games/{game}/stats -> поля для таблицы matches. None — непригоден."""
    s = item.get("stats") or item
    finished = _int(s.get("Match Finished At"))
    result = str(s.get("Result", "")).strip()
    kills, deaths = _int(s.get("Kills")), _int(s.get("Deaths"))
    if finished is None or result not in ("0", "1") or kills is None or deaths is None:
        return None
    mid = s.get("Match Id") or f"{finished}-{s.get('Map', '')}"
    score = s.get("Final Score") or s.get("Score")
    return {"external_id": str(mid), "played_at": to_iso(from_epoch_ms(finished)),
            "map": _map_name(s.get("Map")), "result": "win" if result == "1" else "loss",
            "kills": kills, "deaths": deaths, "assists": _int(s.get("Assists")) or 0,
            "headshot_pct": _num(s.get("Headshots %")),
            "score": str(score).replace(" / ", ":").replace("/", ":") if score else None}


# ---------------- клиент ----------------
class FaceitClient:
    def __init__(self, api_key: str, http: HttpClient | None = None):
        if not api_key:
            raise ApiError("Укажите FACEIT API Key (Подключённые аккаунты → FACEIT).")
        self.http = http or HttpClient(BASE, min_interval=0.25)
        self._headers = {"Authorization": f"Bearer {api_key}", "Accept": "application/json"}

    def _get(self, path: str, params: dict | None = None) -> Any:
        return self.http.get_json(f"{BASE}/{path.lstrip('/')}", params=params, headers=self._headers)

    def search_players(self, nickname: str, limit: int = 10) -> list[dict]:
        data = self._get("search/players", {"nickname": nickname, "game": GAME, "limit": limit})
        return data.get("items") or []

    def player_by_nickname(self, nickname: str) -> dict:
        try:
            return self._get("players", {"nickname": nickname, "game": GAME})
        except NotFoundError:
            raise NotFoundError(f"Игрок «{nickname}» не найден на FACEIT.", 404) from None

    def player(self, player_id: str) -> dict:
        return self._get(f"players/{player_id}")

    def player_stats(self, player_id: str) -> dict:
        return self._get(f"players/{player_id}/stats/{GAME}")

    def match_stats(self, player_id: str, limit: int = 100, offset: int = 0) -> list[dict]:
        data = self._get(f"players/{player_id}/games/{GAME}/stats", {"limit": limit, "offset": offset})
        return data.get("items") or []
