"""Spotify Web API: OAuth 2.0 Authorization Code + PKCE (клиентский секрет не нужен).

Актуальные ограничения (проверено по документации Spotify, 2026):
- Redirect URI: только https:// или loopback-IP `http://127.0.0.1:PORT/...` (localhost запрещён).
  URI должен ТОЧНО совпадать с указанным в Spotify Developer Dashboard.
- Dev Mode с февраля–марта 2026: нужен Spotify Premium у владельца приложения, максимум 5 пользователей
  на Client ID. Поле `product` из /me убрано, поэтому Premium у слушателя определяется по ответу
  PREMIUM_REQUIRED на команды управления.
- Управление воспроизведением (play/pause/next/previous) работает только на аккаунте Premium
  и при наличии активного устройства (Spotify открыт на ПК/телефоне).
- Spotify не предоставляет endpoint отзыва токена: при отключении токены удаляются локально,
  доступ можно отозвать на https://www.spotify.com/account/apps/.
"""
from __future__ import annotations

import base64
import hashlib
import secrets as pysecrets
import time
from urllib.parse import urlencode

from api.http import ApiError, AuthError, HttpClient
from utils import secrets as sec

AUTH_URL = "https://accounts.spotify.com/authorize"
TOKEN_URL = "https://accounts.spotify.com/api/token"
API = "https://api.spotify.com/v1"
SCOPES = ["user-read-playback-state", "user-modify-playback-state", "user-read-currently-playing",
          "playlist-read-private", "playlist-read-collaborative"]


class PremiumRequired(ApiError):
    pass


class NoActiveDevice(ApiError):
    pass


def make_pkce() -> tuple[str, str]:
    verifier = base64.urlsafe_b64encode(pysecrets.token_bytes(64)).decode().rstrip("=")
    challenge = base64.urlsafe_b64encode(hashlib.sha256(verifier.encode()).digest()).decode().rstrip("=")
    return verifier, challenge


def build_auth_url(client_id: str, redirect_uri: str, challenge: str, state: str) -> str:
    q = {"client_id": client_id, "response_type": "code", "redirect_uri": redirect_uri,
         "code_challenge_method": "S256", "code_challenge": challenge, "state": state,
         "scope": " ".join(SCOPES)}
    return f"{AUTH_URL}?{urlencode(q)}"


def parse_playback(data: dict | None, playlist_names: dict[str, str] | None = None) -> dict | None:
    """Ответ GET /me/player -> компактное состояние. None — нет активного устройства."""
    if not data:
        return None
    item = data.get("item") or {}
    album = item.get("album") or {}
    images = album.get("images") or []
    ctx = data.get("context") or {}
    ctx_uri = ctx.get("uri")
    names = playlist_names or {}
    device = data.get("device") or {}
    return {
        "is_playing": bool(data.get("is_playing")),
        "title": item.get("name") or ("Реклама" if data.get("currently_playing_type") == "ad" else ""),
        "artists": ", ".join(a.get("name", "") for a in item.get("artists", []) if a.get("name")),
        "album": album.get("name", ""),
        "cover_url": images[0]["url"] if images else None,
        "progress_ms": int(data.get("progress_ms") or 0),
        "duration_ms": int(item.get("duration_ms") or 0),
        "context_type": ctx.get("type"),
        "context_uri": ctx_uri,
        "context_name": names.get(ctx_uri) if ctx_uri else None,
        "device": device.get("name"),
        "fetched_at": time.monotonic(),
    }


def parse_playlists(items: list[dict]) -> list[dict]:
    out = []
    for p in items:
        if not p:
            continue
        imgs = p.get("images") or []
        cnt = p.get("items") or p.get("tracks") or {}
        out.append({"id": p.get("id"), "uri": p.get("uri"), "name": p.get("name") or "Без названия",
                    "cover_url": imgs[0]["url"] if imgs else None,
                    "total": cnt.get("total") if isinstance(cnt, dict) else None,
                    "owner": (p.get("owner") or {}).get("display_name")})
    return out


class SpotifyClient:
    def __init__(self, client_id: str, store: sec.SecretStore, http: HttpClient | None = None):
        self.client_id = client_id
        self.store = store
        self.http = http or HttpClient(min_interval=0.1)

    # ---- токены ----
    def has_tokens(self) -> bool:
        return bool(self.store.get(sec.SPOTIFY_REFRESH) or self.store.get(sec.SPOTIFY_ACCESS))

    def _save_tokens(self, tok: dict) -> None:
        if tok.get("access_token"):
            self.store.set(sec.SPOTIFY_ACCESS, tok["access_token"])
        if tok.get("refresh_token"):  # при обновлении Spotify может не прислать новый refresh_token
            self.store.set(sec.SPOTIFY_REFRESH, tok["refresh_token"])
        self.store.set(sec.SPOTIFY_EXPIRES, str(time.time() + int(tok.get("expires_in", 3600))))

    def clear_tokens(self) -> None:
        self.store.delete_many([sec.SPOTIFY_ACCESS, sec.SPOTIFY_REFRESH, sec.SPOTIFY_EXPIRES])

    def _token_request(self, data: dict) -> dict:
        try:
            resp = self.http.request("POST", TOKEN_URL, data=data, ok=(200,))
        except AuthError:
            raise
        except ApiError as exc:
            if exc.status == 400:
                raise AuthError("Spotify отклонил запрос авторизации (токен истёк или отозван). "
                                "Подключите аккаунт заново.", 400) from None
            raise
        return self.http.json_of(resp)

    def exchange_code(self, code: str, verifier: str, redirect_uri: str) -> None:
        tok = self._token_request({"grant_type": "authorization_code", "code": code,
                                   "redirect_uri": redirect_uri, "client_id": self.client_id,
                                   "code_verifier": verifier})
        self._save_tokens(tok)

    def refresh(self) -> None:
        rt = self.store.get(sec.SPOTIFY_REFRESH)
        if not rt:
            raise AuthError("Нет refresh-токена: подключите Spotify заново.")
        try:
            tok = self._token_request({"grant_type": "refresh_token", "refresh_token": rt,
                                       "client_id": self.client_id})
        except AuthError:
            self.clear_tokens()  # токен отозван — не держим мёртвые секреты
            raise
        self._save_tokens(tok)

    def _access(self) -> str:
        exp = self.store.get(sec.SPOTIFY_EXPIRES)
        tok = self.store.get(sec.SPOTIFY_ACCESS)
        try:
            expired = (not tok) or (float(exp or 0) - time.time() < 60)
        except ValueError:
            expired = True
        if expired:
            self.refresh()
            tok = self.store.get(sec.SPOTIFY_ACCESS)
        if not tok:
            raise AuthError("Spotify не подключён.")
        return tok

    # ---- запросы ----
    def _call(self, method: str, path: str, *, params=None, json=None, ok=(200,), _retry=True):
        try:
            return self.http.request(method, f"{API}/{path.lstrip('/')}", params=params, json=json, ok=ok,
                                     headers={"Authorization": f"Bearer {self._access()}"})
        except AuthError as exc:
            if exc.status == 401 and _retry:  # токен мог истечь раньше срока
                self.refresh()
                return self._call(method, path, params=params, json=json, ok=ok, _retry=False)
            if exc.status == 403 and exc.reason == "PREMIUM_REQUIRED":
                raise PremiumRequired("Управление воспроизведением доступно только с Spotify Premium.",
                                      403, exc.reason) from None
            if exc.status == 403:
                raise AuthError("Spotify отклонил запрос (403). В режиме разработчика доступ есть только у "
                                "добавленных в Dashboard пользователей, а владелец приложения должен иметь Premium.",
                                403, exc.reason) from None
            raise
        except ApiError as exc:
            if exc.status == 404 and exc.reason == "NO_ACTIVE_DEVICE":
                raise NoActiveDevice("Нет активного устройства Spotify. Запустите Spotify на ПК или телефоне "
                                     "и начните воспроизведение.", 404, exc.reason) from None
            raise

    def me(self) -> dict:
        return self.http.json_of(self._call("GET", "me"))

    def playback(self, playlist_names: dict[str, str] | None = None) -> dict | None:
        resp = self._call("GET", "me/player", ok=(200, 204))
        if resp.status_code == 204 or not resp.content:
            return None
        return parse_playback(self.http.json_of(resp), playlist_names)

    def play(self, context_uri: str | None = None) -> None:
        self._call("PUT", "me/player/play", json={"context_uri": context_uri} if context_uri else None,
                   ok=(200, 202, 204))

    def pause(self) -> None:
        self._call("PUT", "me/player/pause", ok=(200, 202, 204))

    def next(self) -> None:
        self._call("POST", "me/player/next", ok=(200, 202, 204))

    def previous(self) -> None:
        self._call("POST", "me/player/previous", ok=(200, 202, 204))

    def playlists(self, max_pages: int = 4) -> list[dict]:
        out: list[dict] = []
        offset = 0
        for _ in range(max_pages):
            data = self.http.json_of(self._call("GET", "me/playlists", params={"limit": 50, "offset": offset}))
            out.extend(parse_playlists(data.get("items") or []))
            if not data.get("next"):
                break
            offset += 50
        return out
