"""Как часто опрашивать датчики (без Qt, чтобы логика проверялась тестами)."""
from __future__ import annotations

IDLE_INTERVAL_MS = 5000    # датчики никто не смотрит (другая страница или свёрнутое окно): история пишется раз в 10 с
BACKGROUND_INTERVAL_MS = 3000


def poll_interval_ms(interval_ms: int, *, background: bool, watchers: int, record: bool) -> int:
    """Живые показания нужны только пока открыт Dashboard или PC Monitor. Иначе опрос нужен лишь для записи истории
    (раз в 10 с), поэтому 5 с достаточно, а если историю ещё и не пишем — можно опрашивать ещё реже."""
    base = max(250, int(interval_ms))
    if watchers > 0 and not background:
        return base
    if background:
        base = max(base, BACKGROUND_INTERVAL_MS)
    idle = IDLE_INTERVAL_MS if record else IDLE_INTERVAL_MS * 2
    return max(base, idle)


class WatchCounter:
    """Сколько видимых страниц сейчас показывают живые данные."""

    def __init__(self) -> None:
        self.count = 0

    def watch(self) -> None:
        self.count += 1

    def unwatch(self) -> None:
        self.count = max(0, self.count - 1)
