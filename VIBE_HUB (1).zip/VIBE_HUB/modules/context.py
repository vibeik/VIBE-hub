"""AppContext: общий контейнер сервисов приложения (создаётся один раз в main.py)."""
from __future__ import annotations

import logging
from typing import Any

from config.settings import Settings, cache_dir
from database.db import Database
from database.repos import Repos
from modules import goal_service
from modules.controllers import FaceitController, SpotifyController, SteamController
from modules.events import Bus
from modules.monitor_service import MonitorService
from modules.music_player import MusicPlayer
from modules.notifications import NotificationCenter
from modules import workers
from utils.perf import PerfStats
from utils.secrets import SecretStore
from utils.i18n import _

log = logging.getLogger("vibehub.context")


class AppContext:
    def __init__(self, settings: Settings, db: Database):
        self.settings = settings
        self.db = db
        self.repos = Repos(db)
        self.store = SecretStore()
        self.bus = Bus()
        self.notifications = NotificationCenter(self.bus)
        self.minimized = False             # окно свёрнуто; приложение при этом продолжает работать
        self.perf = PerfStats()            # замеры подвисаний интерфейса (наполняет ui.perf_watch)
        self.monitor = MonitorService(self.repos.pc, int(settings.get("monitor_interval_ms") or 1000),
                                      bool(settings.get("monitor_history")))
        self.faceit = FaceitController(self)
        self.steam = SteamController(self)
        self.spotify = SpotifyController(self)
        self.player = MusicPlayer(self)
        self.theme: Any = None      # ui.theme.ThemeManager, назначается в main
        settings.on_change(lambda k, v: self.bus.settings_changed.emit(k, v))
        self.bus.settings_changed.connect(self._on_setting)

    # ---- запуск / остановка ----
    def start(self) -> None:
        self.monitor.start()
        self.faceit.start()
        self.steam.start()
        self.spotify.start()
        self.sync_goals()

    def shutdown(self) -> None:
        log.info("Остановка фоновых задач")
        for ctl in (self.faceit, self.steam, self.spotify):
            ctl.stop()
        self.spotify.cancel_connect()
        self.steam.cancel_sign_in()
        self.player.shutdown()
        self.monitor.stop()
        workers.shutdown()

    # ---- общие операции ----
    def notify(self, kind: str, title: str, text: str = "", toast: bool = True) -> None:
        self.notifications.add(kind, title, text, toast)

    def log_activity(self, kind: str, text: str, ref: str | None = None) -> None:
        self.repos.activity.add(kind, text, ref)
        self.bus.activity_changed.emit()

    def sync_goals(self) -> None:
        """Обновить цели с авто-метриками и показать уведомления о завершённых."""
        try:
            ctx = goal_service.build_context(self.repos, self.faceit.overview(),
                                             self.settings.get("dashboard_source") or "all")
            done = goal_service.sync_auto_goals(self.repos, ctx)
        except Exception:
            log.exception("Не удалось обновить цели")
            return
        for g in done:
            self.notify("success", _("Цель выполнена 🎯"), g["title"])
        self.bus.goals_changed.emit()
        if done:
            self.bus.activity_changed.emit()

    def cover_cache(self):
        return cache_dir("covers")

    def _on_setting(self, key: str, value) -> None:
        if key == "monitor_interval_ms":
            self.monitor.set_interval(int(value))
        elif key == "monitor_history":
            self.monitor.record = bool(value)
        elif key == "dashboard_source":
            self.sync_goals()
        elif key in ("faceit_poll_min", "steam_poll_min"):
            ctl = self.faceit if key.startswith("faceit") else self.steam
            ctl._start_timer(max(2, int(value)), ctl._auto)
