"""Удаление следов приложения: автозапуск, ключи в Windows Credential Manager, кэш и (по желанию) все данные.

Без Qt и без открытия базы — запускается командой `main.py --cleanup [--delete-data]`
(из uninstall.bat и из деинсталлятора Inno Setup).
"""
from __future__ import annotations

import json
import logging
import shutil
from dataclasses import dataclass
from pathlib import Path

from config import settings as cfg
from modules import autostart
from utils import i18n
from utils import secrets as sec
from utils.i18n import _

log = logging.getLogger("vibehub.cleanup")

# Папку данных удаляем только если это явно наша папка
DATA_MARKERS = ("vibehub.db", "settings.json")
ALL_SECRETS = (sec.STEAM_API_KEY, sec.FACEIT_API_KEY, sec.SPOTIFY_ACCESS, sec.SPOTIFY_REFRESH, sec.SPOTIFY_EXPIRES)


@dataclass
class Step:
    name: str
    ok: bool
    detail: str = ""

    def line(self) -> str:
        return f"[{' OK ' if self.ok else 'FAIL'}] {self.name}" + (f" — {self.detail}" if self.detail else "")


def is_safe_data_dir(base: Path) -> bool:
    """Защита от удаления чужой папки (например, из-за неверной VIBEHUB_DATA_DIR)."""
    try:
        p = base.resolve()
    except OSError:
        return False
    if p == p.parent or p == Path.home().resolve() or len(p.parts) < 3:
        return False                                   # корень диска, домашняя папка, слишком короткий путь
    if p.name == cfg.APP_ID:
        return True
    return any((p / m).exists() for m in DATA_MARKERS)


def _remaining(path: Path, limit: int = 3) -> list[str]:
    left: list[str] = []
    for f in path.rglob("*"):
        if f.is_file():
            left.append(f.name)
            if len(left) >= limit:
                break
    return left


def _rmtree(path: Path) -> tuple[bool, str]:
    shutil.rmtree(path, ignore_errors=True)
    if not path.exists():
        return True, ""
    left = ", ".join(_remaining(path))
    return False, _("не удалось удалить файлы (возможно, VIBE HUB ещё запущен): ") + left


def remove_autostart() -> Step:
    name = _("Автозапуск с Windows")
    if not autostart.supported():
        return Step(name, True, _("не используется на этой системе"))
    try:
        if not autostart.is_enabled():
            return Step(name, True, _("записи не было"))
        autostart.set_enabled(False)
        return Step(name, not autostart.is_enabled(), _("запись удалена"))
    except OSError as exc:
        return Step(name, False, str(exc))


def remove_secrets(store: sec.SecretStore | None = None) -> Step:
    name = _("Ключи и токены в Credential Manager")
    try:
        store = store or sec.SecretStore()
    except Exception as exc:  # noqa: BLE001
        return Step(name, False, type(exc).__name__)
    if not store.persistent:
        return Step(name, True, _("хранилище недоступно из этого окружения — проверьте Credential Manager вручную (записи VibeHub)"))
    store.delete_many(ALL_SECRETS)
    left = [n for n in ALL_SECRETS if store.get(n)]
    if left:
        return Step(name, False, _("остались записи: ") + ", ".join(left))
    return Step(name, True, _("удалены"))


def remove_cache(base: Path) -> Step:
    name = _("Кэш (скачанные картинки и обложки)")
    cache = base / "cache"
    if not cache.exists():
        return Step(name, True, _("кэша не было"))
    ok, why = _rmtree(cache)
    return Step(name, ok, why or _("удалён"))


def remove_data(base: Path) -> Step:
    name = _("Данные: база, настройки, резервные копии, журналы")
    if not base.exists():
        return Step(name, True, _("папки не было"))
    if not is_safe_data_dir(base):
        return Step(name, False, _("отказ: папка не похожа на папку VIBE HUB — ") + str(base))
    ok, why = _rmtree(base)
    return Step(name, ok, why or _("удалены: ") + str(base))


def _language(base: Path) -> str:
    try:
        lang = json.loads((base / "settings.json").read_text(encoding="utf-8")).get("language")
        return lang if lang in ("ru", "en") else "ru"
    except (OSError, ValueError, AttributeError):
        return "ru"


def run(delete_data: bool, base: Path | None = None, store: sec.SecretStore | None = None) -> list[Step]:
    base = base or cfg.data_dir_path()
    i18n.set_language(_language(base))
    steps = [remove_autostart(), remove_secrets(store)]
    steps.append(remove_data(base) if delete_data else remove_cache(base))
    return steps
