"""Сканирование музыкальных папок и чтение тегов. Qt не нужен.

Теги читаются через mutagen, если он установлен; иначе название берётся из имени файла.
Длительность без mutagen неизвестна (0) и уточняется плеером при воспроизведении.
"""
from __future__ import annotations

import hashlib
import logging
import os
from pathlib import Path
from typing import Callable, Iterator

log = logging.getLogger("vibehub.music")

AUDIO_EXT = {".mp3", ".flac", ".wav", ".ogg", ".oga", ".opus", ".m4a", ".aac", ".wma"}


def iter_audio_files(folder: str | Path) -> Iterator[Path]:
    for root, _dirs, files in os.walk(folder):
        for f in files:
            if Path(f).suffix.lower() in AUDIO_EXT:
                yield Path(root) / f


def title_from_filename(path: Path) -> tuple[str, str]:
    """'Artist - Title.mp3' -> (title, artist)."""
    stem = path.stem.strip()
    if " - " in stem:
        artist, title = stem.split(" - ", 1)
        return title.strip() or stem, artist.strip()
    return stem, ""


def read_tags(path: Path, cover_dir: Path | None = None) -> dict:
    title, artist = title_from_filename(path)
    info = {"title": title, "artist": artist, "album": "", "duration_ms": 0, "cover": None}
    try:
        import mutagen  # type: ignore
    except ImportError:
        return info
    try:
        mf = mutagen.File(str(path), easy=True)
        if mf is not None:
            def first(key: str) -> str:
                v = mf.tags.get(key) if mf.tags else None
                return str(v[0]).strip() if v else ""

            info["title"] = first("title") or info["title"]
            info["artist"] = first("artist") or info["artist"]
            info["album"] = first("album")
            if mf.info is not None and getattr(mf.info, "length", None):
                info["duration_ms"] = int(mf.info.length * 1000)
        if cover_dir is not None:
            info["cover"] = _extract_cover(path, cover_dir)
    except Exception:
        log.debug("Не удалось прочитать теги %s", path, exc_info=True)
    return info


def _extract_cover(path: Path, cover_dir: Path) -> str | None:
    """Сохраняет встроенную обложку в кэш (имя = хэш содержимого), возвращает путь."""
    import mutagen  # type: ignore

    data: bytes | None = None
    try:
        raw = mutagen.File(str(path))
        if raw is None:
            return None
        tags = raw.tags
        if tags is not None:
            for k in tags.keys():  # ID3: APIC:...
                if str(k).startswith("APIC"):
                    data = tags[k].data
                    break
        if data is None and hasattr(raw, "pictures") and raw.pictures:  # FLAC/OGG
            data = raw.pictures[0].data
        if data is None and tags is not None and "covr" in tags:  # MP4
            data = bytes(tags["covr"][0])
    except Exception:
        return None
    if not data:
        # обложка-файл рядом с треком
        for name in ("cover.jpg", "cover.png", "folder.jpg", "folder.png", "front.jpg"):
            p = path.parent / name
            if p.exists():
                return str(p)
        return None
    cover_dir.mkdir(parents=True, exist_ok=True)
    out = cover_dir / (hashlib.sha1(data).hexdigest() + ".img")
    if not out.exists():
        out.write_bytes(data)
    return str(out)


def scan_folder(repo, folder: str, cover_dir: Path,
                should_stop: Callable[[], bool] = lambda: False,
                progress: Callable[[int], None] | None = None) -> dict:
    """Обновляет библиотеку для папки: добавляет новые/изменённые, удаляет исчезнувшие."""
    known = repo.track_mtimes(folder)
    seen: set[str] = set()
    added = updated = 0
    n = 0
    for f in iter_audio_files(folder):
        if should_stop():
            break
        p = str(f)
        seen.add(p)
        try:
            mtime = f.stat().st_mtime
        except OSError:
            continue
        n += 1
        if p in known and abs(known[p] - mtime) < 1e-6:
            continue
        tags = read_tags(f, cover_dir)
        is_new = repo.upsert_track({"path": p, "folder": folder, "mtime": mtime, **tags})
        added += 1 if is_new else 0
        updated += 0 if is_new else 1
        if progress and n % 20 == 0:
            progress(n)
    removed = []
    if not should_stop():
        removed = [p for p in known if p not in seen]
        repo.remove_paths(removed)
    return {"added": added, "updated": updated, "removed": len(removed), "total": n}
