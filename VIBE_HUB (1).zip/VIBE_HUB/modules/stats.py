"""Расчёт статистики матчей (чистые функции, без Qt)."""
from __future__ import annotations

from collections import OrderedDict
from datetime import date

from utils.timeutil import last_n_days, parse_iso


def kd(kills: int, deaths: int) -> float:
    """K/D. При 0 смертей возвращает число убийств (стандартное соглашение трекеров)."""
    return float(kills) if deaths == 0 else kills / deaths


def summarize(matches: list[dict]) -> dict:
    n = len(matches)
    wins = sum(1 for m in matches if m["result"] == "win")
    losses = sum(1 for m in matches if m["result"] == "loss")
    draws = n - wins - losses
    kills = sum(m["kills"] for m in matches)
    deaths = sum(m["deaths"] for m in matches)
    assists = sum(m["assists"] for m in matches)
    decided = wins + losses
    return {
        "matches": n,
        "wins": wins,
        "losses": losses,
        "draws": draws,
        "win_rate": (wins / decided * 100.0) if decided else None,
        "kills": kills,
        "deaths": deaths,
        "assists": assists,
        # K/D матча = убийства/смерти; «средний K/D» считаем как суммарный (kills/deaths) — устойчивее к 0 смертей
        "kd": kd(kills, deaths) if n else None,
        "avg_kd_per_match": (sum(kd(m["kills"], m["deaths"]) for m in matches) / n) if n else None,
        "avg_kills": kills / n if n else None,
    }


def by_day(matches: list[dict], days: int, today: date | None = None) -> "OrderedDict[date, dict]":
    """Группировка по последним `days` дням (включая дни без матчей)."""
    buckets: OrderedDict[date, list[dict]] = OrderedDict((d, []) for d in last_n_days(days, today))
    for m in matches:
        d = parse_iso(m["played_at"]).date()
        if d in buckets:
            buckets[d].append(m)
    out: OrderedDict[date, dict] = OrderedDict()
    for d, ms in buckets.items():
        s = summarize(ms)
        out[d] = s
    return out


def kd_trend(matches: list[dict]) -> list[tuple[str, float]]:
    """Скользящий суммарный K/D по матчам в хронологическом порядке (для графика прогресса)."""
    ks = ds = 0
    pts = []
    for m in sorted(matches, key=lambda x: (x["played_at"], x["id"])):
        ks += m["kills"]
        ds += m["deaths"]
        pts.append((m["played_at"], kd(ks, ds)))
    return pts


def winrate_trend(matches: list[dict]) -> list[tuple[str, float]]:
    w = l = 0
    pts = []
    for m in sorted(matches, key=lambda x: (x["played_at"], x["id"])):
        if m["result"] == "win":
            w += 1
        elif m["result"] == "loss":
            l += 1
        if w + l:
            pts.append((m["played_at"], w / (w + l) * 100.0))
    return pts


def per_map(matches: list[dict]) -> list[dict]:
    groups: dict[str, list[dict]] = {}
    for m in matches:
        groups.setdefault(m["map"] or "—", []).append(m)
    rows = []
    for name, ms in groups.items():
        s = summarize(ms)
        rows.append({"map": name, **s})
    rows.sort(key=lambda r: (-r["matches"], r["map"]))
    return rows
