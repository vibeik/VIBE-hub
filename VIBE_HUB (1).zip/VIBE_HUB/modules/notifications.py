"""Центр уведомлений: список в колокольчике + всплывающие toast."""
from __future__ import annotations

from datetime import datetime

from PySide6.QtCore import QObject, Signal


class NotificationCenter(QObject):
    changed = Signal()
    MAX = 50

    def __init__(self, bus):
        super().__init__()
        self.bus = bus
        self.items: list[dict] = []

    def add(self, kind: str, title: str, text: str = "", toast: bool = True) -> None:
        """kind: info | success | warning | error"""
        self.items.insert(0, {"ts": datetime.now(), "kind": kind, "title": title, "text": text, "read": False})
        del self.items[self.MAX:]
        self.changed.emit()
        if toast:
            self.bus.notified.emit(kind, title, text)

    @property
    def unread(self) -> int:
        return sum(1 for i in self.items if not i["read"])

    def mark_all_read(self) -> None:
        if self.unread:
            for i in self.items:
                i["read"] = True
            self.changed.emit()

    def clear(self) -> None:
        self.items.clear()
        self.changed.emit()
