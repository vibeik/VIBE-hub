"""Бизнес-логика Steam (без Qt): вход OpenID, профиль, игры, достижения."""
from __future__ import annotations

import logging
import webbrowser
from datetime import datetime
from typing import Callable

from api import steam_api as sapi
from api.http import ApiError, AuthError, HttpClient
from api.oauth_server import CallbackServer
from utils import secrets as sec
from utils.timeutil import parse_iso
from utils.i18n import _

log = logging.getLogger("vibehub.steam")
ACH_TTL_SECONDS = 600


class SteamService:
    def __init__(self, repos, settings, store: sec.SecretStore, client_factory=None, http: HttpClient | None = None):
        self.r = repos
        self.settings = settings
        self.store = store
        self._http = http or HttpClient(min_interval=0.2)
        self._factory = client_factory or (lambda key: sapi.SteamClient(key, self._http))

    def api_key(self) -> str | None:
        return self.store.get(sec.STEAM_API_KEY)

    def set_api_key(self, key: str) -> None:
        key = key.strip()
        if key:
            self.store.set(sec.STEAM_API_KEY, key)
        else:
            self.store.delete(sec.STEAM_API_KEY)

    def account(self) -> dict | None:
        return self.r.accounts.get("steam")

    def is_linked(self) -> bool:
        return self.account() is not None

    # ---- вход через Steam OpenID ----
    def sign_in(self, port: int, timeout: float = 180, cancelled: Callable[[], bool] | None = None,
                open_browser: Callable[[str], object] = webbrowser.open) -> str:
        return_to = f"http://127.0.0.1:{port}/steam/callback"
        realm = f"http://127.0.0.1:{port}"
        with CallbackServer(port, "/steam/callback") as srv:
            open_browser(sapi.build_login_url(return_to, realm))
            params = srv.wait(timeout, cancelled)
        steamid = sapi.extract_steam_id(params, return_to)
        if not steamid:
            raise AuthError(_("Steam не подтвердил вход (ответ не прошёл проверку)."))
        if not sapi.verify_assertion(params, self._http):
            raise AuthError(_("Steam не подтвердил подлинность входа."))
        self.r.accounts.upsert("steam", external_id=steamid, profile_url=f"https://steamcommunity.com/profiles/{steamid}",
                               touch_connected=True)
        self.r.activity.add("account", "Steam подключён")
        return steamid

    def disconnect(self, delete_key: bool = True) -> None:
        self.r.accounts.delete("steam")
        self.r.steam.clear()
        self.r.cache.clear("steam:")
        if delete_key:
            self.store.delete(sec.STEAM_API_KEY)
        self.r.activity.add("account", "Steam отключён")

    # ---- обновление ----
    def refresh(self) -> dict:
        acc = self.account()
        if not acc:
            raise ApiError(_("Steam не подключён."))
        sid = acc["external_id"]
        client = self._factory(self.api_key())
        notes: list[str] = []
        profile: dict = {}
        prev = (self.r.cache.get("steam:profile") or ({}, None))[0]
        if client.api_key:
            s = client.player_summary(sid)
            if s:
                profile = {"name": s.get("personaname"), "avatar": s.get("avatarfull"),
                           "profile_url": s.get("profileurl"), "visibility": s.get("communityvisibilitystate"),
                           "playing": s.get("gameextrainfo"), "playing_appid": s.get("gameid"),
                           "persona_state": s.get("personastate"), "created": s.get("timecreated")}
        else:
            notes.append(_("Без Steam API Key доступны только ник и аватар. Добавьте ключ, чтобы увидеть уровень, игры и достижения."))
            x = client.profile_xml(sid)
            if x:
                profile = {"name": x["personaname"], "avatar": x["avatarfull"], "profile_url": x["profileurl"] or acc["profile_url"],
                           "visibility": 3 if x["privacy"] == "public" else 1, "playing": None}
        public = profile.get("visibility") == 3
        level = None
        games = None
        recent: list[dict] = []
        if client.api_key and profile:
            if public:
                level = client.steam_level(sid)
                games = client.owned_games(sid)
                recent = client.recent_games(sid)
                if games is None:
                    notes.append(_("Список игр скрыт: в Steam откройте «Сведения об играх» в настройках приватности."))
            else:
                notes.append(_("Профиль Steam закрыт настройками приватности — игры, уровень и достижения недоступны. "
                             "Приложение не обходит эти ограничения."))
        if games is not None:
            by_recent = {g["appid"]: g for g in recent}
            for g in games:
                g.setdefault("playtime_2weeks", by_recent.get(g["appid"], {}).get("playtime_2weeks", 0))
            self.r.steam.replace_games(games)
        profile["level"] = level
        profile["notes"] = notes
        profile["has_key"] = bool(client.api_key)
        ts = self.r.cache.set("steam:profile", profile)
        self.r.accounts.upsert("steam", username=profile.get("name"), avatar_url=profile.get("avatar"),
                               profile_url=profile.get("profile_url"))
        cur, old = profile.get("playing"), prev.get("playing")
        if cur and cur != old:
            self.r.activity.add("steam", f"Steam: запущена игра «{cur}»")
        return self.overview() | {"updated_at": ts}

    def achievements(self, appid: int, force: bool = False) -> dict:
        acc = self.account()
        if not acc:
            raise ApiError(_("Steam не подключён."))
        key = f"steam:ach:{appid}"
        cached = self.r.cache.get(key)
        if cached and not force and (datetime.now() - parse_iso(cached[1])).total_seconds() < ACH_TTL_SECONDS:
            return cached[0]
        data = self._factory(self.api_key()).achievements(acc["external_id"], appid)
        self.r.cache.set(key, data)
        return data

    # ---- данные для UI ----
    def overview(self) -> dict:
        acc = self.account()
        if not acc:
            return {"linked": False, "has_key": bool(self.api_key())}
        pc = self.r.cache.get("steam:profile")
        p = pc[0] if pc else {}
        games = self.r.steam.games()
        total_min = sum(g["playtime_forever"] for g in games)
        return {
            "linked": True, "has_key": bool(self.api_key()), "steamid": acc["external_id"],
            "name": p.get("name") or acc.get("username"), "avatar": p.get("avatar") or acc.get("avatar_url"),
            "profile_url": p.get("profile_url") or acc.get("profile_url"), "level": p.get("level"),
            "visibility": p.get("visibility"), "private": p.get("visibility") not in (None, 3),
            "playing": p.get("playing"), "notes": p.get("notes", []),
            "games_count": len(games), "total_minutes": total_min,
            "recent": self.r.steam.recent(5), "top": games[:10],
            "updated_at": pc[1] if pc else None,
        }
