"""Автозапуск вместе с Windows (HKCU\\...\\Run). На других ОС недоступен."""
from __future__ import annotations

import logging
import os
import sys
from pathlib import Path
from utils.i18n import _

log = logging.getLogger("vibehub.autostart")
RUN_KEY = r"Software\Microsoft\Windows\CurrentVersion\Run"
VALUE_NAME = "VibeHub"


def supported() -> bool:
    return os.name == "nt"


def build_command() -> str:
    if getattr(sys, "frozen", False):
        return f'"{sys.executable}"'
    exe = Path(sys.executable)
    pyw = exe.with_name("pythonw.exe")
    interp = pyw if pyw.exists() else exe
    main = Path(__file__).resolve().parent.parent / "main.py"
    return f'"{interp}" "{main}"'


def is_enabled() -> bool:
    if not supported():
        return False
    import winreg
    try:
        with winreg.OpenKey(winreg.HKEY_CURRENT_USER, RUN_KEY, 0, winreg.KEY_READ) as k:
            winreg.QueryValueEx(k, VALUE_NAME)
            return True
    except OSError:
        return False


def set_enabled(on: bool) -> None:
    """Бросает OSError, если реестр недоступен."""
    if not supported():
        raise OSError(_("Автозапуск поддерживается только в Windows."))
    import winreg
    with winreg.CreateKey(winreg.HKEY_CURRENT_USER, RUN_KEY) as k:
        if on:
            winreg.SetValueEx(k, VALUE_NAME, 0, winreg.REG_SZ, build_command())
        else:
            try:
                winreg.DeleteValue(k, VALUE_NAME)
            except FileNotFoundError:
                pass
