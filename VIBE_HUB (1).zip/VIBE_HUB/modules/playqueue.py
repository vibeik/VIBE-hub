"""Очередь воспроизведения локального плеера (без Qt): shuffle и repeat."""
from __future__ import annotations

import random


class PlayQueue:
    REPEAT_MODES = ("off", "all", "one")

    def __init__(self, rng: random.Random | None = None):
        self._rng = rng or random.Random()
        self._items: list[int] = []      # id треков в «исходном» порядке
        self._order: list[int] = []      # порядок воспроизведения
        self._pos = -1
        self.shuffle = False
        self.repeat = "off"

    # ---- состояние ----
    @property
    def current(self) -> int | None:
        return self._order[self._pos] if 0 <= self._pos < len(self._order) else None

    def __len__(self) -> int:
        return len(self._items)

    def items(self) -> list[int]:
        return list(self._items)

    # ---- управление ----
    def set_queue(self, ids: list[int], start_id: int | None = None) -> None:
        self._items = list(ids)
        self._rebuild(start_id if start_id in self._items else (self._items[0] if self._items else None))

    def set_shuffle(self, on: bool) -> None:
        cur = self.current
        self.shuffle = on
        self._rebuild(cur)

    def set_repeat(self, mode: str) -> None:
        self.repeat = mode if mode in self.REPEAT_MODES else "off"

    def jump_to(self, track_id: int) -> bool:
        if track_id in self._order:
            self._pos = self._order.index(track_id)
            return True
        return False

    def next(self, auto: bool = False) -> int | None:
        """auto=True — трек закончился сам (учитывается repeat=one). None — очередь закончилась."""
        if not self._order:
            return None
        if auto and self.repeat == "one":
            return self.current
        if self._pos + 1 < len(self._order):
            self._pos += 1
        elif self.repeat == "all":
            if self.shuffle:
                self._rebuild(None)
            self._pos = 0
        else:
            return None
        return self.current

    def prev(self) -> int | None:
        if not self._order:
            return None
        if self._pos > 0:
            self._pos -= 1
        elif self.repeat == "all":
            self._pos = len(self._order) - 1
        return self.current

    # ---- внутреннее ----
    def _rebuild(self, keep_id: int | None) -> None:
        if not self._items:
            self._order, self._pos = [], -1
            return
        if not self.shuffle:
            self._order = list(self._items)
            self._pos = self._order.index(keep_id) if keep_id in self._order else 0
            return
        rest = [i for i in self._items if i != keep_id]
        self._rng.shuffle(rest)
        if keep_id is not None and keep_id in self._items:
            self._order = [keep_id] + rest
        else:
            self._order = rest
        self._pos = 0
