"""Контроллеры интеграций: связывают сервисы (без Qt) с интерфейсом.

Все сетевые вызовы идут в фоновых потоках (workers.run_async); результаты приходят в GUI-поток.
Периодическое обновление идёт, пока приложение запущено — в том числе при свёрнутом или неактивном окне.
Полностью приложение останавливается только при закрытии окна (крестик). Свёрнутое окно лишь реже опрашивает Spotify.
"""
from __future__ import annotations

import logging
import time
from typing import Any, Callable

from PySide6.QtCore import QObject, QTimer, Signal

from api.http import ApiError
from api.spotify_api import NoActiveDevice, PremiumRequired
from modules.faceit_service import FaceitService
from modules.spotify_service import SpotifyService
from modules.steam_service import SteamService
from modules.workers import CancelToken, describe_error, run_async
from utils.i18n import _

log = logging.getLogger("vibehub.controllers")


class BaseController(QObject):
    updated = Signal()
    busy_changed = Signal(bool)
    error = Signal(str)

    def __init__(self, ctx):
        super().__init__()
        self.ctx = ctx
        self.busy = False
        self.last_error = ""
        self._timer: QTimer | None = None

    def _set_busy(self, v: bool) -> None:
        if self.busy != v:
            self.busy = v
            self.busy_changed.emit(v)

    def _run(self, fn: Callable[[], Any], on_ok: Callable[[Any], None] | None = None,
             on_err: Callable[[BaseException], None] | None = None, silent: bool = False) -> None:
        self._set_busy(True)

        def ok(res):
            self._set_busy(False)
            self.last_error = ""
            if on_ok:
                on_ok(res)
            self.updated.emit()

        def err(exc):
            self._set_busy(False)
            msg = describe_error(exc)
            self.last_error = msg
            if not silent:
                self.error.emit(msg)
            if on_err:
                on_err(exc)
            self.updated.emit()

        run_async(fn, ok, err, owner=self)

    def _start_timer(self, minutes: float, slot) -> None:
        if self._timer is None:
            self._timer = QTimer(self)
            self._timer.timeout.connect(slot)
        self._timer.start(int(minutes * 60_000))

    def stop(self) -> None:
        if self._timer:
            self._timer.stop()


# =============================== FACEIT ===============================
class FaceitController(BaseController):
    def __init__(self, ctx):
        super().__init__(ctx)
        self.service = FaceitService(ctx.repos, ctx.settings, ctx.store)

    def start(self) -> None:
        self._start_timer(max(2, int(self.ctx.settings.get("faceit_poll_min") or 10)), self._auto)
        if self.service.is_linked() and self.service.has_key():
            QTimer.singleShot(2500, lambda: self.refresh(False, silent=True))

    def _auto(self) -> None:
        if self.service.is_linked() and self.service.has_key():
            self.refresh(False, silent=True)

    def overview(self) -> dict:
        return self.service.overview()

    @property
    def linked(self) -> bool:
        return self.service.is_linked()

    def refresh(self, force: bool = True, silent: bool = False) -> None:
        if self.busy or not self.service.is_linked():
            return
        if not self.service.has_key():
            if not silent:
                self.error.emit(_("Укажите FACEIT API Key (Подключённые аккаунты → FACEIT)."))
            return
        self._run(lambda: self.service.refresh(force), lambda _o: self._after_sync(), silent=silent)

    def _after_sync(self) -> None:
        self.ctx.bus.matches_changed.emit()
        self.ctx.bus.activity_changed.emit()
        self.ctx.sync_goals()

    def link(self, nickname: str, on_ok: Callable[[dict], None] | None = None) -> None:
        def done(p):
            self.ctx.bus.accounts_changed.emit()
            self.ctx.notifications.add("success", _("FACEIT подключён"), p["nickname"], toast=True)
            if on_ok:
                on_ok(p)
            self.refresh(True)
        self._run(lambda: self.service.link(nickname), done)

    def search(self, nickname: str, on_ok: Callable[[list], None]) -> None:
        self._run(lambda: self.service.search(nickname), on_ok)

    def disconnect(self, delete_key: bool = True) -> None:
        self.service.disconnect(delete_key=delete_key)
        self.ctx.bus.accounts_changed.emit()
        self.ctx.bus.matches_changed.emit()
        self.ctx.bus.activity_changed.emit()
        self.ctx.sync_goals()
        self.updated.emit()


# =============================== STEAM ===============================
class SteamController(BaseController):
    login_state = Signal(str)             # 'waiting' | 'idle'
    achievements_ready = Signal(int, object)
    achievements_failed = Signal(int, str)

    def __init__(self, ctx):
        super().__init__(ctx)
        self.service = SteamService(ctx.repos, ctx.settings, ctx.store)
        self._cancel: CancelToken | None = None

    def start(self) -> None:
        self._start_timer(max(2, int(self.ctx.settings.get("steam_poll_min") or 5)), self._auto)
        if self.service.is_linked():
            QTimer.singleShot(1500, lambda: self.refresh(silent=True))

    def _auto(self) -> None:
        if self.service.is_linked():
            self.refresh(silent=True)

    def overview(self) -> dict:
        return self.service.overview()

    @property
    def linked(self) -> bool:
        return self.service.is_linked()

    def sign_in(self) -> None:
        if self._cancel is not None:
            return
        self._cancel = tok = CancelToken()
        port = int(self.ctx.settings.get("steam_port") or 8889)   # отдельный порт от Spotify
        self.login_state.emit("waiting")

        def finish():
            self._cancel = None
            self.login_state.emit("idle")

        def ok(_sid):
            finish()
            self.ctx.bus.accounts_changed.emit()
            self.ctx.bus.activity_changed.emit()
            self.ctx.notifications.add("success", _("Steam подключён"), _("Вход выполнен через официальный Steam OpenID."))
            self.refresh(silent=True)

        self._run(lambda: self.service.sign_in(port, cancelled=tok), ok, lambda _e: finish())

    def cancel_sign_in(self) -> None:
        if self._cancel:
            self._cancel.cancel()

    def refresh(self, silent: bool = False) -> None:
        if self.busy or not self.service.is_linked():
            return

        def ok(_o):
            self.ctx.bus.accounts_changed.emit()
            self.ctx.bus.activity_changed.emit()
        self._run(self.service.refresh, ok, silent=silent)

    def load_achievements(self, appid: int, force: bool = False) -> None:
        def ok(data):
            self.achievements_ready.emit(appid, data)

        def err(exc):
            self.achievements_failed.emit(appid, describe_error(exc))
        run_async(lambda: self.service.achievements(appid, force), ok, err, owner=self)

    def disconnect(self, delete_key: bool = True) -> None:
        self.service.disconnect(delete_key=delete_key)
        self.ctx.bus.accounts_changed.emit()
        self.ctx.bus.activity_changed.emit()
        self.updated.emit()


# =============================== SPOTIFY ===============================
class SpotifyController(BaseController):
    state_changed = Signal()
    playlists_changed = Signal()
    login_state = Signal(str)

    def __init__(self, ctx):
        super().__init__(ctx)
        self.service = SpotifyService(ctx.repos, ctx.settings, ctx.store)
        self.state: dict | None = None          # parse_playback()
        self.status = "disconnected"            # disconnected | ok | idle | error
        self.status_text = ""
        self.playlists: list[dict] = []
        self.playlists_updated_at: str | None = None
        self._cancel: CancelToken | None = None
        self._polling = False
        self._skipped = 0

    # ---- запуск ----
    def start(self) -> None:
        self._start_timer(5 / 60, self._tick)          # опрос каждые 5 с
        self.playlists, self.playlists_updated_at = self.service.cached_playlists()
        if self.service.is_connected():
            self.status = "idle"
            QTimer.singleShot(1000, self.poll)
            QTimer.singleShot(1500, self.load_playlists)

    @property
    def connected(self) -> bool:
        return self.service.is_connected()

    def _tick(self) -> None:
        if not self.connected:
            return
        if self.ctx.minimized:              # свёрнуто: опрашиваем в 3 раза реже (каждые ~15 с), но не останавливаемся
            self._skipped = (self._skipped + 1) % 3
            if self._skipped:
                return
        self.poll()

    # ---- подключение ----
    def connect_account(self) -> None:
        if self._cancel is not None:
            return
        self._cancel = tok = CancelToken()
        self.login_state.emit("waiting")

        def finish():
            self._cancel = None
            self.login_state.emit("idle")

        def ok(_acc):
            finish()
            self.status = "idle"
            self.ctx.bus.accounts_changed.emit()
            self.ctx.bus.activity_changed.emit()
            self.ctx.notifications.add("success", _("Spotify подключён"), _("Авторизация OAuth 2.0 (PKCE) выполнена."))
            self.poll()
            self.load_playlists()
        self._run(lambda: self.service.connect(cancelled=tok), ok, lambda _e: finish())

    def cancel_connect(self) -> None:
        if self._cancel:
            self._cancel.cancel()

    def disconnect(self) -> None:
        self.service.disconnect()
        self.state, self.status, self.status_text, self.playlists = None, "disconnected", "", []
        self.ctx.bus.accounts_changed.emit()
        self.ctx.bus.activity_changed.emit()
        self.state_changed.emit()
        self.playlists_changed.emit()
        self.updated.emit()

    # ---- состояние плеера ----
    def poll(self) -> None:
        if self._polling or not self.connected:
            return
        self._polling = True

        def ok(state):
            self._polling = False
            self.state = state
            if state is None:
                self.status, self.status_text = "idle", _("Нет активного устройства. Запустите Spotify на ПК или телефоне.")
            else:
                self.status, self.status_text = "ok", ""
            self.state_changed.emit()

        def err(exc):
            self._polling = False
            self.status, self.status_text = "error", describe_error(exc)
            if isinstance(exc, ApiError) and exc.status == 401:
                self.ctx.bus.accounts_changed.emit()
            self.state_changed.emit()
        run_async(self.service.playback, ok, err, owner=self)

    def load_playlists(self) -> None:
        def ok(items):
            self.playlists = items
            self.playlists_updated_at = time.strftime("%Y-%m-%d %H:%M:%S")
            self.playlists_changed.emit()

        def err(exc):
            self.status_text = describe_error(exc)
            self.playlists_changed.emit()
        if self.connected:
            run_async(self.service.playlists, ok, err, owner=self)

    # ---- управление ----
    def control(self, action: str, context_uri: str | None = None) -> None:
        if not self.connected:
            return
        # оптимистичное обновление play/pause — откатывается следующим опросом
        if self.state and action in ("play", "pause"):
            self.state["is_playing"] = action == "play"
            self.state["progress_ms"] = self._progress_now()
            self.state["fetched_at"] = time.monotonic()
            self.state_changed.emit()

        def err(exc):
            if isinstance(exc, PremiumRequired):
                self.status, self.status_text = "premium", str(exc)
            elif isinstance(exc, NoActiveDevice):
                self.status, self.status_text = "idle", str(exc)
            else:
                self.status_text = describe_error(exc)
            self.error.emit(self.status_text)
            self.state_changed.emit()
        run_async(lambda: self.service.control(action, context_uri), lambda _r: QTimer.singleShot(500, self.poll),
                  err, owner=self)

    def toggle_play(self) -> None:
        playing = bool(self.state and self.state.get("is_playing"))
        self.control("pause" if playing else "play")

    def _progress_now(self) -> int:
        s = self.state
        if not s:
            return 0
        p = s["progress_ms"]
        if s.get("is_playing"):
            p += int((time.monotonic() - s["fetched_at"]) * 1000)
        return min(p, s.get("duration_ms") or p)

    def progress_now(self) -> int:
        return self._progress_now()
