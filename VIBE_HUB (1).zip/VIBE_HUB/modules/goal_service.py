"""Авто-обновление целей из данных модулей (FACEIT / трекер). Без Qt."""
from __future__ import annotations

from modules import stats
from modules.goals import AUTO_METRICS, auto_value


def build_context(repos, faceit_overview: dict | None, source: str = "all") -> dict:
    ms = repos.matches.list(source=None if source == "all" else source)
    return {"faceit": faceit_overview or {}, "tracker": stats.summarize(ms)}


def sync_auto_goals(repos, ctx: dict) -> list[dict]:
    """Обновляет цели с авто-метрикой. Возвращает список целей, выполненных ИМЕННО сейчас."""
    done: list[dict] = []
    for g in repos.goals.list(status=None):
        metric = g["metric"]
        if metric == "manual" or metric not in AUTO_METRICS:
            continue
        val = auto_value(metric, ctx)
        if val is None:
            continue
        val = round(float(val), 2)
        if abs(val - g["current_value"]) < 1e-9:
            continue
        if repos.goals.set_current(g["id"], val, note="авто"):
            done.append(repos.goals.get(g["id"]))
    for g in done:
        repos.activity.add("goal", f"Цель выполнена: {g['title']}", ref=str(g["id"]))
    return done
