"""Бизнес-логика FACEIT (без Qt): привязка профиля, обновление, импорт матчей, ELO-снимки."""
from __future__ import annotations

import logging
from datetime import datetime

from api import faceit_api as fapi
from api.http import ApiError
from utils import secrets as sec
from utils.timeutil import parse_iso
from utils.i18n import _

log = logging.getLogger("vibehub.faceit")
MIN_REFRESH_SECONDS = 60  # не чаще раза в минуту (лимиты API)


class FaceitService:
    def __init__(self, repos, settings, store: sec.SecretStore, client_factory=None):
        self.r = repos
        self.settings = settings
        self.store = store
        self._factory = client_factory or (lambda key: fapi.FaceitClient(key))

    # ---- состояние ----
    def api_key(self) -> str | None:
        return self.store.get(sec.FACEIT_API_KEY)

    def has_key(self) -> bool:
        return bool(self.api_key())

    def account(self) -> dict | None:
        return self.r.accounts.get("faceit")

    def is_linked(self) -> bool:
        return self.account() is not None

    def _client(self):
        key = self.api_key()
        if not key:
            raise ApiError(_("Укажите FACEIT API Key (Подключённые аккаунты → FACEIT)."))
        return self._factory(key)

    def set_api_key(self, key: str) -> None:
        key = key.strip()
        if key:
            self.store.set(sec.FACEIT_API_KEY, key)
        else:
            self.store.delete(sec.FACEIT_API_KEY)

    # ---- подключение ----
    def search(self, nickname: str) -> list[dict]:
        return [{"nickname": p.get("nickname"), "player_id": p.get("player_id"), "country": p.get("country"),
                 "level": next((g.get("skill_level") for k, g in (p.get("games") or {}).items() if k == "cs2"), None)}
                for p in self._client().search_players(nickname)]

    def link(self, nickname: str) -> dict:
        nickname = nickname.strip()
        if not nickname:
            raise ApiError(_("Введите FACEIT nickname."))
        p = fapi.parse_player(self._client().player_by_nickname(nickname))
        self.r.accounts.upsert("faceit", external_id=p["player_id"], username=p["nickname"],
                               avatar_url=p["avatar"], profile_url=p["profile_url"],
                               extra={"country": p["country"], "region": p["region"]}, touch_connected=True)
        self.settings.set("faceit_nickname", p["nickname"])
        self.r.activity.add("account", f"FACEIT подключён: {p['nickname']}")
        return p

    def disconnect(self, delete_key: bool = True, delete_matches: bool = True) -> None:
        self.r.accounts.delete("faceit")
        self.r.snapshots.clear()
        self.r.cache.clear("faceit:")
        if delete_matches:
            self.r.db.execute("DELETE FROM matches WHERE source='faceit'")
        if delete_key:
            self.store.delete(sec.FACEIT_API_KEY)
        self.settings.set("faceit_nickname", "")
        self.r.activity.add("account", "FACEIT отключён")

    # ---- обновление ----
    def refresh(self, force: bool = False) -> dict:
        acc = self.account()
        if not acc:
            raise ApiError(_("FACEIT не подключён."))
        meta = self.r.cache.get("faceit:meta")
        if not force and meta:
            age = (datetime.now() - parse_iso(meta[1])).total_seconds()
            if age < MIN_REFRESH_SECONDS:
                return self.overview()
        c = self._client()
        pid = acc["external_id"]
        player = fapi.parse_player(c.player(pid))
        lifetime = fapi.parse_lifetime(c.player_stats(pid))
        first_sync = not self.r.db.query_one("SELECT 1 FROM matches WHERE source='faceit' LIMIT 1")
        raw: list[dict] = []
        for offset in ((0, 100) if first_sync else (0,)):
            page = c.match_stats(pid, limit=100, offset=offset)
            raw.extend(page)
            if len(page) < 100:
                break
        imported = 0
        with self.r.db.tx():
            for item in raw:
                m = fapi.parse_match(item)
                if m:
                    ext = m.pop("external_id")
                    imported += 1 if self.r.matches.upsert_external("faceit", ext, **m) else 0
        self.r.snapshots.add(elo=player["elo"], level=player["level"], matches=lifetime["matches"],
                             wins=lifetime["wins"], win_rate=lifetime["win_rate"], kd=lifetime["kd"],
                             hs_pct=lifetime["hs_pct"])
        self.r.cache.set("faceit:player", player)
        self.r.cache.set("faceit:lifetime", lifetime)
        self.r.cache.set("faceit:meta", {"imported": imported})
        self.r.accounts.upsert("faceit", username=player["nickname"], avatar_url=player["avatar"],
                               profile_url=player["profile_url"])
        if imported:
            self.r.activity.add("faceit", f"FACEIT: импортировано матчей — {imported}")
        return self.overview()

    # ---- данные для UI (из БД/кэша, без сети) ----
    def elo_change(self) -> dict | None:
        """Изменение ELO между двумя последними РАЗНЫМИ значениями локальных снимков."""
        snaps = [s for s in self.r.snapshots.since(None) if s["elo"] is not None]
        if len(snaps) < 2:
            return None
        last = snaps[-1]
        for prev in reversed(snaps[:-1]):
            if prev["elo"] != last["elo"]:
                return {"delta": last["elo"] - prev["elo"], "since": prev["ts"]}
        return None

    def overview(self) -> dict:
        acc = self.account()
        if not acc:
            return {"linked": False, "has_key": self.has_key()}
        player = (self.r.cache.get("faceit:player") or ({}, None))[0]
        lifetime_c = self.r.cache.get("faceit:lifetime")
        lifetime = lifetime_c[0] if lifetime_c else {}
        recent = self.r.matches.list(source="faceit", limit=10)
        last30 = self.r.matches.list(source="faceit", limit=30)
        avg_kills = (sum(m["kills"] for m in last30) / len(last30)) if last30 else None
        return {
            "linked": True, "has_key": self.has_key(), "nickname": acc["username"], "avatar": acc["avatar_url"],
            "profile_url": acc["profile_url"], "country": (acc.get("extra") or {}).get("country"),
            "level": player.get("level"), "elo": player.get("elo"),
            "matches": lifetime.get("matches"), "wins": lifetime.get("wins"), "losses": lifetime.get("losses"),
            "win_rate": lifetime.get("win_rate"), "kd": lifetime.get("kd"), "hs_pct": lifetime.get("hs_pct"),
            "win_streak": lifetime.get("win_streak"), "recent_results": lifetime.get("recent_results", []),
            "avg_kills": avg_kills, "avg_kills_n": len(last30),
            "elo_change": self.elo_change(), "recent": recent,
            "updated_at": lifetime_c[1] if lifetime_c else None,
        }
