"""Фоновые задачи: функция выполняется в QThreadPool, результат доставляется в GUI-поток.

Доставка идёт через QObject-диспетчер, живущий в GUI-потоке (очередь событий Qt), поэтому
обработчики on_ok/on_err всегда вызываются в GUI-потоке и безопасно трогают виджеты.
"""
from __future__ import annotations

import logging
import threading
from typing import Any, Callable

from PySide6.QtCore import QObject, QRunnable, QThreadPool, Signal, Slot

try:
    from shiboken6 import isValid as _is_valid
except Exception:  # pragma: no cover
    def _is_valid(_o) -> bool:
        return True

log = logging.getLogger("vibehub.workers")


class CancelToken:
    def __init__(self):
        self._ev = threading.Event()

    def cancel(self) -> None:
        self._ev.set()

    @property
    def cancelled(self) -> bool:
        return self._ev.is_set()

    __call__ = lambda self: self._ev.is_set()  # noqa: E731  (токен можно передавать как cancelled=token)


class _Dispatcher(QObject):
    call = Signal(object)

    def __init__(self):
        super().__init__()
        self.call.connect(self._run)

    @Slot(object)
    def _run(self, fn) -> None:
        try:
            fn()
        except Exception:
            log.exception("Ошибка в обработчике результата фоновой задачи")


_dispatcher: _Dispatcher | None = None
_pool: QThreadPool | None = None
_active: set = set()
_closing = False


def init(max_threads: int = 6) -> None:
    """Вызывается один раз из GUI-потока после создания QApplication."""
    global _dispatcher, _pool, _closing
    _dispatcher = _Dispatcher()
    _pool = QThreadPool()
    _pool.setMaxThreadCount(max_threads)
    _closing = False


def post(fn: Callable[[], Any]) -> None:
    """Выполнить fn в GUI-потоке (можно вызывать из любого потока)."""
    if _dispatcher is not None and not _closing:
        _dispatcher.call.emit(fn)


class _Task(QRunnable):
    def __init__(self, fn, on_ok, on_err, owner):
        super().__init__()
        self.setAutoDelete(False)
        self.fn, self.on_ok, self.on_err, self.owner = fn, on_ok, on_err, owner

    def run(self) -> None:
        try:
            result = self.fn()
        except BaseException as exc:  # noqa: BLE001 — любые сбои уходят в on_err, поток не падает
            log.debug("Фоновая задача завершилась ошибкой: %s", type(exc).__name__)
            post(lambda e=exc: self._deliver(self.on_err, e, is_err=True))
        else:
            post(lambda r=result: self._deliver(self.on_ok, r, is_err=False))
        finally:
            _active.discard(self)

    def _deliver(self, cb, value, is_err: bool) -> None:
        if self.owner is not None and not _is_valid(self.owner):
            return  # виджет уже уничтожен
        if cb is not None:
            cb(value)
        elif is_err:
            log.error("Необработанная ошибка фоновой задачи: %r", value)


def run_async(fn: Callable[[], Any], on_ok: Callable[[Any], None] | None = None,
              on_err: Callable[[BaseException], None] | None = None, owner: QObject | None = None) -> None:
    if _pool is None or _closing:
        return
    task = _Task(fn, on_ok, on_err, owner)
    _active.add(task)
    _pool.start(task)


def shutdown(timeout_ms: int = 4000) -> None:
    global _closing
    _closing = True
    if _pool is not None:
        _pool.clear()
        _pool.waitForDone(timeout_ms)


def describe_error(exc: BaseException) -> str:
    """Человекочитаемое сообщение. Секреты в текст не попадают."""
    from api.http import ApiError
    from api.oauth_server import OAuthError
    if isinstance(exc, (ApiError, OAuthError)):
        return str(exc)
    log.error("Непредвиденная ошибка", exc_info=exc)
    return f"Непредвиденная ошибка ({type(exc).__name__}). Подробности в журнале."
