"""Шина событий приложения: слабая связность между модулями."""
from __future__ import annotations

from PySide6.QtCore import QObject, Signal


class Bus(QObject):
    sensors = Signal(object)            # modules.sensors.Snapshot
    matches_changed = Signal()
    goals_changed = Signal()
    activity_changed = Signal()
    accounts_changed = Signal()
    theme_changed = Signal()
    settings_changed = Signal(str, object)
    navigate = Signal(str)              # id страницы
    request_action = Signal(str)        # 'add_match', 'create_goal'
    notified = Signal(str, str, str)    # kind, title, text — показать toast
