"""Мониторинг ПК в отдельном потоке: UI не блокируется, история пишется в SQLite."""
from __future__ import annotations

import logging
import time
from collections import deque

from PySide6.QtCore import QObject, QThread, Signal, Slot

from modules.polling import WatchCounter, poll_interval_ms
from modules.sensors import SensorReader, Snapshot

log = logging.getLogger("vibehub.monitor")
HISTORY_LEN = 600          # точек в памяти для графиков
DB_WRITE_EVERY = 10.0      # секунд между записями в БД


class _MonitorThread(QThread):
    raw = Signal(object)

    def __init__(self, service: "MonitorService"):
        super().__init__()
        self.svc = service

    def run(self) -> None:
        try:
            reader = SensorReader()
        except Exception:
            log.exception("Не удалось запустить мониторинг")
            return
        last_db = 0.0
        last_prune = 0.0
        while not self.isInterruptionRequested():
            t0 = time.monotonic()
            if not self.svc.paused:
                try:
                    snap = reader.read()
                    self.raw.emit(snap)
                    now = time.monotonic()
                    if self.svc.record and now - last_db >= DB_WRITE_EVERY:
                        last_db = now
                        self.svc.repo.add(snap.as_history())
                        if now - last_prune > 3600 or last_prune == 0.0:
                            last_prune = now
                            self.svc.repo.prune(7)
                except Exception:
                    log.exception("Ошибка опроса датчиков")
            # интервал пересчитывается на каждом шаге ожидания: открыли Dashboard — следующее чтение будет сразу
            while time.monotonic() - t0 < self.svc.effective_interval() / 1000.0 and not self.isInterruptionRequested():
                self.msleep(50)


class MonitorService(QObject):
    snapshot = Signal(object)

    def __init__(self, pc_repo, interval_ms: int = 1000, record: bool = True):
        super().__init__()
        self.repo = pc_repo
        self.interval_ms = max(250, int(interval_ms))
        self.record = record
        self.paused = False
        self.background = False          # окно свёрнуто — опрашиваем реже, но запись истории продолжается
        self._watch = WatchCounter()     # сколько видимых страниц показывают живые данные
        self.latest: Snapshot | None = None
        self.history: deque[Snapshot] = deque(maxlen=HISTORY_LEN)
        self._thread: _MonitorThread | None = None

    @property
    def watchers(self) -> int:
        return self._watch.count

    def watch(self) -> None:
        """Страница с живыми показаниями стала видимой."""
        self._watch.watch()

    def unwatch(self) -> None:
        self._watch.unwatch()

    def effective_interval(self) -> int:
        return poll_interval_ms(self.interval_ms, background=self.background, watchers=self._watch.count, record=self.record)

    def set_interval(self, ms: int) -> None:
        self.interval_ms = max(250, int(ms))

    def start(self) -> None:
        if self._thread is not None:
            return
        self._thread = _MonitorThread(self)
        self._thread.raw.connect(self._on_raw)
        self._thread.start()

    def stop(self) -> None:
        if self._thread is None:
            return
        self._thread.requestInterruption()
        self._thread.wait(5000)
        self._thread = None

    @Slot(object)
    def _on_raw(self, snap: Snapshot) -> None:
        self.latest = snap
        self.history.append(snap)
        self.snapshot.emit(snap)
