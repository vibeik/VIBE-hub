"""Точка расширения: автоматический импорт матчей CS2.

Сейчас автоматический источник один — FACEIT (см. faceit_service.refresh). Чтобы добавить новый
(например, Steam Game State Integration, разбор демо или другой сервис), реализуйте MatchImporter
и вызовите run_import — матчи попадут в общий трекер с пометкой источника и без дублей.
"""
from __future__ import annotations

from abc import ABC, abstractmethod
from typing import Iterable


class MatchImporter(ABC):
    #: короткое имя источника, пишется в matches.source
    source: str = ""

    @abstractmethod
    def fetch(self) -> Iterable[dict]:
        """Вернуть матчи в формате: external_id, played_at('YYYY-MM-DD HH:MM:SS'), map, result('win'|'loss'|'draw'),
        kills, deaths, assists, [headshot_pct], [score]."""


def run_import(match_repo, importer: MatchImporter) -> int:
    added = 0
    for m in importer.fetch():
        m = dict(m)
        ext = str(m.pop("external_id"))
        if match_repo.upsert_external(importer.source, ext, **m):
            added += 1
    return added
