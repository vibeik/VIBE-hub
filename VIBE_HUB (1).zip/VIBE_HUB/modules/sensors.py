"""Сбор показателей ПК. Всё, что получить нельзя, возвращается как None — данные не выдумываются.

Источники:
- CPU/RAM/диски/сеть — psutil;
- температура CPU — psutil.sensors_temperatures() (на Windows обычно недоступно) и
  WMI MSAcpi_ThermalZone (через PowerShell; на многих ПК отсутствует или не отражает температуру CPU);
- GPU: NVIDIA — nvidia-smi (идёт с драйвером), загрузка/температура/VRAM;
  остальные GPU — счётчики Windows «GPU Engine» (только загрузка), температуры нет.
"""
from __future__ import annotations

import logging
import os
import re
import shutil
import subprocess
import time
from dataclasses import dataclass, field

import psutil
from utils.i18n import _

log = logging.getLogger("vibehub.sensors")

_NO_WINDOW = getattr(subprocess, "CREATE_NO_WINDOW", 0)


@dataclass
class Snapshot:
    ts: float = 0.0
    cpu: float | None = None
    cpu_per_core: list[float] = field(default_factory=list)
    cpu_freq_mhz: float | None = None
    cpu_temp: float | None = None
    cpu_temp_note: str = ""
    ram: float | None = None
    ram_used: int = 0
    ram_total: int = 0
    gpu: float | None = None
    gpu_name: str | None = None
    gpu_temp: float | None = None
    vram_used_mb: float | None = None
    vram_total_mb: float | None = None
    gpu_note: str = ""
    disks: list[dict] = field(default_factory=list)   # {mount,total,used,free,percent}
    disk_percent: float | None = None                 # системный диск
    disk_read_bps: float | None = None
    disk_write_bps: float | None = None
    net_down_bps: float | None = None
    net_up_bps: float | None = None

    def as_history(self) -> dict:
        return {"cpu": self.cpu, "ram": self.ram, "gpu": self.gpu, "cpu_temp": self.cpu_temp,
                "gpu_temp": self.gpu_temp, "disk": self.disk_percent,
                "net_down": self.net_down_bps, "net_up": self.net_up_bps}


# ---------------- GPU ----------------
def parse_nvidia_smi(output: str) -> dict | None:
    """Разбор `nvidia-smi --query-gpu=name,utilization.gpu,temperature.gpu,memory.used,memory.total --format=csv,noheader,nounits`."""
    line = next((l for l in output.strip().splitlines() if l.strip()), "")
    if not line:
        return None
    parts = [p.strip() for p in line.split(",")]
    if len(parts) < 5:
        return None

    def num(s: str) -> float | None:
        try:
            return float(s)
        except ValueError:
            return None  # "[N/A]", "[Not Supported]"

    return {"name": parts[0], "util": num(parts[1]), "temp": num(parts[2]),
            "mem_used": num(parts[3]), "mem_total": num(parts[4])}


def _find_nvidia_smi() -> str | None:
    p = shutil.which("nvidia-smi")
    if p:
        return p
    for cand in (r"C:\Windows\System32\nvidia-smi.exe",
                 os.path.join(os.environ.get("ProgramFiles", r"C:\Program Files"), "NVIDIA Corporation", "NVSMI", "nvidia-smi.exe")):
        if os.path.exists(cand):
            return cand
    return None


def read_nvidia(exe: str | None = None) -> dict | None:
    exe = exe or _find_nvidia_smi()
    if not exe:
        return None
    try:
        out = subprocess.run(
            [exe, "--query-gpu=name,utilization.gpu,temperature.gpu,memory.used,memory.total",
             "--format=csv,noheader,nounits"],
            capture_output=True, text=True, timeout=3, creationflags=_NO_WINDOW)
        if out.returncode != 0:
            return None
        return parse_nvidia_smi(out.stdout)
    except (OSError, subprocess.SubprocessError):
        return None


def parse_gpu_engine_total(output: str) -> float | None:
    """Сумма значений счётчиков по движку 3D (по экземплярам) -> загрузка 0..100."""
    total = 0.0
    seen = False
    for line in output.splitlines():
        m = re.match(r"\s*([0-9]+(?:[.,][0-9]+)?)\s*$", line)
        if m:
            total += float(m.group(1).replace(",", "."))
            seen = True
    return min(100.0, total) if seen else None


def read_windows_gpu_engine() -> float | None:
    """Загрузка любого GPU через счётчики Windows (AMD/Intel). Только Windows."""
    if os.name != "nt":
        return None
    ps = ("(Get-Counter '\\GPU Engine(*engtype_3D)\\Utilization Percentage' -ErrorAction Stop)"
          ".CounterSamples | ForEach-Object { $_.CookedValue }")
    try:
        out = subprocess.run(["powershell", "-NoProfile", "-NonInteractive", "-Command", ps],
                             capture_output=True, text=True, timeout=5, creationflags=_NO_WINDOW)
        if out.returncode != 0:
            return None
        return parse_gpu_engine_total(out.stdout)
    except (OSError, subprocess.SubprocessError):
        return None


# ---------------- CPU temp ----------------
def read_cpu_temp() -> tuple[float | None, str]:
    """Возвращает (температура, пояснение, если недоступна)."""
    try:
        fn = getattr(psutil, "sensors_temperatures", None)
        if fn:
            data = fn()
            for key in ("coretemp", "k10temp", "cpu_thermal", "zenpower", "acpitz"):
                if key in data and data[key]:
                    vals = [t.current for t in data[key] if t.current]
                    if vals:
                        return max(vals), ""
    except Exception:
        log.debug("psutil.sensors_temperatures не сработал", exc_info=True)
    if os.name == "nt":
        t = _wmi_thermal_zone()
        if t is not None:
            return t, ""
        return None, _("Windows не предоставляет температуру CPU без драйвера датчиков")
    return None, _("Датчик температуры недоступен")


# PowerShell дорог (старт процесса — сотни миллисекунд процессора). Если датчика нет, повторять запрос каждые
# 10 с бессмысленно, поэтому после неудач пауза растёт: 10 с (успех) → 60 → 300 → 900 с.
_WMI_RETRY_S = (60.0, 300.0, 900.0)
_wmi_state = {"next": 0.0, "val": None, "fails": 0}


def wmi_backoff(fails: int) -> float:
    """Пауза до следующей попытки после `fails` подряд неудачных запросов (0 — последний был успешным)."""
    if fails <= 0:
        return 10.0
    return _WMI_RETRY_S[min(fails, len(_WMI_RETRY_S)) - 1]


def _wmi_thermal_zone() -> float | None:
    now = time.monotonic()
    if now < _wmi_state["next"]:
        return _wmi_state["val"]
    ps = ("Get-CimInstance -Namespace root/wmi -ClassName MSAcpi_ThermalZoneTemperature -ErrorAction Stop | "
          "ForEach-Object { [math]::Round(($_.CurrentTemperature / 10) - 273.15, 1) }")
    vals: list[float] = []
    try:
        out = subprocess.run(["powershell", "-NoProfile", "-NonInteractive", "-Command", ps],
                             capture_output=True, text=True, timeout=5, creationflags=_NO_WINDOW)
        for l in out.stdout.splitlines():
            try:
                v = float(l.strip().replace(",", "."))
                if 5 < v < 125:  # отсекаем заведомо мусорные значения
                    vals.append(v)
            except ValueError:
                pass
    except (OSError, subprocess.SubprocessError):
        pass
    _wmi_state["val"] = max(vals) if vals else None
    _wmi_state["fails"] = 0 if vals else _wmi_state["fails"] + 1
    _wmi_state["next"] = time.monotonic() + wmi_backoff(_wmi_state["fails"])
    return _wmi_state["val"]


# ---------------- Ограничитель частоты ----------------
class Throttle:
    """Решает, пора ли снова вызывать дорогой источник данных.

    Пауза не короче `base_s` и не короче `factor` × длительность последнего вызова (но не длиннее `max_s`):
    чем дороже вызов, тем реже он повторяется, поэтому доля процессорного времени остаётся небольшой.
    """

    def __init__(self, base_s: float, factor: float = 10.0, max_s: float = 60.0):
        self.base_s, self.factor, self.max_s = base_s, factor, max_s
        self._next = 0.0

    def due(self, now: float) -> bool:
        return now >= self._next

    def done(self, now: float, cost_s: float) -> None:
        self._next = now + min(self.max_s, max(self.base_s, cost_s * self.factor))

    def reset(self) -> None:
        self._next = 0.0


GPU_NVIDIA_EVERY_S = 2.0      # nvidia-smi: ~50–100 мс на вызов
GPU_ENGINE_EVERY_S = 6.0      # PowerShell Get-Counter: сотни миллисекунд на вызов
GPU_NONE_EVERY_S = 60.0       # датчиков GPU нет вообще — проверяем изредка (драйвер могли поставить позже)
DISKS_EVERY_S = 10.0          # список дисков и их заполнение меняются медленно


# ---------------- Основной сборщик ----------------
class SensorReader:
    """Не потокобезопасен: используется из одного рабочего потока."""

    def __init__(self):
        psutil.cpu_percent(None)  # прогрев
        self._last_net = psutil.net_io_counters()
        self._last_disk = psutil.disk_io_counters()
        self._last_t = time.time()
        self._gpu_cache: dict | None = None
        self._gpu_throttle = Throttle(GPU_NVIDIA_EVERY_S)
        self._nv_exe: str | None = None
        self._nv_checked = False
        self._disks_throttle = Throttle(DISKS_EVERY_S, factor=0.0)
        self._disks_cache: list[dict] = []
        self._disk_percent_cache: float | None = None
        self._sys_drive = os.environ.get("SystemDrive", "C:") + "\\" if os.name == "nt" else "/"

    def read(self) -> Snapshot:
        s = Snapshot(ts=time.time())
        s.cpu = psutil.cpu_percent(None)
        s.cpu_per_core = psutil.cpu_percent(None, percpu=True)
        try:
            f = psutil.cpu_freq()
            s.cpu_freq_mhz = f.current if f else None
        except Exception:
            pass
        vm = psutil.virtual_memory()
        s.ram, s.ram_used, s.ram_total = vm.percent, vm.used, vm.total

        # диски: перечисление разделов и disk_usage на каждом тике не нужны (и могут зависать на сетевых дисках)
        mono = time.monotonic()
        if self._disks_throttle.due(mono):
            self._disks_cache, self._disk_percent_cache = self._read_disks()
            self._disks_throttle.done(time.monotonic(), 0.0)
        s.disks = list(self._disks_cache)
        s.disk_percent = self._disk_percent_cache

        # скорости IO/сети
        now = time.time()
        dt = max(now - self._last_t, 1e-3)
        net = psutil.net_io_counters()
        if net and self._last_net:
            s.net_down_bps = max(0.0, (net.bytes_recv - self._last_net.bytes_recv) / dt)
            s.net_up_bps = max(0.0, (net.bytes_sent - self._last_net.bytes_sent) / dt)
        try:
            dio = psutil.disk_io_counters()
            if dio and self._last_disk:
                s.disk_read_bps = max(0.0, (dio.read_bytes - self._last_disk.read_bytes) / dt)
                s.disk_write_bps = max(0.0, (dio.write_bytes - self._last_disk.write_bytes) / dt)
            self._last_disk = dio
        except Exception:
            pass
        self._last_net, self._last_t = net, now

        # температура CPU (дорогие вызовы кэшируются внутри)
        s.cpu_temp, s.cpu_temp_note = read_cpu_temp()

        # GPU — дорогие внешние вызовы: по времени и с учётом их стоимости, между опросами берём кэш
        mono = time.monotonic()
        if self._gpu_throttle.due(mono):
            t0 = time.monotonic()
            self._gpu_cache = self._read_gpu()
            cost = time.monotonic() - t0
            self._gpu_throttle.base_s = self._gpu_interval(self._gpu_cache)
            self._gpu_throttle.done(time.monotonic(), cost)
        g = self._gpu_cache or {}
        s.gpu, s.gpu_name, s.gpu_temp = g.get("util"), g.get("name"), g.get("temp")
        s.vram_used_mb, s.vram_total_mb = g.get("mem_used"), g.get("mem_total")
        s.gpu_note = g.get("note", "") if s.gpu is None else ""
        if s.gpu is None and not s.gpu_note:
            s.gpu_note = _("Датчики GPU недоступны (нужен драйвер NVIDIA или Windows 10/11 с поддержкой GPU Engine)")
        return s

    def _read_disks(self) -> tuple[list[dict], float | None]:
        disks: list[dict] = []
        for part in psutil.disk_partitions(all=False):
            if os.name == "nt" and ("cdrom" in part.opts or part.fstype == ""):
                continue
            try:
                u = psutil.disk_usage(part.mountpoint)
            except (PermissionError, OSError):
                continue
            disks.append({"mount": part.mountpoint, "total": u.total, "used": u.used, "free": u.free, "percent": u.percent})
        try:
            percent: float | None = psutil.disk_usage(self._sys_drive).percent
        except Exception:
            percent = disks[0]["percent"] if disks else None
        return disks, percent

    @staticmethod
    def _gpu_interval(g: dict | None) -> float:
        """Базовая пауза между опросами GPU по тому, какой источник сработал."""
        if not g:
            return GPU_NONE_EVERY_S
        if g.get("name"):                  # nvidia-smi
            return GPU_NVIDIA_EVERY_S
        return GPU_ENGINE_EVERY_S          # счётчики Windows через PowerShell

    def _read_gpu(self) -> dict:
        if not self._nv_checked:           # путь к nvidia-smi ищем один раз
            self._nv_exe = _find_nvidia_smi()
            self._nv_checked = True
        if self._nv_exe:
            nv = read_nvidia(self._nv_exe)
            if nv:
                return nv
        util = read_windows_gpu_engine()
        if util is not None:
            return {"util": util, "name": None, "temp": None, "mem_used": None, "mem_total": None,
                    "note": _("Температура и VRAM доступны только для NVIDIA")}
        return {}
