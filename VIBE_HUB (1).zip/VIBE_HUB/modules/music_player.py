"""Локальный музыкальный плеер на Qt Multimedia. Источник отдельный от Spotify."""
from __future__ import annotations

import logging
import os

from PySide6.QtCore import QObject, QUrl, Signal
from PySide6.QtMultimedia import QAudioOutput, QMediaPlayer

from modules.playqueue import PlayQueue

log = logging.getLogger("vibehub.player")


class MusicPlayer(QObject):
    track_changed = Signal(object)        # dict | None
    playing_changed = Signal(bool)
    position_changed = Signal(int, int)   # позиция, длительность (мс)
    queue_changed = Signal()
    error = Signal(str)

    def __init__(self, ctx):
        super().__init__()
        self.ctx = ctx
        self.repo = ctx.repos.music
        self.queue = PlayQueue()
        self.queue.shuffle = bool(ctx.settings.get("music_shuffle"))
        self.queue.set_repeat(ctx.settings.get("music_repeat") or "off")
        self.current: dict | None = None
        self._audio = QAudioOutput()
        self._player = QMediaPlayer()
        self._player.setAudioOutput(self._audio)
        self.set_volume(int(ctx.settings.get("music_volume") or 70), save=False)
        self._player.positionChanged.connect(self._on_pos)
        self._player.durationChanged.connect(self._on_dur)
        self._player.mediaStatusChanged.connect(self._on_status)
        self._player.playbackStateChanged.connect(self._on_state)
        self._player.errorOccurred.connect(self._on_error)
        self._skipped = 0

    # ---- состояние ----
    @property
    def is_playing(self) -> bool:
        return self._player.playbackState() == QMediaPlayer.PlaybackState.PlayingState

    @property
    def volume(self) -> int:
        return int(self.ctx.settings.get("music_volume") or 0)

    def position(self) -> int:
        return int(self._player.position())

    def duration(self) -> int:
        return int(self._player.duration())

    # ---- управление ----
    def play_tracks(self, ids: list[int], start_id: int | None = None) -> None:
        self.queue.set_queue(ids, start_id)
        self.queue_changed.emit()
        self._skipped = 0
        self._load_current(autoplay=True)

    def toggle(self) -> None:
        if self.is_playing:
            self._player.pause()
        elif self.current is not None:
            self._player.play()
        elif self.queue.current is not None:
            self._load_current(autoplay=True)

    def stop(self) -> None:
        self._player.stop()

    def next(self, auto: bool = False) -> None:
        nid = self.queue.next(auto=auto)
        if nid is None:
            self._player.stop()
            self.position_changed.emit(0, self.duration())
            return
        self._load_current(autoplay=True)

    def previous(self) -> None:
        if self.position() > 3000:       # как в большинстве плееров: сначала в начало трека
            self._player.setPosition(0)
            return
        self.queue.prev()
        self._load_current(autoplay=True)

    def seek(self, ms: int) -> None:
        self._player.setPosition(max(0, int(ms)))

    def set_volume(self, vol: int, save: bool = True) -> None:
        vol = max(0, min(100, int(vol)))
        self._audio.setVolume((vol / 100.0) ** 2)     # квадратичная шкала ближе к восприятию громкости
        if save:
            self.ctx.settings.set("music_volume", vol, notify=False)

    def set_shuffle(self, on: bool) -> None:
        self.queue.set_shuffle(on)
        self.ctx.settings.set("music_shuffle", on, notify=False)

    def set_repeat(self, mode: str) -> None:
        self.queue.set_repeat(mode)
        self.ctx.settings.set("music_repeat", self.queue.repeat, notify=False)

    # ---- внутреннее ----
    def _load_current(self, autoplay: bool) -> None:
        tid = self.queue.current
        track = self.repo.get_track(tid) if tid is not None else None
        if track is None:
            self.current = None
            self.track_changed.emit(None)
            return
        if not os.path.exists(track["path"]):
            self.error.emit(f"Файл не найден: {os.path.basename(track['path'])}")
            self._skip_broken()
            return
        self.current = track
        self._player.setSource(QUrl.fromLocalFile(track["path"]))
        self.track_changed.emit(track)
        if autoplay:
            self._player.play()

    def _skip_broken(self) -> None:
        self._skipped += 1
        if self._skipped >= max(1, len(self.queue)):
            self._skipped = 0
            self._player.stop()
            return
        nid = self.queue.next()
        if nid is not None:
            self._load_current(autoplay=True)

    def _on_pos(self, pos: int) -> None:
        self.position_changed.emit(int(pos), self.duration())

    def _on_dur(self, dur: int) -> None:
        self.position_changed.emit(self.position(), int(dur))

    def _on_status(self, status) -> None:
        if status == QMediaPlayer.MediaStatus.EndOfMedia:
            self.next(auto=True)
        elif status == QMediaPlayer.MediaStatus.LoadedMedia:
            self._skipped = 0

    def _on_state(self, _state) -> None:
        self.playing_changed.emit(self.is_playing)

    def _on_error(self, _err, text: str) -> None:
        name = os.path.basename(self.current["path"]) if self.current else ""
        log.warning("Ошибка воспроизведения %s: %s", name, text)
        self.error.emit(f"Не удалось воспроизвести «{name}»: {text}" if name else f"Ошибка плеера: {text}")
        self._skip_broken()

    def shutdown(self) -> None:
        try:
            self._player.stop()
            self._player.setSource(QUrl())
        except Exception:
            pass
