"""Логика целей без Qt."""
from __future__ import annotations

CATEGORIES = ["FACEIT", "CS2", "Steam", "YouTube", "Музыка", "Личное", "Другое"]

# Метрики, которые приложение умеет обновлять само из данных модулей.
# key -> (подпись, единица)
AUTO_METRICS = {
    "manual": ("Вручную", ""),
    "faceit_elo": ("FACEIT ELO (авто)", "ELO"),
    "faceit_level": ("FACEIT Level (авто)", "lvl"),
    "tracker_kd": ("Средний K/D в трекере (авто)", "K/D"),
    "tracker_matches": ("Матчей в трекере (авто)", "матчей"),
    "tracker_winrate": ("Win Rate в трекере (авто)", "%"),
}


def is_reached(start: float, current: float, target: float) -> bool:
    """Цель может быть как «вырасти до X», так и «снизиться до X» — направление по start/target."""
    if target >= start:
        return current >= target
    return current <= target


def progress_ratio(start: float, current: float, target: float) -> float:
    """Доля выполнения 0..1."""
    span = target - start
    if span == 0:
        return 1.0 if is_reached(start, current, target) else 0.0
    ratio = (current - start) / span
    return max(0.0, min(1.0, ratio))


def progress_percent(start: float, current: float, target: float) -> int:
    return int(round(progress_ratio(start, current, target) * 100))


def fmt_value(v: float) -> str:
    if float(v).is_integer():
        return str(int(v))
    return f"{v:.2f}".rstrip("0").rstrip(".")


def auto_value(metric: str, ctx: dict) -> float | None:
    """Значение авто-метрики из контекста {'faceit': {...}, 'tracker': {...}}; None — данных нет."""
    f = ctx.get("faceit") or {}
    t = ctx.get("tracker") or {}
    if metric == "faceit_elo":
        return f.get("elo")
    if metric == "faceit_level":
        return f.get("level")
    if metric == "tracker_kd":
        return t.get("kd") if t.get("matches") else None
    if metric == "tracker_matches":
        return t.get("matches") if t.get("matches") else None
    if metric == "tracker_winrate":
        return t.get("win_rate") if t.get("matches") else None
    return None
