"""Данные для графиков Dashboard/FACEIT/трекера (без Qt, считается из БД)."""
from __future__ import annotations

from datetime import date, timedelta

from modules import stats
from utils.timeutil import day_start, last_n_days, parse_iso, period_start


def _source(src: str) -> str | None:
    return None if src in (None, "", "all") else src


def weekly(repos, source: str = "all", days: int = 7, today: date | None = None) -> dict:
    """Серии за последние `days` дней: матчи/победы/поражения по дням, K/D по дням."""
    t = today or date.today()
    ms = repos.matches.list(date_from=day_start(t - timedelta(days=days - 1)), source=_source(source))
    per_day = stats.by_day(ms, days, t)
    labels = [d for d in per_day]
    return {
        "days": labels,
        "matches": [s["matches"] for s in per_day.values()],
        "wins": [s["wins"] for s in per_day.values()],
        "losses": [s["losses"] for s in per_day.values()],
        "kd": [s["kd"] for s in per_day.values()],            # None — день без матчей
        "total": stats.summarize(ms),
    }


def elo_series(repos, days: int = 30) -> list[tuple[float, float]]:
    """(timestamp, elo) из локальных снимков FACEIT."""
    since = day_start(date.today() - timedelta(days=days - 1))
    out = []
    for s in repos.snapshots.since(since):
        if s["elo"] is not None:
            out.append((parse_iso(s["ts"]).timestamp(), float(s["elo"])))
    return out


def goals_completed(repos, days: int = 7, today: date | None = None) -> dict:
    t = today or date.today()
    per_day = repos.goals.completed_per_day(day_start(t - timedelta(days=days - 1)))
    ds = last_n_days(days, t)
    return {"days": ds, "completed": [per_day.get(d.isoformat(), 0) for d in ds]}


def overview(repos, source: str = "all") -> dict:
    ms = repos.matches.list(source=_source(source))
    return {"all": stats.summarize(ms), "week": stats.summarize(
        [m for m in ms if parse_iso(m["played_at"]) >= period_start("week")])}
