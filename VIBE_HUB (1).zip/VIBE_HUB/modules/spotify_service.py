"""Бизнес-логика Spotify (без Qt): вход OAuth PKCE, состояние плеера, управление, плейлисты."""
from __future__ import annotations

import logging
import secrets as pysecrets
import webbrowser
from typing import Callable

from api import spotify_api as sp
from api.http import ApiError, AuthError, HttpClient
from api.oauth_server import CallbackServer
from utils import secrets as sec
from utils.i18n import _

log = logging.getLogger("vibehub.spotify")


class SpotifyService:
    def __init__(self, repos, settings, store: sec.SecretStore, http: HttpClient | None = None):
        self.r = repos
        self.settings = settings
        self.store = store
        self._http = http or HttpClient(min_interval=0.1)
        self._playlist_names: dict[str, str] = {}

    # ---- состояние ----
    def client_id(self) -> str:
        return (self.settings.get("spotify_client_id") or "").strip()

    def port(self) -> int:
        try:
            return int(self.settings.get("spotify_port") or 8888)
        except (TypeError, ValueError):
            return 8888

    def redirect_uri(self) -> str:
        return f"http://127.0.0.1:{self.port()}/callback"

    def _client(self) -> sp.SpotifyClient:
        cid = self.client_id()
        if not cid:
            raise ApiError(_("Укажите Spotify Client ID (Подключённые аккаунты → Spotify)."))
        return sp.SpotifyClient(cid, self.store, self._http)

    def account(self) -> dict | None:
        return self.r.accounts.get("spotify")

    def is_connected(self) -> bool:
        return self.account() is not None and bool(self.store.get(sec.SPOTIFY_REFRESH) or self.store.get(sec.SPOTIFY_ACCESS))

    # ---- подключение ----
    def connect(self, cancelled: Callable[[], bool] | None = None, timeout: float = 180,
                open_browser: Callable[[str], object] = webbrowser.open) -> dict:
        client = self._client()
        verifier, challenge = sp.make_pkce()
        state = pysecrets.token_urlsafe(16)
        uri = self.redirect_uri()
        with CallbackServer(self.port(), "/callback") as srv:
            open_browser(sp.build_auth_url(client.client_id, uri, challenge, state))
            params = srv.wait(timeout, cancelled)
        if params.get("error"):
            raise AuthError(_("Spotify: вход отменён или отклонён") +
                            (_(" (проверьте, что Redirect URI в Dashboard совпадает: ") + uri + ")"
                             if params["error"] == "invalid_redirect_uri" else "."))
        if params.get("state") != state:
            raise AuthError(_("Spotify: не совпал параметр state — вход отклонён из соображений безопасности."))
        if not params.get("code"):
            raise AuthError(_("Spotify не вернул код авторизации."))
        client.exchange_code(params["code"], verifier, uri)
        me = client.me()
        self.r.accounts.upsert("spotify", external_id=me.get("id"), username=me.get("display_name") or me.get("id"),
                               avatar_url=((me.get("images") or [{}])[0] or {}).get("url"),
                               profile_url=(me.get("external_urls") or {}).get("spotify"), touch_connected=True)
        self.r.activity.add("account", "Spotify подключён")
        return self.account() or {}

    def disconnect(self) -> None:
        """Токены удаляются локально (у Spotify нет endpoint'а отзыва — см. README)."""
        try:
            sp.SpotifyClient(self.client_id() or "-", self.store, self._http).clear_tokens()
        finally:
            self.r.accounts.delete("spotify")
            self.r.cache.clear("spotify:")
            self._playlist_names.clear()
            self.r.activity.add("account", "Spotify отключён")

    # ---- плеер ----
    def playback(self) -> dict | None:
        return self._client().playback(self._playlist_names)

    def control(self, action: str, context_uri: str | None = None) -> None:
        c = self._client()
        if action == "play":
            c.play(context_uri)
        elif action == "pause":
            c.pause()
        elif action == "next":
            c.next()
        elif action == "previous":
            c.previous()
        else:
            raise ValueError(action)

    def playlists(self) -> list[dict]:
        items = self._client().playlists()
        self._playlist_names = {p["uri"]: p["name"] for p in items if p.get("uri")}
        self.r.cache.set("spotify:playlists", items)
        return items

    def cached_playlists(self) -> tuple[list[dict], str | None]:
        c = self.r.cache.get("spotify:playlists")
        if c:
            self._playlist_names = {p["uri"]: p["name"] for p in c[0] if p.get("uri")}
        return (c[0], c[1]) if c else ([], None)
