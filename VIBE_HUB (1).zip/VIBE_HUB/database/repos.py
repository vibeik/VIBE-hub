"""Репозитории: тонкий слой над SQLite. Без Qt — полностью тестируется отдельно."""
from __future__ import annotations

import json
from datetime import datetime
from typing import Any, Iterable

from database.db import Database
from utils.timeutil import now_iso, to_iso


def _row(r) -> dict[str, Any] | None:
    return dict(r) if r is not None else None


# ======================= MATCHES =======================
class MatchRepo:
    FIELDS = ("source", "external_id", "map", "played_at", "result", "kills", "deaths",
              "assists", "headshot_pct", "score", "notes")

    def __init__(self, db: Database):
        self.db = db

    def add(self, **m) -> int:
        ts = now_iso()
        data = {"source": "manual", "external_id": None, "map": "", "assists": 0,
                "headshot_pct": None, "score": None, "notes": ""}
        data.update(m)
        self._validate(data)
        cols = list(self.FIELDS)
        return self.db.execute(
            f"INSERT INTO matches({','.join(cols)},created_at,updated_at) VALUES({','.join('?' * len(cols))},?,?)",
            [data.get(c) for c in cols] + [ts, ts])

    def upsert_external(self, source: str, external_id: str, **m) -> bool:
        """Вставляет внешний матч, если его ещё нет. True — если добавлен новый."""
        exists = self.db.query_one("SELECT id FROM matches WHERE source=? AND external_id=?", (source, external_id))
        if exists:
            return False
        self.add(source=source, external_id=external_id, **m)
        return True

    def update(self, match_id: int, **fields) -> None:
        cur = self.get(match_id)
        if cur is None:
            raise KeyError(match_id)
        cur.update({k: v for k, v in fields.items() if k in self.FIELDS})
        self._validate(cur)
        sets = ",".join(f"{c}=?" for c in self.FIELDS)
        self.db.execute(f"UPDATE matches SET {sets}, updated_at=? WHERE id=?",
                        [cur[c] for c in self.FIELDS] + [now_iso(), match_id])

    def delete(self, match_id: int) -> bool:
        return self.db.execute_rowcount("DELETE FROM matches WHERE id=?", (match_id,)) > 0

    def get(self, match_id: int) -> dict | None:
        return _row(self.db.query_one("SELECT * FROM matches WHERE id=?", (match_id,)))

    def list(self, date_from: datetime | None = None, date_to: datetime | None = None,
             source: str | None = None, map_name: str | None = None, newest_first: bool = True,
             limit: int | None = None) -> list[dict]:
        where, params = [], []
        if date_from is not None:
            where.append("played_at >= ?")
            params.append(to_iso(date_from))
        if date_to is not None:
            where.append("played_at <= ?")
            params.append(to_iso(date_to))
        if source and source != "all":
            where.append("source = ?")
            params.append(source)
        if map_name:
            where.append("map = ?")
            params.append(map_name)
        sql = "SELECT * FROM matches"
        if where:
            sql += " WHERE " + " AND ".join(where)
        sql += " ORDER BY played_at " + ("DESC" if newest_first else "ASC") + ", id " + ("DESC" if newest_first else "ASC")
        if limit:
            sql += f" LIMIT {int(limit)}"
        return [dict(r) for r in self.db.query(sql, params)]

    def maps(self) -> list[str]:
        return [r[0] for r in self.db.query("SELECT DISTINCT map FROM matches WHERE map<>'' ORDER BY map")]

    @staticmethod
    def _validate(m: dict) -> None:
        if m.get("result") not in ("win", "loss", "draw"):
            raise ValueError("result должен быть win, loss или draw")
        for k in ("kills", "deaths", "assists"):
            if int(m.get(k) or 0) < 0:
                raise ValueError(f"{k} не может быть отрицательным")
            m[k] = int(m.get(k) or 0)
        if not m.get("played_at"):
            raise ValueError("не указана дата матча")


# ======================= GOALS =======================
class GoalRepo:
    def __init__(self, db: Database):
        self.db = db

    def create(self, title: str, target: float, *, description: str = "", category: str = "Другое",
               metric: str = "manual", unit: str = "", start: float | None = None,
               current: float | None = None) -> int:
        title = title.strip()
        if not title:
            raise ValueError("Название цели не может быть пустым")
        cur = 0.0 if current is None else float(current)
        st = cur if start is None else float(start)
        ts = now_iso()
        with self.db.tx():
            gid = self.db.execute(
                "INSERT INTO goals(title,description,category,metric,unit,start_value,current_value,target_value,created_at)"
                " VALUES(?,?,?,?,?,?,?,?,?)",
                (title, description.strip(), category, metric, unit, st, cur, float(target), ts))
            self._log(gid, "created", None, title)
        return gid

    def get(self, gid: int) -> dict | None:
        return _row(self.db.query_one("SELECT * FROM goals WHERE id=?", (gid,)))

    def list(self, status: str | None = None) -> list[dict]:
        if status:
            rows = self.db.query("SELECT * FROM goals WHERE status=? ORDER BY created_at DESC, id DESC", (status,))
        else:
            rows = self.db.query("SELECT * FROM goals ORDER BY status ASC, created_at DESC, id DESC")
        return [dict(r) for r in rows]

    def update(self, gid: int, **fields) -> None:
        allowed = {"title", "description", "category", "metric", "unit", "start_value", "current_value", "target_value"}
        cur = self.get(gid)
        if cur is None:
            raise KeyError(gid)
        with self.db.tx():
            for k, v in fields.items():
                if k not in allowed:
                    continue
                if k == "title" and not str(v).strip():
                    raise ValueError("Название цели не может быть пустым")
                if cur[k] != v:
                    self.db.execute(f"UPDATE goals SET {k}=? WHERE id=?", (v, gid))
                    self._log(gid, k, cur[k], v)

    def set_current(self, gid: int, value: float, note: str = "") -> bool:
        """Обновляет текущее значение. Возвращает True, если цель только что выполнена."""
        from modules.goals import is_reached  # локальный импорт, чтобы не было циклов

        g = self.get(gid)
        if g is None:
            raise KeyError(gid)
        value = float(value)
        just_done = False
        with self.db.tx():
            if g["current_value"] != value:
                self.db.execute("UPDATE goals SET current_value=? WHERE id=?", (value, gid))
                self._log(gid, "current_value", g["current_value"], value, note)
            g["current_value"] = value
            if g["status"] == "active" and is_reached(g["start_value"], value, g["target_value"]):
                self.db.execute("UPDATE goals SET status='completed', completed_at=? WHERE id=?", (now_iso(), gid))
                self._log(gid, "status", "active", "completed", note)
                just_done = True
            elif g["status"] == "completed" and not is_reached(g["start_value"], value, g["target_value"]):
                self.db.execute("UPDATE goals SET status='active', completed_at=NULL WHERE id=?", (gid,))
                self._log(gid, "status", "completed", "active", note)
        return just_done

    def delete(self, gid: int) -> bool:
        return self.db.execute_rowcount("DELETE FROM goals WHERE id=?", (gid,)) > 0

    def history(self, gid: int) -> list[dict]:
        return [dict(r) for r in self.db.query(
            "SELECT * FROM goal_history WHERE goal_id=? ORDER BY changed_at DESC, id DESC", (gid,))]

    def completed_per_day(self, since: datetime) -> dict[str, int]:
        rows = self.db.query(
            "SELECT substr(completed_at,1,10) d, COUNT(*) c FROM goals WHERE completed_at>=? GROUP BY d", (to_iso(since),))
        return {r["d"]: r["c"] for r in rows}

    def _log(self, gid: int, field: str, old, new, note: str = "") -> None:
        self.db.execute(
            "INSERT INTO goal_history(goal_id,changed_at,field,old_value,new_value,note) VALUES(?,?,?,?,?,?)",
            (gid, now_iso(), field, None if old is None else str(old), None if new is None else str(new), note))


# ======================= ACTIVITY =======================
class ActivityRepo:
    def __init__(self, db: Database):
        self.db = db

    def add(self, kind: str, text: str, ref: str | None = None) -> None:
        self.db.execute("INSERT INTO activity(ts,kind,text,ref) VALUES(?,?,?,?)", (now_iso(), kind, text, ref))
        self.db.execute("DELETE FROM activity WHERE id NOT IN (SELECT id FROM activity ORDER BY id DESC LIMIT 500)")

    def recent(self, limit: int = 20) -> list[dict]:
        return [dict(r) for r in self.db.query("SELECT * FROM activity ORDER BY id DESC LIMIT ?", (limit,))]


# ======================= ACCOUNTS =======================
class AccountRepo:
    def __init__(self, db: Database):
        self.db = db

    def get(self, service: str) -> dict | None:
        r = _row(self.db.query_one("SELECT * FROM accounts WHERE service=?", (service,)))
        if r and r.get("extra"):
            try:
                r["extra"] = json.loads(r["extra"])
            except ValueError:
                r["extra"] = {}
        elif r:
            r["extra"] = {}
        return r

    def upsert(self, service: str, *, external_id=None, username=None, avatar_url=None, profile_url=None,
               extra: dict | None = None, touch_connected: bool = False) -> None:
        cur = self.get(service)
        ts = now_iso()
        if cur is None:
            self.db.execute(
                "INSERT INTO accounts(service,external_id,username,avatar_url,profile_url,extra,connected_at,updated_at)"
                " VALUES(?,?,?,?,?,?,?,?)",
                (service, external_id, username, avatar_url, profile_url, json.dumps(extra or {}), ts, ts))
            return
        merged_extra = dict(cur.get("extra") or {})
        if extra:
            merged_extra.update(extra)
        self.db.execute(
            "UPDATE accounts SET external_id=?,username=?,avatar_url=?,profile_url=?,extra=?,connected_at=?,updated_at=? WHERE service=?",
            (external_id if external_id is not None else cur["external_id"],
             username if username is not None else cur["username"],
             avatar_url if avatar_url is not None else cur["avatar_url"],
             profile_url if profile_url is not None else cur["profile_url"],
             json.dumps(merged_extra), ts if touch_connected else cur["connected_at"], ts, service))

    def delete(self, service: str) -> None:
        self.db.execute("DELETE FROM accounts WHERE service=?", (service,))


# ======================= FACEIT snapshots =======================
class SnapshotRepo:
    def __init__(self, db: Database):
        self.db = db

    def add(self, *, elo, level, matches, wins, win_rate, kd, hs_pct) -> None:
        """Пишет снимок. Дубли подряд (ничего не изменилось) не сохраняются."""
        last = self.last()
        if last and all(last[k] == v for k, v in
                        (("elo", elo), ("level", level), ("matches", matches), ("wins", wins))):
            return
        self.db.execute(
            "INSERT INTO faceit_snapshots(ts,elo,level,matches,wins,win_rate,kd,hs_pct) VALUES(?,?,?,?,?,?,?,?)",
            (now_iso(), elo, level, matches, wins, win_rate, kd, hs_pct))

    def last(self) -> dict | None:
        return _row(self.db.query_one("SELECT * FROM faceit_snapshots ORDER BY id DESC LIMIT 1"))

    def since(self, dt: datetime | None = None) -> list[dict]:
        if dt is None:
            rows = self.db.query("SELECT * FROM faceit_snapshots ORDER BY id")
        else:
            rows = self.db.query("SELECT * FROM faceit_snapshots WHERE ts>=? ORDER BY id", (to_iso(dt),))
        return [dict(r) for r in rows]

    def clear(self) -> None:
        self.db.execute("DELETE FROM faceit_snapshots")


# ======================= STEAM games =======================
class SteamRepo:
    def __init__(self, db: Database):
        self.db = db

    def replace_games(self, games: Iterable[dict]) -> None:
        ts = now_iso()
        with self.db.tx():
            self.db.execute("DELETE FROM steam_games")
            self.db.executemany(
                "INSERT OR REPLACE INTO steam_games(appid,name,playtime_forever,playtime_2weeks,icon_hash,last_played,updated_at)"
                " VALUES(?,?,?,?,?,?,?)",
                [(g["appid"], g.get("name") or f"App {g['appid']}", g.get("playtime_forever", 0),
                  g.get("playtime_2weeks", 0), g.get("img_icon_url"), g.get("rtime_last_played"), ts) for g in games])

    def games(self, limit: int | None = None, order: str = "playtime_forever") -> list[dict]:
        if order not in ("playtime_forever", "playtime_2weeks", "name"):
            order = "playtime_forever"
        sql = f"SELECT * FROM steam_games ORDER BY {order} {'ASC' if order == 'name' else 'DESC'}"
        if limit:
            sql += f" LIMIT {int(limit)}"
        return [dict(r) for r in self.db.query(sql)]

    def recent(self, limit: int = 5) -> list[dict]:
        return [dict(r) for r in self.db.query(
            "SELECT * FROM steam_games WHERE playtime_2weeks>0 ORDER BY playtime_2weeks DESC LIMIT ?", (limit,))]

    def clear(self) -> None:
        self.db.execute("DELETE FROM steam_games")


# ======================= MUSIC =======================
class MusicRepo:
    def __init__(self, db: Database):
        self.db = db

    # folders
    def folders(self) -> list[str]:
        return [r[0] for r in self.db.query("SELECT path FROM music_folders ORDER BY path")]

    def add_folder(self, path: str) -> None:
        self.db.execute("INSERT OR IGNORE INTO music_folders(path) VALUES(?)", (path,))

    def remove_folder(self, path: str) -> None:
        with self.db.tx():
            self.db.execute("DELETE FROM tracks WHERE folder=?", (path,))
            self.db.execute("DELETE FROM music_folders WHERE path=?", (path,))

    # tracks
    def upsert_track(self, t: dict) -> bool:
        """True — если трек новый."""
        ex = self.db.query_one("SELECT id FROM tracks WHERE path=?", (t["path"],))
        if ex:
            self.db.execute(
                "UPDATE tracks SET folder=?,title=?,artist=?,album=?,duration_ms=?,cover=?,mtime=? WHERE id=?",
                (t["folder"], t["title"], t["artist"], t["album"], t["duration_ms"], t.get("cover"), t["mtime"], ex["id"]))
            return False
        self.db.execute(
            "INSERT INTO tracks(path,folder,title,artist,album,duration_ms,cover,mtime,added_at) VALUES(?,?,?,?,?,?,?,?,?)",
            (t["path"], t["folder"], t["title"], t["artist"], t["album"], t["duration_ms"], t.get("cover"), t["mtime"], now_iso()))
        return True

    def track_mtimes(self, folder: str) -> dict[str, float]:
        return {r["path"]: r["mtime"] for r in self.db.query("SELECT path,mtime FROM tracks WHERE folder=?", (folder,))}

    def remove_paths(self, paths: Iterable[str]) -> None:
        self.db.executemany("DELETE FROM tracks WHERE path=?", [(p,) for p in paths])

    def tracks(self, search: str = "") -> list[dict]:
        if search.strip():
            like = f"%{search.strip()}%"
            rows = self.db.query(
                "SELECT * FROM tracks WHERE title LIKE ? OR artist LIKE ? OR album LIKE ? ORDER BY artist, album, title",
                (like, like, like))
        else:
            rows = self.db.query("SELECT * FROM tracks ORDER BY artist, album, title")
        return [dict(r) for r in rows]

    def get_track(self, tid: int) -> dict | None:
        return _row(self.db.query_one("SELECT * FROM tracks WHERE id=?", (tid,)))

    def count_tracks(self) -> int:
        return self.db.query_one("SELECT COUNT(*) FROM tracks")[0]

    # playlists
    def playlists(self) -> list[dict]:
        return [dict(r) for r in self.db.query(
            "SELECT p.*, (SELECT COUNT(*) FROM playlist_tracks pt WHERE pt.playlist_id=p.id) AS count "
            "FROM playlists p ORDER BY p.name")]

    def create_playlist(self, name: str) -> int:
        name = name.strip()
        if not name:
            raise ValueError("Название плейлиста не может быть пустым")
        return self.db.execute("INSERT INTO playlists(name,created_at) VALUES(?,?)", (name, now_iso()))

    def rename_playlist(self, pid: int, name: str) -> None:
        self.db.execute("UPDATE playlists SET name=? WHERE id=?", (name.strip(), pid))

    def delete_playlist(self, pid: int) -> None:
        self.db.execute("DELETE FROM playlists WHERE id=?", (pid,))

    def playlist_tracks(self, pid: int) -> list[dict]:
        return [dict(r) for r in self.db.query(
            "SELECT t.* FROM playlist_tracks pt JOIN tracks t ON t.id=pt.track_id WHERE pt.playlist_id=? ORDER BY pt.position",
            (pid,))]

    def add_to_playlist(self, pid: int, track_ids: Iterable[int]) -> int:
        added = 0
        with self.db.tx():
            pos = self.db.query_one("SELECT COALESCE(MAX(position),-1) FROM playlist_tracks WHERE playlist_id=?", (pid,))[0]
            for tid in track_ids:
                if self.db.query_one("SELECT 1 FROM playlist_tracks WHERE playlist_id=? AND track_id=?", (pid, tid)):
                    continue
                pos += 1
                self.db.execute("INSERT INTO playlist_tracks(playlist_id,track_id,position) VALUES(?,?,?)", (pid, tid, pos))
                added += 1
        return added

    def remove_from_playlist(self, pid: int, track_id: int) -> None:
        self.db.execute("DELETE FROM playlist_tracks WHERE playlist_id=? AND track_id=?", (pid, track_id))


# ======================= PC history =======================
class PCHistoryRepo:
    def __init__(self, db: Database):
        self.db = db

    def add(self, s: dict) -> None:
        self.db.execute(
            "INSERT INTO pc_history(ts,cpu,ram,gpu,cpu_temp,gpu_temp,disk,net_down,net_up) VALUES(?,?,?,?,?,?,?,?,?)",
            (now_iso(), s.get("cpu"), s.get("ram"), s.get("gpu"), s.get("cpu_temp"), s.get("gpu_temp"),
             s.get("disk"), s.get("net_down"), s.get("net_up")))

    def since(self, dt: datetime) -> list[dict]:
        return [dict(r) for r in self.db.query("SELECT * FROM pc_history WHERE ts>=? ORDER BY ts", (to_iso(dt),))]

    def prune(self, keep_days: int = 7) -> None:
        from datetime import timedelta
        self.db.execute("DELETE FROM pc_history WHERE ts < ?", (to_iso(datetime.now() - timedelta(days=keep_days)),))

    def clear(self) -> None:
        self.db.execute("DELETE FROM pc_history")


# ======================= HTTP cache =======================
class CacheRepo:
    def __init__(self, db: Database):
        self.db = db

    def get(self, key: str) -> tuple[Any, str] | None:
        r = self.db.query_one("SELECT payload,fetched_at FROM cache WHERE key=?", (key,))
        if r is None:
            return None
        try:
            return json.loads(r["payload"]), r["fetched_at"]
        except ValueError:
            return None

    def set(self, key: str, payload: Any) -> str:
        ts = now_iso()
        self.db.execute("INSERT OR REPLACE INTO cache(key,payload,fetched_at) VALUES(?,?,?)",
                        (key, json.dumps(payload, ensure_ascii=False), ts))
        return ts

    def clear(self, prefix: str = "") -> None:
        if prefix:
            self.db.execute("DELETE FROM cache WHERE key LIKE ?", (prefix + "%",))
        else:
            self.db.execute("DELETE FROM cache")


# ======================= контейнер =======================
class Repos:
    """Все репозитории вместе — передаётся в сервисы и UI."""

    def __init__(self, db: Database):
        self.db = db
        self.matches = MatchRepo(db)
        self.goals = GoalRepo(db)
        self.activity = ActivityRepo(db)
        self.accounts = AccountRepo(db)
        self.snapshots = SnapshotRepo(db)
        self.steam = SteamRepo(db)
        self.music = MusicRepo(db)
        self.pc = PCHistoryRepo(db)
        self.cache = CacheRepo(db)
