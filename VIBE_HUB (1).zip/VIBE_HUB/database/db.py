"""SQLite: подключение, миграции, бэкап/восстановление, восстановление после сбоя."""
from __future__ import annotations

import logging
import shutil
import sqlite3
import threading
from contextlib import contextmanager
from datetime import datetime
from pathlib import Path

log = logging.getLogger("vibehub.db")

SCHEMA_V1 = """
CREATE TABLE matches(
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    source TEXT NOT NULL DEFAULT 'manual',
    external_id TEXT,
    map TEXT NOT NULL DEFAULT '',
    played_at TEXT NOT NULL,
    result TEXT NOT NULL CHECK(result IN ('win','loss','draw')),
    kills INTEGER NOT NULL CHECK(kills >= 0),
    deaths INTEGER NOT NULL CHECK(deaths >= 0),
    assists INTEGER NOT NULL DEFAULT 0 CHECK(assists >= 0),
    headshot_pct REAL,
    score TEXT,
    notes TEXT NOT NULL DEFAULT '',
    created_at TEXT NOT NULL,
    updated_at TEXT NOT NULL,
    UNIQUE(source, external_id)
);
CREATE INDEX idx_matches_played ON matches(played_at);

CREATE TABLE goals(
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    title TEXT NOT NULL,
    description TEXT NOT NULL DEFAULT '',
    category TEXT NOT NULL DEFAULT 'Другое',
    metric TEXT NOT NULL DEFAULT 'manual',
    unit TEXT NOT NULL DEFAULT '',
    start_value REAL NOT NULL DEFAULT 0,
    current_value REAL NOT NULL DEFAULT 0,
    target_value REAL NOT NULL,
    status TEXT NOT NULL DEFAULT 'active' CHECK(status IN ('active','completed')),
    created_at TEXT NOT NULL,
    completed_at TEXT
);

CREATE TABLE goal_history(
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    goal_id INTEGER NOT NULL REFERENCES goals(id) ON DELETE CASCADE,
    changed_at TEXT NOT NULL,
    field TEXT NOT NULL,
    old_value TEXT,
    new_value TEXT,
    note TEXT NOT NULL DEFAULT ''
);
CREATE INDEX idx_goal_history_goal ON goal_history(goal_id);

CREATE TABLE activity(
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    ts TEXT NOT NULL,
    kind TEXT NOT NULL,
    text TEXT NOT NULL,
    ref TEXT
);
CREATE INDEX idx_activity_ts ON activity(ts);

CREATE TABLE accounts(
    service TEXT PRIMARY KEY,
    external_id TEXT,
    username TEXT,
    avatar_url TEXT,
    profile_url TEXT,
    extra TEXT,
    connected_at TEXT,
    updated_at TEXT
);

CREATE TABLE faceit_snapshots(
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    ts TEXT NOT NULL,
    elo INTEGER,
    level INTEGER,
    matches INTEGER,
    wins INTEGER,
    win_rate REAL,
    kd REAL,
    hs_pct REAL
);
CREATE INDEX idx_faceit_snap_ts ON faceit_snapshots(ts);

CREATE TABLE steam_games(
    appid INTEGER PRIMARY KEY,
    name TEXT NOT NULL,
    playtime_forever INTEGER NOT NULL DEFAULT 0,
    playtime_2weeks INTEGER NOT NULL DEFAULT 0,
    icon_hash TEXT,
    last_played INTEGER,
    updated_at TEXT NOT NULL
);

CREATE TABLE music_folders(path TEXT PRIMARY KEY);

CREATE TABLE tracks(
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    path TEXT NOT NULL UNIQUE,
    folder TEXT NOT NULL,
    title TEXT NOT NULL,
    artist TEXT NOT NULL DEFAULT '',
    album TEXT NOT NULL DEFAULT '',
    duration_ms INTEGER NOT NULL DEFAULT 0,
    cover TEXT,
    mtime REAL NOT NULL DEFAULT 0,
    added_at TEXT NOT NULL
);
CREATE INDEX idx_tracks_title ON tracks(title);

CREATE TABLE playlists(
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL UNIQUE,
    created_at TEXT NOT NULL
);

CREATE TABLE playlist_tracks(
    playlist_id INTEGER NOT NULL REFERENCES playlists(id) ON DELETE CASCADE,
    track_id INTEGER NOT NULL REFERENCES tracks(id) ON DELETE CASCADE,
    position INTEGER NOT NULL,
    PRIMARY KEY(playlist_id, track_id)
);

CREATE TABLE pc_history(
    ts TEXT NOT NULL,
    cpu REAL, ram REAL, gpu REAL, cpu_temp REAL, gpu_temp REAL,
    disk REAL, net_down REAL, net_up REAL
);
CREATE INDEX idx_pc_history_ts ON pc_history(ts);

CREATE TABLE cache(
    key TEXT PRIMARY KEY,
    payload TEXT NOT NULL,
    fetched_at TEXT NOT NULL
);
"""

# Миграции: старые НЕ редактировать, изменения схемы — новым элементом списка.
MIGRATIONS = [SCHEMA_V1]
SCHEMA_VERSION = len(MIGRATIONS)
REQUIRED_TABLES = {"matches", "goals", "tracks", "accounts", "cache"}


class DatabaseError(Exception):
    pass


class Database:
    def __init__(self, path: Path | str):
        self.path = Path(path)
        self._lock = threading.RLock()
        self._conn: sqlite3.Connection | None = None
        self.recovered_from: str | None = None
        self.open()

    # -- подключение ------------------------------------------------------
    def open(self) -> None:
        with self._lock:
            self._conn = self._connect(self.path)
            try:
                self._migrate()
            except BaseException:
                self._conn.close()
                self._conn = None
                raise

    @staticmethod
    def _connect(path: Path | str) -> sqlite3.Connection:
        conn = sqlite3.connect(str(path), check_same_thread=False, isolation_level=None, timeout=10)
        conn.row_factory = sqlite3.Row
        conn.execute("PRAGMA foreign_keys = ON")
        try:
            conn.execute("PRAGMA journal_mode = WAL")
        except sqlite3.DatabaseError:
            pass
        conn.execute("PRAGMA synchronous = NORMAL")
        return conn

    def close(self) -> None:
        with self._lock:
            if self._conn is not None:
                self._conn.close()
                self._conn = None

    @classmethod
    def open_with_recovery(cls, path: Path | str, backup_dir: Path | str) -> "Database":
        """Открывает БД; при повреждении переименовывает файл и поднимает последний авто-бэкап."""
        path, backup_dir = Path(path), Path(backup_dir)
        try:
            db = cls(path)
            row = db.query_one("PRAGMA quick_check")
            if row is not None and list(row)[0] != "ok":
                db.close()
                raise sqlite3.DatabaseError("quick_check не пройден")
            return db
        except sqlite3.DatabaseError as exc:
            log.error("БД повреждена (%s) — запускаю восстановление", exc)

        stamp = datetime.now().strftime("%Y%m%d-%H%M%S")
        if path.exists():
            bad = path.with_name(f"{path.name}.corrupt-{stamp}")
            try:
                path.replace(bad)
            except OSError:
                pass
        for ext in ("-wal", "-shm"):
            side = Path(str(path) + ext)
            if side.exists():
                try:
                    side.unlink()
                except OSError:
                    pass

        backups = sorted(backup_dir.glob("auto-*.db"), reverse=True) if backup_dir.exists() else []
        msg = "База данных была повреждена. Создана новая пустая база."
        for b in backups:
            try:
                shutil.copy2(b, path)
                db = cls(path)
                row = db.query_one("PRAGMA quick_check")
                if row is not None and list(row)[0] == "ok":
                    db.recovered_from = f"База данных была повреждена и восстановлена из резервной копии {b.name}."
                    return db
                db.close()
                path.unlink(missing_ok=True)
            except Exception:  # noqa: BLE001
                log.exception("Бэкап %s не подошёл", b)
                path.unlink(missing_ok=True)
        db = cls(path)
        db.recovered_from = msg
        return db

    # -- миграции ---------------------------------------------------------
    def _migrate(self) -> None:
        assert self._conn is not None
        with self._lock:
            ver = self._conn.execute("PRAGMA user_version").fetchone()[0]
            if ver > SCHEMA_VERSION:
                raise DatabaseError(f"БД создана более новой версией приложения (schema v{ver}).")
            while ver < SCHEMA_VERSION:
                script = MIGRATIONS[ver]
                self._conn.executescript("BEGIN;\n" + script + f"\nPRAGMA user_version = {ver + 1};\nCOMMIT;")
                ver += 1
                log.info("Миграция БД до версии %d", ver)

    # -- запросы ----------------------------------------------------------
    @contextmanager
    def tx(self):
        """Транзакция: COMMIT при успехе, ROLLBACK при любом исключении."""
        assert self._conn is not None
        with self._lock:
            self._conn.execute("BEGIN")
            try:
                yield self
                self._conn.execute("COMMIT")
            except BaseException:
                self._conn.execute("ROLLBACK")
                raise

    def execute(self, sql: str, params=()) -> int | None:
        """Выполняет запись, возвращает lastrowid."""
        assert self._conn is not None
        with self._lock:
            cur = self._conn.execute(sql, params)
            return cur.lastrowid

    def execute_rowcount(self, sql: str, params=()) -> int:
        assert self._conn is not None
        with self._lock:
            return self._conn.execute(sql, params).rowcount

    def executemany(self, sql: str, seq) -> None:
        assert self._conn is not None
        with self._lock:
            self._conn.executemany(sql, seq)

    def query(self, sql: str, params=()) -> list[sqlite3.Row]:
        assert self._conn is not None
        with self._lock:
            return list(self._conn.execute(sql, params).fetchall())

    def query_one(self, sql: str, params=()) -> sqlite3.Row | None:
        assert self._conn is not None
        with self._lock:
            return self._conn.execute(sql, params).fetchone()

    # -- бэкапы -----------------------------------------------------------
    def backup_to(self, dest: Path | str) -> Path:
        assert self._conn is not None
        dest = Path(dest)
        dest.parent.mkdir(parents=True, exist_ok=True)
        tmp = dest.with_suffix(dest.suffix + ".tmp")
        tmp.unlink(missing_ok=True)
        with self._lock:
            target = sqlite3.connect(str(tmp))
            try:
                self._conn.backup(target)
            finally:
                target.close()
        tmp.replace(dest)
        return dest

    def auto_backup(self, backup_dir: Path | str, keep: int = 7) -> Path | None:
        """Один авто-бэкап в сутки, хранится последние `keep` штук."""
        backup_dir = Path(backup_dir)
        backup_dir.mkdir(parents=True, exist_ok=True)
        target = backup_dir / f"auto-{datetime.now():%Y%m%d}.db"
        created: Path | None = None
        if not target.exists():
            created = self.backup_to(target)
        for old in sorted(backup_dir.glob("auto-*.db"), reverse=True)[keep:]:
            old.unlink(missing_ok=True)
        return created

    @staticmethod
    def validate_backup(path: Path | str) -> None:
        """Бросает DatabaseError, если файл — не рабочая БД VIBE HUB."""
        p = Path(path)
        if not p.is_file():
            raise DatabaseError("Файл не найден.")
        try:
            conn = sqlite3.connect(f"file:{p.as_posix()}?mode=ro", uri=True)
        except sqlite3.Error as exc:
            raise DatabaseError(f"Не удалось открыть файл: {exc}") from exc
        try:
            try:
                if conn.execute("PRAGMA integrity_check").fetchone()[0] != "ok":
                    raise DatabaseError("Файл повреждён (integrity_check не пройден).")
                tables = {r[0] for r in conn.execute("SELECT name FROM sqlite_master WHERE type='table'")}
                if not REQUIRED_TABLES <= tables:
                    raise DatabaseError("Это не резервная копия VIBE HUB (нет нужных таблиц).")
                ver = conn.execute("PRAGMA user_version").fetchone()[0]
                if ver > SCHEMA_VERSION:
                    raise DatabaseError("Копия создана более новой версией приложения.")
            except sqlite3.Error as exc:
                raise DatabaseError(f"Файл не является базой SQLite: {exc}") from exc
        finally:
            conn.close()

    def restore_from(self, src: Path | str, backup_dir: Path | str) -> None:
        """Заменяет содержимое БД содержимым копии. Перед этим делает страховочный бэкап."""
        assert self._conn is not None
        self.validate_backup(src)
        self.backup_to(Path(backup_dir) / f"pre-restore-{datetime.now():%Y%m%d-%H%M%S}.db")
        with self._lock:
            source = sqlite3.connect(f"file:{Path(src).as_posix()}?mode=ro", uri=True)
            try:
                source.backup(self._conn)
            finally:
                source.close()
            self._conn.execute("PRAGMA foreign_keys = ON")
            self._migrate()
