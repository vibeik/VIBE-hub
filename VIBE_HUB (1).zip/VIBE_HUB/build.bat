@echo off
setlocal
chcp 65001 >nul
cd /d "%~dp0"
echo ==== VIBE HUB: build EXE and installer ====

if not exist ".venv\Scripts\python.exe" (
    echo The environment is not installed yet - running install.bat ...
    call install.bat
    if errorlevel 1 exit /b 1
)

".venv\Scripts\python.exe" -m pip install -r requirements-dev.txt
if errorlevel 1 ( echo [ERROR] Could not install build tools. & pause & exit /b 1 )

echo Running tests ...
".venv\Scripts\python.exe" -m pytest -q
if errorlevel 1 echo [WARNING] Some tests failed - continuing the build. Please report them.

echo Building EXE ...
".venv\Scripts\python.exe" -m PyInstaller --noconfirm --clean VibeHub.spec
if errorlevel 1 ( echo [ERROR] PyInstaller failed. See messages above. & pause & exit /b 1 )

echo Smoke test of the built EXE ...
start /wait "" "dist\VibeHub\VibeHub.exe" --selftest
if errorlevel 1 echo [WARNING] The built EXE failed its self-test. Log: %%APPDATA%%\VibeHub\logs\vibehub.log - try launching dist\VibeHub\VibeHub.exe by hand.

".venv\Scripts\python.exe" -c "from config.settings import APP_VERSION; print(APP_VERSION)" > "%TEMP%\vibehub_ver.txt"
set /p VER=<"%TEMP%\vibehub_ver.txt"

set "ISCC="
if exist "%ProgramFiles(x86)%\Inno Setup 6\ISCC.exe" set "ISCC=%ProgramFiles(x86)%\Inno Setup 6\ISCC.exe"
if exist "%ProgramFiles%\Inno Setup 6\ISCC.exe" set "ISCC=%ProgramFiles%\Inno Setup 6\ISCC.exe"
if exist "%LOCALAPPDATA%\Programs\Inno Setup 6\ISCC.exe" set "ISCC=%LOCALAPPDATA%\Programs\Inno Setup 6\ISCC.exe"
if not defined ISCC goto noinstaller

echo Building installer ...
"%ISCC%" /DMyAppVersion=%VER% installer\VibeHub.iss
if errorlevel 1 ( echo [ERROR] Inno Setup failed. See messages above. & pause & exit /b 1 )
echo.
echo Installer: dist_installer\VibeHub-Setup-%VER%.exe
goto done

:noinstaller
echo.
echo Inno Setup 6 was not found, so the installer was skipped.
echo Install it from https://jrsoftware.org/isdl.php and run build.bat again.

:done
echo EXE folder: dist\VibeHub\VibeHub.exe
pause
