@echo off
setlocal EnableExtensions
chcp 65001 >nul
cd /d "%~dp0"
set "ROOT=%~dp0"
if "%ROOT:~-1%"=="\" set "ROOT=%ROOT:~0,-1%"
set "ALL="
if /i "%~1"=="/all" set "ALL=1"
set "DEL_DATA="
set "DEL_DIR="

echo ==== VIBE HUB: uninstall ====
echo.
echo This removes what VIBE HUB put on this computer:
echo   - the Windows autostart entry, if you enabled it
echo   - API keys and Spotify tokens saved in Windows Credential Manager
echo   - the cache of downloaded images and covers
echo   - the virtual environment .venv with the downloaded Python libraries
echo.
echo Optionally (you will be asked):
echo   - your data: database with goals and match history, settings, backups, logs
echo     in %%APPDATA%%\VibeHub
echo   - the program folder itself: %ROOT%
echo.
if not defined ALL goto :ask
echo Option /all: answering YES to everything.
set "DEL_DATA=1"
set "DEL_DIR=1"
goto :go

:ask
choice /c YN /n /m "Continue? [Y/N] "
if errorlevel 2 goto :cancel
choice /c YN /n /m "Also delete YOUR DATA (database, settings, backups, logs)? Cannot be undone. [Y/N] "
if not errorlevel 2 set "DEL_DATA=1"
choice /c YN /n /m "Also delete the program folder itself? [Y/N] "
if not errorlevel 2 set "DEL_DIR=1"
goto :go

:cancel
echo Cancelled. Nothing was removed.
pause
exit /b 1

:go
echo.
echo Closing VIBE HUB if it is running ...
set "VH_ROOT=%ROOT%"
powershell -NoProfile -ExecutionPolicy Bypass -Command "$r=$env:VH_ROOT; Get-CimInstance Win32_Process | Where-Object { ($_.ExecutablePath -and $_.ExecutablePath.StartsWith($r + '\', [StringComparison]::OrdinalIgnoreCase)) -or ($_.CommandLine -and $_.CommandLine.IndexOf($r + '\main.py', [StringComparison]::OrdinalIgnoreCase) -ge 0) } | ForEach-Object { Stop-Process -Id $_.ProcessId -Force -ErrorAction SilentlyContinue }" >nul 2>nul
timeout /t 2 /nobreak >nul

set "RC=0"
if not exist ".venv\Scripts\python.exe" goto :no_venv
echo Cleaning up ...
if defined DEL_DATA goto :clean_all
".venv\Scripts\python.exe" main.py --cleanup
set "RC=%errorlevel%"
goto :after_cleanup

:clean_all
".venv\Scripts\python.exe" main.py --cleanup --delete-data
set "RC=%errorlevel%"
goto :after_cleanup

:no_venv
echo [WARNING] The virtual environment .venv was not found, so saved keys cannot be removed automatically.
echo           Remove them by hand: Control Panel - Credential Manager - Windows Credentials,
echo           delete the entries that contain VibeHub.
reg delete "HKCU\Software\Microsoft\Windows\CurrentVersion\Run" /v VibeHub /f >nul 2>nul
if defined DEL_DATA if defined APPDATA if exist "%APPDATA%\VibeHub" rd /s /q "%APPDATA%\VibeHub"
if defined DEL_DATA if defined APPDATA if exist "%APPDATA%\VibeHub" set "RC=1"

:after_cleanup
if "%RC%"=="0" goto :remove_venv
echo.
echo [WARNING] Some steps failed (see above). Close VIBE HUB and run uninstall.bat again.
echo           The .venv folder and the program folder were left in place on purpose.
if not defined ALL pause
exit /b 1

:remove_venv
if not exist ".venv" goto :venv_done
echo Removing .venv ...
rd /s /q ".venv"
if exist ".venv" echo [WARNING] Could not remove .venv completely. Delete the folder by hand.

:venv_done
echo.
echo Done. VIBE HUB has been uninstalled.
if defined DEL_DIR goto :del_dir
echo The program folder was kept: %ROOT%
echo You can delete it by hand whenever you like.
if not defined ALL pause
exit /b 0

:del_dir
if not exist "%ROOT%\main.py" goto :not_ours
if not exist "%ROOT%\VibeHub.spec" goto :not_ours
if not defined ALL pause
cd /d "%TEMP%"
start "" /min cmd /c "ping -n 3 127.0.0.1 >nul & rd /s /q "%ROOT%""
exit /b 0

:not_ours
echo [WARNING] %ROOT% does not look like the VIBE HUB folder - it was not deleted.
if not defined ALL pause
exit /b 0
