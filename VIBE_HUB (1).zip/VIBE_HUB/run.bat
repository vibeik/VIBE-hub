@echo off
setlocal
cd /d "%~dp0"
if not exist ".venv\Scripts\python.exe" (
    echo The environment is not installed yet - running install.bat ...
    call install.bat
    if errorlevel 1 exit /b 1
)
if /i "%~1"=="debug" (
    rem Debug mode: console window stays open, verbose log
    ".venv\Scripts\python.exe" main.py --debug
    pause
    exit /b
)
start "" ".venv\Scripts\pythonw.exe" main.py %*
