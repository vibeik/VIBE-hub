"""Настройки: внешний вид, язык, автозапуск, Dashboard, мониторинг, резервные копии, сведения о программе."""
from __future__ import annotations

import logging
import platform
from datetime import datetime

from PySide6.QtCore import QRectF, QSize, Qt, qVersion
from PySide6.QtGui import QColor, QFont, QLinearGradient, QPainter, QPen
from PySide6.QtWidgets import (QApplication, QCheckBox, QColorDialog, QComboBox, QFileDialog, QFormLayout, QGridLayout,
                               QHBoxLayout, QLineEdit, QPushButton, QSlider, QVBoxLayout, QWidget)

from config.settings import APP_NAME, APP_VERSION, backup_dir, data_dir, db_path, log_dir, logos_dir
from database.db import DatabaseError, Database
from modules import autostart
from ui import icons, theme
from ui.common.base import Banner, Card, Page, button, label
from ui.common.dialogs import confirm, message
from ui.common.util import open_path
from utils import logo, winstyle
from utils.i18n import _

log = logging.getLogger("vibehub.settings.ui")

ACCENTS = ["#8B5CF6", "#3B82F6", "#22D3EE", "#10B981", "#F59E0B", "#EF4444", "#EC4899", "#A3E635"]
INTERVALS = [(500, "0,5 с"), (1000, "1 с"), (2000, "2 с"), (5000, "5 с")]
LANGS = [("ru", "Русский"), ("en", "English")]
LOGOS = [("violet", "Чёрно-фиолетовый"), ("yellow", "Чёрно-жёлтый")]
GLASS_CHOICES = [("acrylic", "Акрил (размытие фона)"), ("mica", "Слюда (Mica)"), ("off", "Выключено")]
THEME_COLUMNS = 4
SOURCES = [("all", "Все матчи"), ("faceit", "Только FACEIT"), ("manual", "Только добавленные вручную")]


def _form() -> QFormLayout:
    f = QFormLayout()
    f.setLabelAlignment(Qt.AlignmentFlag.AlignLeft)
    f.setHorizontalSpacing(24)
    f.setVerticalSpacing(12)
    f.setFieldGrowthPolicy(QFormLayout.FieldGrowthPolicy.AllNonFixedFieldsGrow)
    return f


class ThemeTile(QPushButton):
    """Плитка темы: мини-превью (фон, боковая панель, карточка, акцентный градиент) и название."""

    def __init__(self, key: str, title: str):
        super().__init__()
        self.key = key
        self.title = title
        self.setCheckable(True)
        self.setCursor(Qt.CursorShape.PointingHandCursor)
        self.setFixedSize(132, 88)
        self.setToolTip(title)

    def paintEvent(self, _e) -> None:
        pal = theme.PALETTES[self.key]
        p = QPainter(self)
        p.setRenderHint(QPainter.RenderHint.Antialiasing)
        on = self.isChecked()
        rim = QColor(pal["accent"]) if on else QColor(pal["border"])
        if self.underMouse() and not on:
            rim = QColor(pal["accent2"])
        p.setPen(QPen(rim, 2.5 if on else 1.2))
        p.setBrush(QColor(pal["bg"]))
        r = QRectF(self.rect()).adjusted(1.5, 1.5, -1.5, -1.5)
        p.drawRoundedRect(r, 16, 16)
        p.setPen(Qt.PenStyle.NoPen)
        p.setBrush(QColor(pal["surface"]))
        p.drawRoundedRect(QRectF(r.left() + 8, r.top() + 8, 24, r.height() - 28), 8, 8)       # боковая панель
        p.setBrush(QColor(pal["surface2"]))
        p.drawRoundedRect(QRectF(r.left() + 38, r.top() + 8, r.width() - 46, 34), 10, 10)       # карточка
        g = QLinearGradient(r.left() + 46, 0, r.right() - 16, 0)
        g.setColorAt(0, QColor(pal["accent"]))
        g.setColorAt(1, QColor(pal["accent2"]))
        p.setBrush(g)
        p.drawRoundedRect(QRectF(r.left() + 46, r.top() + 18, (r.width() - 62) * 0.62, 7), 3.5, 3.5)   # полоска прогресса
        p.setBrush(QColor(pal["border"]))
        p.drawRoundedRect(QRectF(r.left() + 46 + (r.width() - 62) * 0.62 + 3, r.top() + 18, (r.width() - 62) * 0.38 - 3, 7), 3.5, 3.5)
        p.setPen(QColor(pal["text"]))
        f = QFont(self.font())
        f.setPixelSize(11)
        f.setWeight(QFont.Weight.DemiBold)
        p.setFont(f)
        p.drawText(QRectF(r.left() + 38, r.bottom() - 26, r.width() - 40, 20),
                   int(Qt.AlignmentFlag.AlignLeft | Qt.AlignmentFlag.AlignVCenter), self.title.split(" (")[0])
        p.end()


class SettingsPage(Page):
    def __init__(self, ctx, parent=None):
        super().__init__(ctx, parent)
        self.s = ctx.settings
        root = QVBoxLayout(self)
        root.setContentsMargins(28, 22, 28, 28)
        root.setSpacing(16)
        head, _col = self.page_header(_("Настройки"), f"{APP_NAME} {APP_VERSION}")
        root.addLayout(head)
        self._syncing = False

        # ---------------- внешний вид
        ap = Card(_("Внешний вид"), "palette")
        f = _form()
        self.theme_grid = QGridLayout()
        self.theme_grid.setSpacing(10)
        self._theme_tiles: dict[str, ThemeTile] = {}
        for i, (key, text) in enumerate(theme.THEME_LABELS.items()):
            tile = ThemeTile(key, text)
            tile.clicked.connect(lambda _c=False, k=key: self._on_theme(k))
            self.theme_grid.addWidget(tile, i // THEME_COLUMNS, i % THEME_COLUMNS)
            self._theme_tiles[key] = tile
        self.theme_grid.setColumnStretch(THEME_COLUMNS, 1)
        tw = QWidget()
        tw.setLayout(self.theme_grid)
        f.addRow(_("Тема"), tw)

        self.swatches = QHBoxLayout()
        self.swatches.setSpacing(6)
        self._swatch_btns: list[QPushButton] = []
        for col in ACCENTS:
            b = QPushButton()
            b.setFixedSize(26, 26)
            b.setCursor(Qt.CursorShape.PointingHandCursor)
            b.setToolTip(col)
            b.clicked.connect(lambda _c=False, c=col: self._set_accent(c))
            self.swatches.addWidget(b)
            self._swatch_btns.append(b)
        self.swatches.addWidget(button(_("Свой цвет…"), "ghost", "palette", self._custom_accent))
        self.swatches.addStretch(1)
        sw = QWidget()
        sw.setLayout(self.swatches)
        f.addRow(_("Акцентный цвет"), sw)

        self.logo_row = QHBoxLayout()
        self.logo_row.setSpacing(10)
        self._logo_btns: dict[str, QPushButton] = {}
        for key, text in LOGOS:
            b = QPushButton(_(text))
            b.setCheckable(True)
            b.setIcon(icons.app_icon(key))
            b.setIconSize(QSize(36, 36))
            b.setMinimumHeight(52)
            b.setCursor(Qt.CursorShape.PointingHandCursor)
            b.clicked.connect(lambda _c=False, k=key: self._on_logo(k))
            self.logo_row.addWidget(b)
            self._logo_btns[key] = b
        self.logo_row.addStretch(1)
        lw = QWidget()
        lw.setLayout(self.logo_row)
        f.addRow(_("Логотип"), lw)
        f.addRow("", label(_("Значок меняется в приложении, в окне и на панели задач. Файл .exe и ярлыки сохраняют иконку, с которой собрано приложение."),
                           "Muted", wrap=True))

        self.anim = QCheckBox(_("Плавные анимации"))
        self.anim.toggled.connect(lambda v: self._set("animations", bool(v)))
        f.addRow(_("Анимации"), self.anim)

        self.glass = QComboBox()
        for key, text in GLASS_CHOICES:
            self.glass.addItem(_(text), key)
        self.glass.currentIndexChanged.connect(self._on_glass)
        f.addRow(_("Эффект стекла"), self.glass)
        self.glass_note = label("", "Muted", wrap=True)
        f.addRow("", self.glass_note)
        self.glass_alpha = QSlider(Qt.Orientation.Horizontal)
        self.glass_alpha.setRange(10, 70)
        self.glass_alpha.setFixedWidth(220)
        self.glass_alpha_lbl = label("30%", "Muted")
        self.glass_alpha.valueChanged.connect(self._on_glass_alpha)
        self.glass_alpha.sliderReleased.connect(lambda: self._on_glass_alpha(self.glass_alpha.value()))
        row = QHBoxLayout()
        row.addWidget(self.glass_alpha)
        row.addWidget(self.glass_alpha_lbl)
        row.addStretch(1)
        self.glass_alpha_row = QWidget()
        self.glass_alpha_row.setLayout(row)
        f.addRow(_("Прозрачность фона"), self.glass_alpha_row)
        ap.body.addLayout(f)
        root.addWidget(ap)

        # ---------------- общие
        gen = Card(_("Общие"), "settings")
        f = _form()
        self.lang = QComboBox()
        for key, text in LANGS:
            self.lang.addItem(text, key)
        self.lang.currentIndexChanged.connect(self._on_lang)
        f.addRow(_("Язык интерфейса"), self.lang)
        self.lang_note = label(_("Язык применится после перезапуска приложения."), "Muted")
        self.lang_note.setVisible(False)
        f.addRow("", self.lang_note)
        self.name = QLineEdit()
        self.name.setPlaceholderText(_("Как к вам обращаться"))
        self.name.setMaxLength(32)
        self.name.setFixedWidth(260)
        self.name.editingFinished.connect(lambda: self._set("user_name", self.name.text().strip()))
        f.addRow(_("Ваше имя"), self.name)
        self.auto = QCheckBox(_("Запускать вместе с Windows"))
        self.auto.toggled.connect(self._on_autostart)
        f.addRow(_("Автозапуск"), self.auto)
        gen.body.addLayout(f)
        root.addWidget(gen)

        # ---------------- Dashboard
        dash = Card("Dashboard", "dashboard")
        f = _form()
        self.source = QComboBox()
        for key, text in SOURCES:
            self.source.addItem(_(text), key)
        self.source.currentIndexChanged.connect(lambda _i: self._set("dashboard_source", self.source.currentData()))
        f.addRow(_("Источник статистики"), self.source)
        f.addRow(_("Раскладка"), button(_("Сбросить расположение карточек"), icon="refresh", on_click=self._reset_layout))
        dash.body.addLayout(f)
        dash.body.addWidget(label(_("Перемещать, менять размер и скрывать карточки можно на самом Dashboard — кнопка «Настроить»."), "Muted", wrap=True))
        root.addWidget(dash)

        # ---------------- мониторинг
        mon = Card(_("Мониторинг ПК"), "cpu")
        f = _form()
        self.interval = QComboBox()
        for ms, text in INTERVALS:
            self.interval.addItem(_(text), ms)
        self.interval.currentIndexChanged.connect(lambda _i: self._set("monitor_interval_ms", self.interval.currentData()))
        f.addRow(_("Частота обновления"), self.interval)
        self.history = QCheckBox(_("Записывать историю нагрузки (раз в 10 секунд, хранится 7 дней)"))
        self.history.toggled.connect(lambda v: self._set("monitor_history", bool(v)))
        f.addRow(_("История"), self.history)
        f.addRow("", button(_("Очистить историю мониторинга"), "ghost", "trash", self._clear_history))
        mon.body.addLayout(f)
        root.addWidget(mon)

        # ---------------- данные
        dat = Card(_("Данные и резервные копии"), "database")
        self.data_path = label("", "Muted", selectable=True, wrap=True)
        dat.body.addWidget(self.data_path)
        btns = QHBoxLayout()
        btns.setSpacing(8)
        btns.addWidget(button(_("Создать резервную копию…"), "primary", "download", self._backup))
        btns.addWidget(button(_("Восстановить из копии…"), None, "upload", self._restore))
        btns.addStretch(1)
        dat.body.addLayout(btns)
        folders = QHBoxLayout()
        folders.setSpacing(8)
        folders.addWidget(button(_("Открыть папку данных"), "ghost", "folder", lambda: open_path(data_dir())))
        folders.addWidget(button(_("Открыть папку журналов"), "ghost", "folder", lambda: open_path(log_dir())))
        logos_btn = button(_("Открыть папку логотипов"), "ghost", "folder", lambda: open_path(logos_dir()))
        logos_btn.setToolTip(_("Положите сюда steam.png, faceit.png, spotify.png (или .svg) — значки сервисов заменятся после перезапуска"))
        folders.addWidget(logos_btn)
        folders.addStretch(1)
        dat.body.addLayout(folders)
        dat.body.addWidget(label(_("Раз в сутки приложение само создаёт копию базы в папке backups (хранятся последние 7)."), "Muted", wrap=True))
        root.addWidget(dat)

        # ---------------- о программе
        about = Card(_("О программе"), "info")
        self.about_lbl = label("", wrap=True, selectable=True)
        about.body.addWidget(self.about_lbl)
        self.secure = Banner("", "warning")
        about.body.addWidget(self.secure)
        perf_btn = button(_("Скопировать отчёт о производительности"), "ghost", "copy", self._copy_perf_report)
        perf_btn.setToolTip(_("Сводка о подвисаниях интерфейса и параметрах экрана — приложите её, если приложение тормозит"))
        perf_row = QHBoxLayout()
        perf_row.addWidget(perf_btn)
        perf_row.addStretch(1)
        about.body.addLayout(perf_row)
        root.addWidget(about)
        root.addStretch(1)

    # ------------------------------------------------------------------ синхронизация
    def refresh(self) -> None:
        self._syncing = True
        try:
            s = self.s
            self._paint_theme_tiles()
            self._sync_glass()
            self._paint_swatches()
            self._paint_logo_tiles()
            self.anim.setChecked(bool(s.get("animations")))
            self.lang.setCurrentIndex(max(0, self.lang.findData(s.get("language"))))
            self.name.setText(s.get("user_name") or "")
            if autostart.supported():
                self.auto.setChecked(autostart.is_enabled())
            else:
                self.auto.setChecked(False)
                self.auto.setEnabled(False)
                self.auto.setToolTip(_("Автозапуск доступен только в Windows."))
            self.source.setCurrentIndex(max(0, self.source.findData(s.get("dashboard_source"))))
            self.interval.setCurrentIndex(max(0, self.interval.findData(int(s.get("monitor_interval_ms") or 1000))))
            self.history.setChecked(bool(s.get("monitor_history")))
        finally:
            self._syncing = False
        self.data_path.setText(f"{_('Папка данных')}: {data_dir()}\n{_('База данных')}: {db_path()}")
        try:
            import PySide6
            pyside = PySide6.__version__
        except Exception:
            pyside = "?"
        self.about_lbl.setText(f"{APP_NAME} {APP_VERSION}\nPython {platform.python_version()} · PySide6 {pyside} · Qt {qVersion()}\n"
                               f"{platform.system()} {platform.release()}")
        store = self.ctx.store
        if store.persistent:
            self.secure.set_text("")
        else:
            self.secure.set_text(f"{_('Защищённое хранилище недоступно')}: {store.problem or _('причина не определена')}. "
                                 f"{_('Ключи и токены живут только до закрытия приложения и на диск не записываются.')}", "warning")

    def _set(self, key: str, value) -> None:
        if not self._syncing:
            self.s.set(key, value)

    # ------------------------------------------------------------------ внешний вид
    def _paint_theme_tiles(self) -> None:
        cur = self.s.get("theme")
        for key, tile in self._theme_tiles.items():
            tile.setChecked(key == cur)
            tile.update()

    def _on_theme(self, key: str) -> None:
        if self._syncing:
            return
        pal = theme.PALETTES.get(key)
        if pal:      # при смене темы акценты возвращаются к палитре темы — дальше их можно изменить вручную
            self.s.set("accent", pal["accent"])
            self.s.set("accent2", pal["accent2"])
        self.s.set("theme", key)
        self._paint_theme_tiles()
        self._paint_swatches()
        self._paint_logo_tiles()

    def _set_accent(self, color: str) -> None:
        self.s.set("accent", color)
        self._paint_swatches()
        self._paint_logo_tiles()

    def _custom_accent(self) -> None:
        c = QColorDialog.getColor(QColor(self.s.get("accent")), self, _("Акцентный цвет"))
        if c.isValid():
            self._set_accent(c.name().upper())

    def _paint_swatches(self) -> None:
        cur = (self.s.get("accent") or "").upper()
        for b, col in zip(self._swatch_btns, ACCENTS):
            border = "2px solid #FFFFFF" if col.upper() == cur else "2px solid transparent"
            b.setStyleSheet(f"QPushButton{{background:{col};border:{border};border-radius:13px;padding:0;min-width:26px;}}")

    def _on_logo(self, key: str) -> None:
        if self._syncing:
            return
        self.s.set("logo_style", key)
        self._paint_logo_tiles()

    def _paint_logo_tiles(self) -> None:
        c = theme.get().colors
        cur = logo.normalize(self.s.get("logo_style"))
        for key, b in self._logo_btns.items():
            on = key == cur
            b.setChecked(on)
            border = f"2px solid {c['accent']}" if on else f"1px solid {c['border']}"
            b.setStyleSheet(f"QPushButton{{background:{c['surface2']};color:{c['text']};border:{border};border-radius:12px;"
                            f"padding:6px 18px 6px 10px;text-align:left;}}"
                            f"QPushButton:hover{{border:2px solid {c['accent']};}}")

    def _sync_glass(self) -> None:
        """Состояние блока «стекло»: доступность зависит от версии Windows и от того, включено ли оно в этом запуске."""
        s = self.s
        supported = winstyle.effective_glass_mode("acrylic") != "off"
        self.glass.setCurrentIndex(max(0, self.glass.findData(s.get("glass"))))
        self.glass.setEnabled(supported)
        active = theme.get().glass_mode != "off"
        self.glass_alpha.setValue(int(s.get("glass_transparency") or 30))
        self.glass_alpha_lbl.setText(f"{self.glass_alpha.value()}%")
        self.glass_alpha_row.setEnabled(active)
        if not supported:
            self.glass_note.setText(_("Недоступно в этой системе: нужна Windows 11."))
        elif active:
            self.glass_note.setText(_("Выбор режима применяется после перезапуска приложения."))
        elif s.get("glass") != "off":
            self.glass_note.setText(_("Стекло включится после перезапуска приложения."))
        else:
            self.glass_note.setText(_("Стекло выключено — окно с обычным фоном."))

    def _on_glass(self) -> None:
        if self._syncing:
            return
        self.s.set("glass", self.glass.currentData())
        self._sync_glass()

    def _on_glass_alpha(self, v: int) -> None:
        self.glass_alpha_lbl.setText(f"{v}%")
        if self._syncing or self.glass_alpha.isSliderDown():
            return      # пока ползунок тянут, ничего не применяем: каждое применение перекрашивает всё приложение и пишет файл
        if self.s.get("glass_transparency") != v:
            self.s.set("glass_transparency", v)

    # ------------------------------------------------------------------ общие
    def _on_lang(self) -> None:
        if self._syncing:
            return
        self.s.set("language", self.lang.currentData())
        self.lang_note.setVisible(True)

    def _on_autostart(self, on: bool) -> None:
        if self._syncing:
            return
        try:
            autostart.set_enabled(bool(on))
            self.s.set("autostart", bool(on))
        except OSError as exc:
            log.warning("Автозапуск: %s", exc)
            message(self, _("Автозапуск"), f"{_('Не удалось изменить автозапуск')}: {exc}", "warning")
            self._syncing = True
            self.auto.setChecked(not on)
            self._syncing = False

    def _reset_layout(self) -> None:
        if confirm(self, _("Сбросить раскладку"), _("Вернуть расположение и размеры карточек Dashboard по умолчанию?"),
                   ok=_("Сбросить"), danger=False):
            self.s.set("dashboard_layout", None)
            self.ctx.bus.settings_changed.emit("dashboard_layout", None)

    def _clear_history(self) -> None:
        if confirm(self, _("Очистить историю"), _("Удалить сохранённую историю нагрузки ПК? Матчи и цели не затрагиваются.")):
            self.ctx.repos.pc.clear()
            message(self, _("Мониторинг ПК"), _("История очищена."))

    # ------------------------------------------------------------------ диагностика
    def _copy_perf_report(self) -> None:
        from ui.perf_watch import build_report
        QApplication.clipboard().setText(build_report(self.ctx))
        self.ctx.notify("success", _("Отчёт скопирован"), _("Вставьте его в сообщение: в нём только цифры задержек и параметры экрана."))

    # ------------------------------------------------------------------ резервные копии
    def _backup(self) -> None:
        default = str(data_dir() / f"VibeHub-backup-{datetime.now():%Y%m%d-%H%M}.db")
        path, _f = QFileDialog.getSaveFileName(self, _("Сохранить резервную копию"), default, "SQLite (*.db)")
        if not path:
            return
        try:
            self.ctx.db.backup_to(path)
        except Exception as exc:
            log.exception("Бэкап не удался")
            message(self, _("Резервная копия"), f"{_('Не удалось создать копию')}: {exc}", "error")
            return
        message(self, _("Резервная копия"), f"{_('Копия сохранена')}:\n{path}\n\n"
                                            f"{_('В копию не входят API-ключи и токены — они хранятся в Диспетчере учётных данных.')}")

    def _restore(self) -> None:
        path, _f = QFileDialog.getOpenFileName(self, _("Выберите резервную копию"), str(backup_dir()), "SQLite (*.db)")
        if not path:
            return
        try:
            Database.validate_backup(path)
        except DatabaseError as exc:
            message(self, _("Восстановление"), str(exc), "warning")
            return
        if not confirm(self, _("Восстановить из копии"),
                       _("Текущие матчи, цели и плейлисты будут заменены содержимым копии. Перед этим приложение сохранит страховочную копию "
                         "текущей базы. После восстановления приложение закроется — запустите его снова."),
                       ok=_("Восстановить")):
            return
        try:
            self.ctx.db.restore_from(path, backup_dir())
        except Exception as exc:
            log.exception("Восстановление не удалось")
            message(self, _("Восстановление"), f"{_('Не удалось восстановить')}: {exc}", "error")
            return
        message(self, _("Восстановление"), _("Готово. Приложение будет закрыто — запустите его снова."))
        QApplication.quit()

