"""Страница FACEIT: профиль, ELO, статистика, графики и последние матчи (Data API v4)."""
from __future__ import annotations

import logging

from PySide6.QtCore import Qt
from PySide6.QtWidgets import QGridLayout, QHBoxLayout, QVBoxLayout, QWidget

from modules import dashboard_data, stats
from ui.common.base import Banner, Card, Chip, EmptyState, Page, SegmentedControl, StatTile, button, label, set_tone
from ui.common.charts import ChartWidget
from ui.common.images import AsyncImage
from ui.common.tables import ALIGN_C, ALIGN_R, cell, fit_height, make_table
from ui.common.util import fmt_dt, open_url
from utils.format import fmt_num, fmt_pct, fmt_signed
from utils.i18n import _
from utils.timeutil import human_ago

log = logging.getLogger("vibehub.faceit.ui")
RESULT_LABEL = {"win": "Победа", "loss": "Поражение", "draw": "Ничья"}
RESULT_TONE = {"win": "success", "loss": "danger", "draw": "muted"}


class FaceitPage(Page):
    def __init__(self, ctx, parent=None):
        super().__init__(ctx, parent)
        self._profile_url: str | None = None
        root = QVBoxLayout(self)
        root.setContentsMargins(28, 22, 28, 28)
        root.setSpacing(16)

        head, _col = self.page_header("FACEIT", _("CS2: уровень, ELO и статистика через официальный Data API"))
        self.btn_open = button(_("Открыть профиль"), icon="external", on_click=lambda: open_url(self._profile_url))
        self.btn_refresh = button(_("Обновить"), "primary", "refresh", lambda: ctx.faceit.refresh(True))
        head.addWidget(self.btn_open)
        head.addWidget(self.btn_refresh)
        root.addLayout(head)

        self.empty = EmptyState(_("FACEIT не подключён"),
                                _("Укажите никнейм и персональный Data API key (developers.faceit.com) в разделе «Подключённые аккаунты»."),
                                icon="trophy", button_text=_("Подключить FACEIT"),
                                on_click=lambda: ctx.bus.navigate.emit("accounts"))
        root.addWidget(self.empty)

        self.content = QWidget()
        cl = QVBoxLayout(self.content)
        cl.setContentsMargins(0, 0, 0, 0)
        cl.setSpacing(16)
        root.addWidget(self.content)

        self.key_banner = Banner(_("Не указан FACEIT API Key — данные не обновляются. Добавьте ключ в «Подключённые аккаунты»."), "warning")
        cl.addWidget(self.key_banner)

        prof = Card()
        row = QHBoxLayout()
        row.setSpacing(16)
        self.avatar = AsyncImage(72)
        col = QVBoxLayout()
        col.setSpacing(4)
        self.nick = label("", "H2")
        chips = QHBoxLayout()
        self.chip_level = Chip("", "accent")
        self.chip_country = Chip("", "neutral")
        chips.addWidget(self.chip_level)
        chips.addWidget(self.chip_country)
        chips.addStretch(1)
        self.updated = label("", "Muted")
        col.addWidget(self.nick)
        col.addLayout(chips)
        col.addWidget(self.updated)
        elo_col = QVBoxLayout()
        elo_col.setSpacing(0)
        self.elo = label("—", "Big")
        self.elo_cap = label("ELO", "Muted", align=Qt.AlignmentFlag.AlignRight)
        self.delta = label("", "Muted", align=Qt.AlignmentFlag.AlignRight)
        elo_col.addWidget(self.elo, 0, Qt.AlignmentFlag.AlignRight)
        elo_col.addWidget(self.elo_cap)
        elo_col.addWidget(self.delta)
        row.addWidget(self.avatar, 0, Qt.AlignmentFlag.AlignTop)
        row.addLayout(col, 1)
        row.addLayout(elo_col)
        prof.body.addLayout(row)
        cl.addWidget(prof)

        tiles = QGridLayout()
        tiles.setSpacing(12)
        self.t = {k: StatTile(title) for k, title in (("matches", _("Матчей")), ("wr", "Win Rate"), ("kd", "K/D"), ("hs", "Headshot %"),
                                                       ("streak", _("Серия побед")), ("avg", _("Убийств за матч")))}
        for i, tile in enumerate(self.t.values()):
            tiles.addWidget(tile, 0, i)
            tiles.setColumnStretch(i, 1)
        cl.addLayout(tiles)

        # --- графики
        self.elo_card = Card(_("История ELO"), "trending-up")
        self.elo_range = SegmentedControl([("30", _("30 дней")), ("90", _("90 дней")), ("365", _("Год"))], "30")
        self.elo_range.changed.connect(lambda _k: self._fill_elo())
        self.elo_card.add_header_widget(self.elo_range)
        self.c_elo = ChartWidget(date_axis=True, min_height=210,
                                 empty_text=_("Пока нет данных. FACEIT API не отдаёт ELO по матчам — график строится из снимков, "
                                              "которые приложение сохраняет при каждом обновлении."))
        self.elo_card.body.addWidget(self.c_elo, 1)
        cl.addWidget(self.elo_card)

        charts = QHBoxLayout()
        charts.setSpacing(16)
        self.c_kd = ChartWidget(min_height=190, empty_text=_("Нет матчей"))
        self.c_kills = ChartWidget(min_height=190, empty_text=_("Нет матчей"))
        for title, ch in ((_("K/D по последним матчам"), self.c_kd), (_("Убийства по последним матчам"), self.c_kills)):
            c = Card(title)
            c.body.addWidget(ch, 1)
            charts.addWidget(c, 1)
        cl.addLayout(charts)

        self.recent_card = Card(_("Последние матчи"), "history")
        self.table = make_table([_("Дата"), _("Карта"), _("Результат"), "K / D / A", "K/D", "HS%", _("Счёт")], stretch_col=1)
        self.recent_card.body.addWidget(self.table)
        cl.addWidget(self.recent_card)
        root.addStretch(1)

        ctx.faceit.updated.connect(self.mark_dirty)
        ctx.faceit.busy_changed.connect(self._on_busy)
        ctx.bus.accounts_changed.connect(self.mark_dirty)
        ctx.bus.matches_changed.connect(self.mark_dirty)

    def _on_busy(self, busy: bool) -> None:
        self.btn_refresh.setEnabled(not busy)
        self.btn_refresh.setText(_("Обновление…") if busy else _("Обновить"))

    def refresh(self) -> None:
        o = self.ctx.faceit.overview()
        linked = bool(o.get("linked"))
        self.empty.setVisible(not linked)
        self.content.setVisible(linked)
        self.btn_open.setVisible(linked)
        self.btn_refresh.setVisible(linked)
        if not linked:
            return
        self._profile_url = o.get("profile_url")
        self.btn_open.setEnabled(bool(self._profile_url))
        self.btn_refresh.setEnabled(bool(o.get("has_key")) and not self.ctx.faceit.busy)
        self.key_banner.setVisible(not o.get("has_key"))
        self.avatar.set_url(o.get("avatar"))
        self.nick.setText(o.get("nickname") or "")
        self.chip_level.setText(f"Level {o['level']}" if o.get("level") else "Level —")
        country = (o.get("country") or "").upper()
        self.chip_country.setText(country)
        self.chip_country.setVisible(bool(country))
        self.updated.setText(f"{_('Обновлено')}: {human_ago(o.get('updated_at'))}")
        self.elo.setText(str(o["elo"]) if o.get("elo") is not None else "—")
        ch = o.get("elo_change")
        if ch and ch.get("delta") is not None:
            self.delta.setText(f"{fmt_signed(ch['delta'])} {_('с')} {fmt_dt(ch['since'])}")
            set_tone(self.delta, "success" if ch["delta"] > 0 else "danger" if ch["delta"] < 0 else None)
        else:
            self.delta.setText("")
        t = self.t
        t["matches"].set_value(str(o["matches"]) if o.get("matches") is not None else "—",
                               f"{o.get('wins', 0)} {_('поб.')} / {o.get('losses', 0)} {_('пор.')}" if o.get("matches") is not None else "")
        wr = o.get("win_rate")
        t["wr"].set_value(fmt_pct(wr, 0) if wr is not None else "—", tone=None if wr is None else ("success" if wr >= 50 else "danger"))
        kd = o.get("kd")
        t["kd"].set_value(fmt_num(kd, 2), tone=None if kd is None else ("success" if kd >= 1 else "danger"))
        t["hs"].set_value(fmt_pct(o.get("hs_pct"), 0) if o.get("hs_pct") is not None else "—")
        t["streak"].set_value(str(o["win_streak"]) if o.get("win_streak") is not None else "—")
        t["avg"].set_value(fmt_num(o.get("avg_kills"), 1), f"{_('за последние')} {o['avg_kills_n']}" if o.get("avg_kills_n") else "")
        self._fill_elo()
        self._fill_matches()

    def _fill_elo(self) -> None:
        pts = dashboard_data.elo_series(self.ctx.repos, int(self.elo_range.current()))
        if pts:
            self.c_elo.plot_lines([{"name": "ELO", "x": [p[0] for p in pts], "y": [p[1] for p in pts], "color": "accent",
                                    "fmt": "{:.0f}", "fill": True}])
        else:
            self.c_elo.show_empty()

    def _fill_matches(self) -> None:
        ms = self.ctx.repos.matches.list(source="faceit", limit=30)
        asc = list(reversed(ms))
        labels = [fmt_dt(m["played_at"]) for m in asc]
        if asc:
            self.c_kd.plot_lines([{"name": "K/D", "y": [stats.kd(m["kills"], m["deaths"]) for m in asc], "color": "accent2",
                                   "fmt": "{:.2f}"}], x_labels=labels)
            self.c_kills.plot_bars([{"name": _("Убийства"), "y": [m["kills"] for m in asc], "color": "accent", "fmt": "{:.0f}"}], labels)
        else:
            self.c_kd.show_empty()
            self.c_kills.show_empty()
        shown = ms[:15]
        tb = self.table
        tb.setRowCount(len(shown))
        for r, m in enumerate(shown):
            tb.setItem(r, 0, cell(fmt_dt(m["played_at"], True)))
            tb.setItem(r, 1, cell(m["map"] or "—"))
            tb.setItem(r, 2, cell(_(RESULT_LABEL[m["result"]]), tone=RESULT_TONE[m["result"]]))
            tb.setItem(r, 3, cell(f"{m['kills']} / {m['deaths']} / {m['assists']}", align=ALIGN_C))
            tb.setItem(r, 4, cell(fmt_num(stats.kd(m["kills"], m["deaths"]), 2), align=ALIGN_R))
            tb.setItem(r, 5, cell(fmt_pct(m["headshot_pct"], 0) if m["headshot_pct"] is not None else "—", align=ALIGN_R))
            tb.setItem(r, 6, cell(m["score"] or "—", align=ALIGN_C))
        fit_height(tb, 15)
        self.recent_card.setVisible(bool(shown))
