"""Цветовые палитры тем и чистая математика цвета (без Qt — проверяется тестами)."""
from __future__ import annotations

# bg — фон окна, surface — панели, surface2 — карточки/всплывающие окна, border — границы,
# text / muted — основной и приглушённый текст, accent / accent2 — начало и конец акцентного градиента.
PALETTES: dict[str, dict[str, str]] = {
    "violet": {"bg": "#0B0B12", "surface": "#13131D", "surface2": "#1B1B29", "border": "#2A2A3D",
               "text": "#ECECF5", "muted": "#8D8DA6", "accent": "#8B5CF6", "accent2": "#38BDF8"},
    "blue": {"bg": "#0A0D14", "surface": "#11161F", "surface2": "#182030", "border": "#25324A",
             "text": "#E8EEF8", "muted": "#8A98B2", "accent": "#3B82F6", "accent2": "#22D3EE"},
    "midnight": {"bg": "#060608", "surface": "#0E0E14", "surface2": "#16161F", "border": "#23232F",
                 "text": "#EEEEF4", "muted": "#85859A", "accent": "#A78BFA", "accent2": "#60A5FA"},
    "aurora": {"bg": "#061110", "surface": "#0C1B1A", "surface2": "#122A29", "border": "#1F4442",
               "text": "#E6F6F3", "muted": "#7FA8A3", "accent": "#0D9488", "accent2": "#16A34A"},
    "ocean": {"bg": "#050E15", "surface": "#0B1923", "surface2": "#112737", "border": "#1D3F57",
              "text": "#E4F2F9", "muted": "#7DA2B8", "accent": "#0284C7", "accent2": "#0D9488"},
    "emerald": {"bg": "#060F0A", "surface": "#0D1912", "surface2": "#14281D", "border": "#21402E",
                "text": "#E7F7EC", "muted": "#80A98F", "accent": "#059669", "accent2": "#0284C7"},
    "sunset": {"bg": "#130B0D", "surface": "#1C1116", "surface2": "#2A1A22", "border": "#43283A",
               "text": "#FAEDEB", "muted": "#B08F95", "accent": "#F43F5E", "accent2": "#F97316"},
    "crimson": {"bg": "#0E0708", "surface": "#180D10", "surface2": "#251519", "border": "#3E2228",
                "text": "#F8EBEC", "muted": "#A98A8F", "accent": "#EF4444", "accent2": "#F97316"},
    "rose": {"bg": "#120A10", "surface": "#1D1119", "surface2": "#2B1A26", "border": "#452839",
             "text": "#FBEBF3", "muted": "#B38DA3", "accent": "#EC4899", "accent2": "#A78BFA"},
    "cyber": {"bg": "#0A0710", "surface": "#130E1F", "surface2": "#1E1432", "border": "#36225A",
              "text": "#F4ECFE", "muted": "#9F8AC0", "accent": "#D946EF", "accent2": "#22D3EE"},
    "mocha": {"bg": "#100C0A", "surface": "#1A1411", "surface2": "#271E18", "border": "#3E3027",
              "text": "#F6EDE6", "muted": "#AD9684", "accent": "#D97706", "accent2": "#E11D48"},
    "carbon": {"bg": "#0C0D0F", "surface": "#141517", "surface2": "#1F2124", "border": "#2F3238",
               "text": "#EEEFF1", "muted": "#8E939B", "accent": "#4F6EF0", "accent2": "#2E90D8"},
}
STATUS = {"success": "#34D399", "warning": "#FBBF24", "danger": "#F87171"}
DEFAULT_THEME = "violet"
THEME_LABELS = {"violet": "Violet (по умолчанию)", "blue": "Blue", "midnight": "Midnight", "aurora": "Aurora",
                "ocean": "Ocean", "emerald": "Emerald", "sunset": "Sunset", "crimson": "Crimson", "rose": "Rose",
                "cyber": "Cyber", "mocha": "Mocha", "carbon": "Carbon"}


def hex_to_rgb(color: str) -> tuple[int, int, int]:
    h = color.lstrip("#")
    return int(h[0:2], 16), int(h[2:4], 16), int(h[4:6], 16)


def luminance(color: str) -> float:
    """Относительная яркость по WCAG (0 — чёрный, 1 — белый)."""
    def lin(v: int) -> float:
        x = v / 255
        return x / 12.92 if x <= 0.03928 else ((x + 0.055) / 1.055) ** 2.4
    r, g, b = (lin(v) for v in hex_to_rgb(color))
    return 0.2126 * r + 0.7152 * g + 0.0722 * b


def contrast(a: str, b: str) -> float:
    la, lb = luminance(a), luminance(b)
    hi, lo = max(la, lb), min(la, lb)
    return (hi + 0.05) / (lo + 0.05)


def mix(a: str, b: str, t: float) -> str:
    """Смесь цветов: t=0 — a, t=1 — b."""
    ra, ga, ba = hex_to_rgb(a)
    rb, gb, bb = hex_to_rgb(b)
    return "#{:02X}{:02X}{:02X}".format(round(ra + (rb - ra) * t), round(ga + (gb - ga) * t), round(ba + (bb - ba) * t))


def on_accent(accent: str, accent2: str) -> str:
    """Цвет текста на акцентном градиенте: белый; для очень светлых акцентов (жёлтый, лайм) — почти чёрный."""
    mid = mix(accent, accent2, 0.5)
    return "#FFFFFF" if contrast("#FFFFFF", mid) >= 2.2 else "#0B0B12"
