"""Подключённые аккаунты: Steam, FACEIT, Spotify — статус, подключение, отключение, обновление.

Пароли приложению не передаются: Steam — OpenID на сайте Steam, Spotify — OAuth 2.0 PKCE, FACEIT — персональный
Data API key. Секреты хранятся только в Диспетчере учётных данных Windows.
"""
from __future__ import annotations

import logging

from PySide6.QtCore import Qt
from PySide6.QtWidgets import QHBoxLayout, QLineEdit, QVBoxLayout

from ui import icons
from ui.common.base import Card, Chip, Page, button, label
from ui.common.dialogs import FormDialog, confirm, confirm_with_option
from ui.common.util import clear_layout, open_url
from utils.i18n import _
from utils.timeutil import human_ago

log = logging.getLogger("vibehub.accounts")


class SecretDialog(FormDialog):
    """Ввод одного секрета (API key / Client ID). Значение не логируется."""

    def __init__(self, parent, title: str, field_label: str, intro: str, link: tuple[str, str] | None = None,
                 secret: bool = True, initial: str = ""):
        super().__init__(parent, title, ok_text=_("Сохранить"), width=520, intro=intro)
        self.edit = QLineEdit(initial)
        if secret:
            self.edit.setEchoMode(QLineEdit.EchoMode.Password)
        self.edit.setPlaceholderText(field_label)
        self.form.addRow(field_label, self.edit)
        if link:
            b = button(link[0], "ghost", "external", lambda: open_url(link[1]))
            self.add_content(b)

    def validate(self) -> str | None:
        v = self.edit.text().strip()
        if len(v) < 8:
            return _("Значение слишком короткое — проверьте, что скопировали его целиком.")
        if any(ch.isspace() for ch in v):
            return _("Значение не должно содержать пробелов.")
        return None

    def value(self) -> str:
        return self.edit.text().strip()


class FaceitDialog(FormDialog):
    def __init__(self, parent, need_key: bool):
        super().__init__(parent, _("Подключить FACEIT"), ok_text=_("Подключить"), width=520,
                         intro=_("Укажите свой никнейм FACEIT и персональный Data API key (Server-side key из "
                                 "developers.faceit.com). Ключ хранится в Диспетчере учётных данных Windows."))
        self.nick = QLineEdit()
        self.nick.setPlaceholderText(_("Никнейм на FACEIT"))
        self.nick.setMaxLength(40)
        self.key = QLineEdit()
        self.key.setEchoMode(QLineEdit.EchoMode.Password)
        self.key.setPlaceholderText("API key")
        self.need_key = need_key
        self.form.addRow(_("Никнейм"), self.nick)
        self.form.addRow("API key", self.key)
        self.add_content(button(_("Где взять ключ"), "ghost", "external", lambda: open_url("https://developers.faceit.com/")))

    def validate(self) -> str | None:
        if not self.nick.text().strip():
            return _("Введите никнейм.")
        k = self.key.text().strip()
        if self.need_key and not k:
            return _("Введите API key.")
        if k and (len(k) < 16 or any(ch.isspace() for ch in k)):
            return _("API key выглядит неправильно — проверьте, что он скопирован целиком.")
        return None


class AccountCard(Card):
    def __init__(self, ctx, service: str, title: str):
        super().__init__()
        self.ctx, self.service, self.name = ctx, service, title
        self.logo = label("")
        self.logo.setFixedSize(48, 48)
        self.logo.setPixmap(icons.service_logo(service, 48))
        self.title = label(title, "H2")
        self.chip = Chip("", "neutral")
        head = QHBoxLayout()
        head.setSpacing(14)
        col = QVBoxLayout()
        col.setSpacing(4)
        row = QHBoxLayout()
        row.addWidget(self.title)
        row.addWidget(self.chip)
        row.addStretch(1)
        self.user = label("", "H3")
        col.addLayout(row)
        col.addWidget(self.user)
        head.addWidget(self.logo, 0, Qt.AlignmentFlag.AlignTop)
        head.addLayout(col, 1)
        self.body.addLayout(head)
        self.lines = QVBoxLayout()
        self.lines.setSpacing(2)
        self.body.addLayout(self.lines)
        self.note = label("", "Muted", wrap=True)
        self.body.addWidget(self.note)
        self.buttons = QHBoxLayout()
        self.buttons.setSpacing(8)
        self.body.addLayout(self.buttons)
        self._line_labels: list = []

    def set_lines(self, lines: list[str]) -> None:
        clear_layout(self.lines)
        for t in lines:
            self.lines.addWidget(label(t, "Muted"))

    def set_buttons(self, specs: list[tuple]) -> None:
        """specs: (text, kind, icon, callback) или None (пропускается); callback=None — кнопка неактивна."""
        clear_layout(self.buttons)
        for spec in specs:
            if spec is None:
                continue
            text, kind, icon, cb = spec
            b = button(text, kind, icon, cb)
            if cb is None:
                b.setEnabled(False)
            self.buttons.addWidget(b)
        self.buttons.addStretch(1)


class AccountsPage(Page):
    def __init__(self, ctx, parent=None):
        super().__init__(ctx, parent)
        self.waiting = {"steam": False, "spotify": False}
        root = QVBoxLayout(self)
        root.setContentsMargins(28, 22, 28, 28)
        root.setSpacing(16)
        head, _col = self.page_header(_("Подключённые аккаунты"),
                                      _("Только официальные API. Пароли не запрашиваются и не сохраняются."))
        root.addLayout(head)
        self.c_steam = AccountCard(ctx, "steam", "Steam")
        self.c_faceit = AccountCard(ctx, "faceit", "FACEIT")
        self.c_spotify = AccountCard(ctx, "spotify", "Spotify")
        for c in (self.c_steam, self.c_faceit, self.c_spotify):
            root.addWidget(c)
        root.addStretch(1)

        ctx.bus.accounts_changed.connect(self.mark_dirty)
        for ctl in (ctx.steam, ctx.faceit, ctx.spotify):
            ctl.updated.connect(self.mark_dirty)
            ctl.busy_changed.connect(lambda _b: self.mark_dirty())
        ctx.steam.login_state.connect(lambda s: self._login_state("steam", s))
        ctx.spotify.login_state.connect(lambda s: self._login_state("spotify", s))

    def _login_state(self, service: str, state: str) -> None:
        self.waiting[service] = state == "waiting"
        self.mark_dirty()

    def refresh(self) -> None:
        self._steam()
        self._faceit()
        self._spotify()

    # ------------------------------------------------------------------ Steam
    def _steam(self) -> None:
        c, ctl = self.c_steam, self.ctx.steam
        o = ctl.overview()
        if self.waiting["steam"]:
            c.chip.set(_("Ожидание входа…"), "warning")
            c.user.setText("")
            c.set_lines([_("Завершите вход в открывшемся окне браузера на сайте Steam.")])
            c.note.setText("")
            c.set_buttons([(_("Отмена"), None, "x", ctl.cancel_sign_in)])
            return
        if not o.get("linked"):
            c.chip.set(_("Не подключён"), "neutral")
            c.user.setText("")
            c.set_lines([])
            c.note.setText(_("Вход выполняется на официальной странице Steam (OpenID 2.0). Приложение получает только ваш SteamID. "
                             "Для списка игр и достижений дополнительно нужен Steam Web API Key и открытые данные профиля."))
            c.set_buttons([(_("Подключить Steam"), "primary", "link", ctl.sign_in)])
            return
        c.chip.set(_("Подключён"), "success")
        c.user.setText(o.get("name") or "")
        c.set_lines([f"SteamID: {o.get('steamid')}",
                     f"{_('Steam API Key')}: " + (_("сохранён в Диспетчере учётных данных") if o.get("has_key") else _("не задан")),
                     f"{_('Обновлено')}: {human_ago(o.get('updated_at'))}"])
        c.note.setText("" if o.get("has_key") else _("Без API Key доступен только вход; список игр, уровень и достижения не загрузятся."))
        c.set_buttons([(_("Обновить"), None, "refresh", ctl.refresh) if o.get("has_key") else None,
                       (_("API Key…") if not o.get("has_key") else _("Сменить API Key…"), None, "key", self.steam_key),
                       (_("Отключить"), "danger", "power", self.steam_disconnect)])

    def steam_key(self) -> None:
        dlg = SecretDialog(self, "Steam API Key", "API Key",
                           _("Ключ выдаётся на странице steamcommunity.com/dev/apikey. Он хранится только в Диспетчере учётных данных Windows."),
                           (_("Получить ключ"), "https://steamcommunity.com/dev/apikey"))
        if dlg.exec():
            self.ctx.steam.service.set_api_key(dlg.value())
            self.ctx.bus.accounts_changed.emit()
            self.ctx.steam.refresh()

    def steam_disconnect(self) -> None:
        ok, delete_key = confirm_with_option(self, _("Отключить Steam"),
                                             _("Локальные данные Steam (профиль, список игр) будут удалены из приложения."),
                                             _("Удалить сохранённый API Key"))
        if ok:
            self.ctx.steam.disconnect(delete_key)
            self.ctx.log_activity("account", _("Steam отключён"))

    # ------------------------------------------------------------------ FACEIT
    def _faceit(self) -> None:
        c, ctl = self.c_faceit, self.ctx.faceit
        o = ctl.overview()
        if not o.get("linked"):
            c.chip.set(_("Не подключён"), "neutral")
            c.user.setText("")
            c.set_lines(["API Key: " + (_("сохранён") if o.get("has_key") else _("не задан"))])
            c.note.setText(_("Используется официальный FACEIT Data API v4. Нужны никнейм и ваш Data API key. "
                             "Статистика берётся по CS2; ELO по матчам API не отдаёт — история ELO накапливается из обновлений."))
            c.set_buttons([(_("Подключить FACEIT"), "primary", "link", self.faceit_connect)])
            return
        c.chip.set(_("Подключён"), "success")
        c.user.setText(o.get("nickname") or "")
        c.set_lines(["API Key: " + (_("сохранён в Диспетчере учётных данных") if o.get("has_key") else _("не задан")),
                     f"{_('Обновлено')}: {human_ago(o.get('updated_at'))}"])
        c.note.setText("" if o.get("has_key") else _("Без API Key данные не обновляются."))
        busy = ctl.busy
        c.set_buttons([(_("Обновление…") if busy else _("Обновить"), None, "refresh", (lambda: ctl.refresh(True)) if o.get("has_key") and not busy else None),
                       (_("Сменить API Key…") if o.get("has_key") else _("Указать API Key…"), None, "key", self.faceit_key),
                       (_("Отключить"), "danger", "power", self.faceit_disconnect)])

    def faceit_connect(self) -> None:
        ctl = self.ctx.faceit
        dlg = FaceitDialog(self, need_key=not ctl.service.has_key())
        if dlg.exec():
            k = dlg.key.text().strip()
            if k:
                ctl.service.set_api_key(k)
            ctl.link(dlg.nick.text().strip())

    def faceit_key(self) -> None:
        dlg = SecretDialog(self, "FACEIT API Key", "API key", _("Data API key из developers.faceit.com. Хранится в Диспетчере учётных данных Windows."),
                           (_("Где взять ключ"), "https://developers.faceit.com/"))
        if dlg.exec():
            self.ctx.faceit.service.set_api_key(dlg.value())
            self.ctx.bus.accounts_changed.emit()
            self.ctx.faceit.refresh(True)

    def faceit_disconnect(self) -> None:
        ok, delete_key = confirm_with_option(self, _("Отключить FACEIT"),
                                             _("Импортированные матчи FACEIT и история ELO будут удалены из приложения. "
                                               "Матчи, добавленные вручную, останутся."), _("Удалить сохранённый API Key"))
        if ok:
            self.ctx.faceit.disconnect(delete_key)
            self.ctx.log_activity("account", _("FACEIT отключён"))

    # ------------------------------------------------------------------ Spotify
    def _spotify(self) -> None:
        c, ctl = self.c_spotify, self.ctx.spotify
        svc = ctl.service
        cid = svc.client_id()
        if self.waiting["spotify"]:
            c.chip.set(_("Ожидание входа…"), "warning")
            c.user.setText("")
            c.set_lines([_("Разрешите доступ в окне браузера на сайте Spotify.")])
            c.note.setText("")
            c.set_buttons([(_("Отмена"), None, "x", ctl.cancel_connect)])
            return
        note = _("Авторизация OAuth 2.0 PKCE: приложение не видит пароль, токены хранятся в Диспетчере учётных данных. "
                 "В dashboard разработчика Spotify укажите Redirect URI: ") + svc.redirect_uri() + ". " + \
            _("Управление воспроизведением требует Spotify Premium; режим разработки Spotify ограничивает число пользователей приложения.")
        if not ctl.connected:
            c.chip.set(_("Не подключён"), "neutral")
            c.user.setText("")
            c.set_lines(["Client ID: " + (cid[:6] + "…" if cid else _("не задан"))])
            c.note.setText(note)
            c.set_buttons([(_("Подключить Spotify"), "primary", "link", self.spotify_connect),
                           (_("Client ID…"), None, "key", self.spotify_client_id)])
            return
        acc = ctl.service.account() or {}
        c.chip.set(_("Подключён"), "success")
        c.user.setText(acc.get("username") or "")
        c.set_lines([f"Client ID: {cid[:6]}…" if cid else "", f"{_('Подключён')}: {human_ago(acc.get('connected_at'))}"])
        c.note.setText(ctl.status_text if ctl.status in ("premium", "error") else _("Premium нужен только для управления воспроизведением."))
        c.set_buttons([(_("Обновить"), None, "refresh", lambda: (ctl.poll(), ctl.load_playlists())),
                       (_("Отключить"), "danger", "power", self.spotify_disconnect)])

    def spotify_client_id(self) -> bool:
        dlg = SecretDialog(self, "Spotify Client ID", "Client ID",
                           _("Создайте приложение на developer.spotify.com/dashboard, добавьте Redirect URI "
                             "и вставьте его Client ID. Client ID — не секрет, но Client Secret приложению не нужен."),
                           (_("Открыть dashboard Spotify"), "https://developer.spotify.com/dashboard"), secret=False,
                           initial=self.ctx.spotify.service.client_id())
        if dlg.exec():
            self.ctx.settings.set("spotify_client_id", dlg.value())
            self.mark_dirty()
            return True
        return False

    def spotify_connect(self) -> None:
        if not self.ctx.spotify.service.client_id() and not self.spotify_client_id():
            return
        self.ctx.spotify.connect_account()

    def spotify_disconnect(self) -> None:
        if confirm(self, _("Отключить Spotify"), _("Токены доступа будут удалены из Диспетчера учётных данных."), ok=_("Отключить")):
            self.ctx.spotify.disconnect()
            self.ctx.log_activity("account", _("Spotify отключён"))

