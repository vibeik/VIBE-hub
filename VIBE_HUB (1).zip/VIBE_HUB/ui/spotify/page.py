"""Страница Spotify: что играет, управление, плейлисты (Web API, OAuth 2.0 PKCE).

Честные ограничения: управление воспроизведением требует Premium и активного устройства; Spotify не даёт
обычному приложению воспроизводить звук сам — оно управляет уже запущенным клиентом Spotify.
"""
from __future__ import annotations

import logging

from PySide6.QtCore import QTimer, Qt
from PySide6.QtWidgets import QHBoxLayout, QProgressBar, QVBoxLayout, QWidget

from ui.common.base import Banner, Card, Chip, EmptyState, IconButton, Page, button, label
from ui.common.flow import FlowLayout
from ui.common.images import AsyncImage
from ui.common.util import clear_layout, open_url
from utils.format import fmt_ms
from utils.i18n import _
from utils.timeutil import human_ago

log = logging.getLogger("vibehub.spotify.ui")


class PlaylistTile(Card):
    def __init__(self, ctx, pl: dict):
        super().__init__(clickable=True, margins=(10, 10, 10, 10))
        self.setFixedWidth(150)
        self.body.setSpacing(6)
        cover = AsyncImage(128, "rounded", "music", radius=10)
        cover.set_url(pl.get("cover_url"))
        name = label(pl["name"], "H3", wrap=True)
        name.setMaximumHeight(40)
        total = pl.get("total")
        sub = label(f"{total} {_('треков')}" if total is not None else "", "Muted")
        self.body.addWidget(cover, 0, Qt.AlignmentFlag.AlignHCenter)
        self.body.addWidget(name)
        self.body.addWidget(sub)
        self.setToolTip(_("Запустить плейлист (нужен Spotify Premium и активное устройство)"))
        uri = pl.get("uri")
        self.clicked.connect(lambda: ctx.spotify.control("play", uri))


class SpotifyPage(Page):
    def __init__(self, ctx, parent=None):
        super().__init__(ctx, parent)
        self._timer = QTimer(self)
        self._timer.setInterval(1000)
        self._timer.timeout.connect(self._tick)
        root = QVBoxLayout(self)
        root.setContentsMargins(28, 22, 28, 28)
        root.setSpacing(16)

        head, _col = self.page_header("Spotify", _("Что играет сейчас и ваши плейлисты"))
        self.btn_open = button(_("Открыть Spotify"), icon="external", on_click=lambda: open_url("https://open.spotify.com"))
        self.btn_refresh = button(_("Обновить"), "primary", "refresh", self._refresh)
        head.addWidget(self.btn_open)
        head.addWidget(self.btn_refresh)
        root.addLayout(head)

        self.empty = EmptyState(_("Spotify не подключён"),
                                _("Подключение через официальный OAuth 2.0 (PKCE). Понадобится Client ID вашего приложения "
                                  "на developer.spotify.com — подробности в «Подключённые аккаунты»."),
                                icon="headphones", button_text=_("Подключить Spotify"),
                                on_click=lambda: ctx.bus.navigate.emit("accounts"))
        root.addWidget(self.empty)

        self.content = QWidget()
        cl = QVBoxLayout(self.content)
        cl.setContentsMargins(0, 0, 0, 0)
        cl.setSpacing(16)
        root.addWidget(self.content)

        self.banner = Banner("", "warning")
        cl.addWidget(self.banner)
        cl.addWidget(Banner(_("Управление воспроизведением (пауза, переключение, запуск плейлиста) работает только с аккаунтом "
                              "Spotify Premium и при запущенном клиенте Spotify на любом устройстве. Если Spotify откажет — "
                              "приложение покажет причину, а не будет делать вид, что всё получилось."), "info"))

        now = Card(_("Сейчас играет"), "headphones")
        row = QHBoxLayout()
        row.setSpacing(18)
        self.cover = AsyncImage(150, "rounded", "music", radius=14)
        col = QVBoxLayout()
        col.setSpacing(4)
        self.title = label("", "H1", wrap=True)
        self.artist = label("", "H3", wrap=True)
        self.album = label("", "Muted", wrap=True)
        chips = QHBoxLayout()
        self.chip_ctx = Chip("", "accent")
        self.chip_dev = Chip("", "neutral")
        chips.addWidget(self.chip_ctx)
        chips.addWidget(self.chip_dev)
        chips.addStretch(1)
        self.bar = QProgressBar()
        self.bar.setRange(0, 1000)
        self.bar.setTextVisible(False)
        self.times = label("", "Muted")
        ctl = QHBoxLayout()
        ctl.setSpacing(6)
        self.b_prev = IconButton("prev", _("Предыдущий"), size=24, role="text", on_click=lambda: ctx.spotify.control("previous"))
        self.b_play = IconButton("play", _("Пауза / продолжить"), size=28, role="text", on_click=ctx.spotify.toggle_play)
        self.b_next = IconButton("next", _("Следующий"), size=24, role="text", on_click=lambda: ctx.spotify.control("next"))
        for b in (self.b_prev, self.b_play, self.b_next):
            ctl.addWidget(b)
        ctl.addStretch(1)
        for w in (self.title, self.artist, self.album):
            col.addWidget(w)
        col.addLayout(chips)
        col.addStretch(1)
        col.addWidget(self.bar)
        col.addWidget(self.times)
        col.addLayout(ctl)
        row.addWidget(self.cover, 0, Qt.AlignmentFlag.AlignTop)
        row.addLayout(col, 1)
        now.body.addLayout(row)
        cl.addWidget(now)

        self.pl_card = Card(_("Ваши плейлисты"), "list-music")
        self.pl_updated = label("", "Muted")
        self.pl_card.add_header_widget(self.pl_updated)
        self.pl_card.add_header_widget(IconButton("refresh", _("Обновить плейлисты"), size=16, on_click=ctx.spotify.load_playlists))
        self.pl_host = QWidget()
        self.pl_flow = FlowLayout(self.pl_host, hspacing=12, vspacing=12)
        self.pl_empty = label(_("Плейлистов нет или они ещё не загружены."), "Muted")
        self.pl_card.body.addWidget(self.pl_host)
        self.pl_card.body.addWidget(self.pl_empty)
        cl.addWidget(self.pl_card)
        root.addStretch(1)

        sp = ctx.spotify
        sp.state_changed.connect(self._on_state)
        sp.playlists_changed.connect(self._fill_playlists)
        ctx.bus.accounts_changed.connect(self.mark_dirty)

    def activated(self) -> None:
        self._timer.start()
        if self.ctx.spotify.connected:
            self.ctx.spotify.poll()

    def deactivated(self) -> None:
        self._timer.stop()

    def _refresh(self) -> None:
        self.ctx.spotify.poll()
        self.ctx.spotify.load_playlists()

    def refresh(self) -> None:
        connected = self.ctx.spotify.connected
        self.empty.setVisible(not connected)
        self.content.setVisible(connected)
        self.btn_refresh.setVisible(connected)
        if connected:
            self._on_state()
            self._fill_playlists()

    def _on_state(self) -> None:
        ctl = self.ctx.spotify
        if not ctl.connected:
            return
        st = ctl.state
        has = bool(st and st.get("title"))
        for b in (self.b_prev, self.b_play, self.b_next):
            b.setEnabled(has)
        txt = ctl.status_text if ctl.status in ("premium", "idle", "error") else ""
        self.banner.set_text(txt, "error" if ctl.status == "error" else "warning")
        if not has or st is None:
            self.title.setText(_("Ничего не играет"))
            for w in (self.artist, self.album):
                w.setText("")
            self.chip_ctx.setVisible(False)
            self.chip_dev.setVisible(False)
            self.cover.clear_image()
            self.bar.setValue(0)
            self.times.setText("")
            self.b_play.set_icon_name("play")
            return
        self.title.setText(st["title"])
        self.artist.setText(st["artists"])
        self.album.setText(st["album"])
        self.cover.set_url(st.get("cover_url"))
        cname = st.get("context_name")
        self.chip_ctx.setText(cname or "")
        self.chip_ctx.setVisible(bool(cname))
        self.chip_dev.setText(f"{_('Устройство')}: {st['device']}" if st.get("device") else "")
        self.chip_dev.setVisible(bool(st.get("device")))
        self.b_play.set_icon_name("pause" if st["is_playing"] else "play")
        self._tick()

    def _tick(self) -> None:
        st = self.ctx.spotify.state
        if not st or not st.get("duration_ms"):
            return
        pos = self.ctx.spotify.progress_now()
        self.bar.setValue(int(pos / st["duration_ms"] * 1000))
        self.times.setText(f"{fmt_ms(pos)} / {fmt_ms(st['duration_ms'])}")

    def _fill_playlists(self) -> None:
        ctl = self.ctx.spotify
        clear_layout(self.pl_flow)
        for pl in ctl.playlists:
            self.pl_flow.addWidget(PlaylistTile(self.ctx, pl))
        has = bool(ctl.playlists)
        self.pl_host.setVisible(has)
        self.pl_empty.setVisible(not has)
        self.pl_updated.setText(f"{_('Обновлено')}: {human_ago(ctl.playlists_updated_at)}" if has else "")
