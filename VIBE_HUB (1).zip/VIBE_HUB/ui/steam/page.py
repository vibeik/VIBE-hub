"""Страница Steam: профиль, игры, достижения. Только данные, которые отдаёт официальный Web API."""
from __future__ import annotations

import logging

from PySide6.QtCore import Qt
from PySide6.QtWidgets import QHBoxLayout, QLineEdit, QVBoxLayout, QWidget

from ui.common.base import Banner, Card, Chip, EmptyState, Page, StatTile, button, label
from ui.common.images import AsyncImage
from ui.common.tables import ALIGN_C, ALIGN_R, cell, make_table
from ui.common.util import clear_layout, fmt_dt, open_url
from utils.format import fmt_minutes
from utils.i18n import _
from utils.timeutil import from_epoch_s, human_ago

log = logging.getLogger("vibehub.steam.ui")
VISIBILITY = {1: "Скрытый", 2: "Только друзья", 3: "Открытый"}
ROW_LIMIT = 400


class SteamPage(Page):
    def __init__(self, ctx, parent=None):
        super().__init__(ctx, parent)
        self._ach_appid: int | None = None
        self._games: list[dict] = []
        self._profile_url: str | None = None
        root = QVBoxLayout(self)
        root.setContentsMargins(28, 22, 28, 28)
        root.setSpacing(16)

        head, _col = self.page_header("Steam", _("Профиль, игры и достижения через официальный Steam Web API"))
        self.btn_open = button(_("Открыть профиль"), icon="external", on_click=lambda: open_url(self._profile_url))
        self.btn_refresh = button(_("Обновить"), "primary", "refresh", self._refresh)
        head.addWidget(self.btn_open)
        head.addWidget(self.btn_refresh)
        root.addLayout(head)

        self.empty = EmptyState(_("Steam не подключён"),
                                _("Вход выполняется на официальной странице Steam (OpenID). Приложение не видит ваш пароль."),
                                icon="gamepad", button_text=_("Подключить Steam"),
                                on_click=lambda: ctx.bus.navigate.emit("accounts"))
        root.addWidget(self.empty)

        self.content = QWidget()
        cl = QVBoxLayout(self.content)
        cl.setContentsMargins(0, 0, 0, 0)
        cl.setSpacing(16)
        root.addWidget(self.content)

        prof = Card()
        row = QHBoxLayout()
        row.setSpacing(16)
        self.avatar = AsyncImage(72)
        col = QVBoxLayout()
        col.setSpacing(4)
        self.name = label("", "H2")
        chips = QHBoxLayout()
        self.chip_level = Chip("", "accent")
        self.chip_vis = Chip("", "neutral")
        chips.addWidget(self.chip_level)
        chips.addWidget(self.chip_vis)
        chips.addStretch(1)
        self.playing = label("", "Muted")
        self.updated = label("", "Muted")
        for w in (self.name,):
            col.addWidget(w)
        col.addLayout(chips)
        col.addWidget(self.playing)
        col.addWidget(self.updated)
        row.addWidget(self.avatar, 0, Qt.AlignmentFlag.AlignTop)
        row.addLayout(col, 1)
        prof.body.addLayout(row)
        cl.addWidget(prof)

        self.notes = QVBoxLayout()
        self.notes.setSpacing(8)
        cl.addLayout(self.notes)

        tiles = QHBoxLayout()
        tiles.setSpacing(12)
        self.t_games, self.t_hours, self.t_recent = StatTile(_("Игр в библиотеке")), StatTile(_("Часов всего")), StatTile(_("За 2 недели"))
        for t in (self.t_games, self.t_hours, self.t_recent):
            tiles.addWidget(t, 1)
        cl.addLayout(tiles)

        self.games_card = Card(_("Игры"), "gamepad")
        self.search = QLineEdit()
        self.search.setPlaceholderText(_("Поиск по названию"))
        self.search.setClearButtonEnabled(True)
        self.search.textChanged.connect(lambda _t: self._fill_games())
        self.games_card.body.addWidget(self.search)
        self.table = make_table([_("Игра"), _("Всего"), _("За 2 недели"), _("Последний запуск")], stretch_col=0)
        self.table.setVerticalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAsNeeded)
        self.table.setFixedHeight(330)
        self.table.itemSelectionChanged.connect(self._on_select)
        self.games_card.body.addWidget(self.table)
        self.games_hint = label("", "Muted", wrap=True)
        self.games_card.body.addWidget(self.games_hint)
        cl.addWidget(self.games_card)

        self.ach_card = Card(_("Достижения"), "trophy")
        self.ach_status = label("", "Muted", wrap=True)
        self.ach_table = make_table([_("Достижение"), _("Описание"), _("Получено")], stretch_col=1)
        self.ach_table.setVerticalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAsNeeded)
        self.ach_table.setFixedHeight(300)
        self.ach_card.body.addWidget(self.ach_status)
        self.ach_card.body.addWidget(self.ach_table)
        self.ach_card.setVisible(False)
        cl.addWidget(self.ach_card)
        root.addStretch(1)

        ctl = ctx.steam
        ctl.updated.connect(self.mark_dirty)
        ctl.busy_changed.connect(self._on_busy)
        ctl.achievements_ready.connect(self._on_ach)
        ctl.achievements_failed.connect(self._on_ach_failed)
        ctx.bus.accounts_changed.connect(self.mark_dirty)

    # ------------------------------------------------------------------ действия
    def _refresh(self) -> None:
        self.ctx.steam.refresh()

    def _on_busy(self, busy: bool) -> None:
        self.btn_refresh.setEnabled(not busy)
        self.btn_refresh.setText(_("Обновление…") if busy else _("Обновить"))

    def refresh(self) -> None:
        o = self.ctx.steam.overview()
        linked = bool(o.get("linked"))
        self.empty.setVisible(not linked)
        self.content.setVisible(linked)
        self.btn_open.setVisible(linked)
        self.btn_refresh.setVisible(linked)
        if not linked:
            return
        self._profile_url = o.get("profile_url")
        self.btn_open.setEnabled(bool(self._profile_url))
        self.avatar.set_url(o.get("avatar"))
        self.name.setText(o.get("name") or "—")
        self.chip_level.setText(f"Level {o['level']}" if o.get("level") is not None else "Level —")
        vis = o.get("visibility")
        self.chip_vis.set(_(VISIBILITY.get(vis, "Статус неизвестен")), "success" if vis == 3 else "warning" if vis else "neutral")
        self.playing.setText(f"{_('Сейчас играет')}: {o['playing']}" if o.get("playing") else _("Сейчас не в игре"))
        self.updated.setText(f"{_('Обновлено')}: {human_ago(o.get('updated_at'))}")
        clear_layout(self.notes)
        for n in o.get("notes") or []:
            self.notes.addWidget(Banner(n, "info" if not o.get("private") else "warning"))
        self._games = self.ctx.repos.steam.games()
        has = bool(self._games)
        self.t_games.set_value(str(o["games_count"]) if has else "—")
        self.t_hours.set_value(fmt_minutes(o["total_minutes"]) if has else "—")
        two = sum(g["playtime_2weeks"] for g in self._games)
        self.t_recent.set_value(fmt_minutes(two) if has else "—")
        self.games_card.setVisible(True)
        self.search.setEnabled(has)
        self.games_hint.setText("" if has else _("Список игр недоступен: нужен Steam API Key и открытые «Сведения об играх» в приватности профиля."))
        self.games_hint.setVisible(not has)
        self.table.setVisible(has)
        self.search.setVisible(has)
        self._fill_games()

    def _fill_games(self) -> None:
        q = self.search.text().strip().lower()
        rows = [g for g in self._games if q in g["name"].lower()] if q else self._games
        rows = rows[:ROW_LIMIT]
        t = self.table
        t.blockSignals(True)
        t.setRowCount(len(rows))
        for r, g in enumerate(rows):
            t.setItem(r, 0, cell(g["name"], data=g["appid"]))
            t.setItem(r, 1, cell(fmt_minutes(g["playtime_forever"]), align=ALIGN_R))
            t.setItem(r, 2, cell(fmt_minutes(g["playtime_2weeks"]) if g["playtime_2weeks"] else "—", align=ALIGN_R))
            lp = g.get("last_played")
            t.setItem(r, 3, cell(fmt_dt(from_epoch_s(lp).strftime("%Y-%m-%d %H:%M:%S"), True) if lp else "—", align=ALIGN_C))
        t.blockSignals(False)

    # ------------------------------------------------------------------ достижения
    def _on_select(self) -> None:
        items = self.table.selectedItems()
        if not items:
            return
        row = items[0].row()
        first = self.table.item(row, 0)
        if first is None:
            return
        appid = first.data(Qt.ItemDataRole.UserRole)
        if appid is None:
            return
        self._ach_appid = int(appid)
        self.ach_card.setVisible(True)
        self.ach_card.set_title(f"{_('Достижения')}: {first.text()}")
        self.ach_table.setRowCount(0)
        self.ach_status.setText(_("Загрузка…"))
        self.ctx.steam.load_achievements(self._ach_appid)

    def _on_ach(self, appid: int, data: dict) -> None:
        if appid != self._ach_appid:
            return
        items = data.get("items") or []
        self.ach_status.setText(f"{_('Получено')} {data.get('unlocked', 0)} {_('из')} {data.get('total', 0)}" if items
                                else _("У этой игры нет достижений."))
        t = self.ach_table
        t.setRowCount(len(items))
        for r, a in enumerate(sorted(items, key=lambda x: (not x["achieved"], x["name"]))):
            t.setItem(r, 0, cell(a["name"], tone=None if a["achieved"] else "muted"))
            t.setItem(r, 1, cell(a["desc"] or "—", tone="muted"))
            when = from_epoch_s(a["unlock_time"]).strftime("%d.%m.%Y") if a["achieved"] and a["unlock_time"] else ("✓" if a["achieved"] else "—")
            t.setItem(r, 2, cell(when, align=ALIGN_C, tone="success" if a["achieved"] else None))

    def _on_ach_failed(self, appid: int, msg: str) -> None:
        if appid != self._ach_appid:
            return
        self.ach_table.setRowCount(0)
        self.ach_status.setText(msg)
