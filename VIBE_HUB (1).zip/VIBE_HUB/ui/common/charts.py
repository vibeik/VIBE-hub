"""Графики и индикаторы.

* RingGauge, Sparkline — лёгкие виджеты на QPainter (для карточек, обновляются часто).
* ChartWidget — интерактивные графики на PyQtGraph (линии, столбцы, «живой» график реального времени),
  стилизованные под тему, с подсказкой при наведении и состоянием «нет данных».
"""
from __future__ import annotations

import html
import logging
from typing import Callable, Sequence

import numpy as np
import pyqtgraph as pg
from PySide6.QtCore import QEasingCurve, QPointF, QRectF, QSize, Qt, QVariantAnimation
from PySide6.QtGui import QColor, QFont, QLinearGradient, QPainter, QPainterPath, QPen
from PySide6.QtWidgets import QHBoxLayout, QLabel, QSizePolicy, QStackedLayout, QVBoxLayout, QWidget

from ui import theme
from utils.i18n import _

log = logging.getLogger("vibehub.charts")
pg.setConfigOptions(antialias=True, foreground="#8D8DA6")


def _color(name: str) -> QColor:
    """'accent' | 'success' | '#RRGGBB' -> QColor."""
    if name.startswith("#"):
        return QColor(name)
    return QColor(theme.get().colors.get(name, name))


# =========================================================================== RingGauge
class RingGauge(QWidget):
    """Круговой индикатор. value=None — «нет данных» (пустое кольцо и прочерк)."""

    def __init__(self, parent: QWidget | None = None, *, thickness: float = 10.0, maximum: float = 100.0,
                 thresholds: tuple[float, float] | None = (75.0, 90.0), unit: str = "%", decimals: int = 0,
                 color_role: str = "accent"):
        super().__init__(parent)
        self._thickness = thickness
        self._max = float(maximum)
        self._thr = thresholds
        self._unit = unit
        self._decimals = decimals
        self._role = color_role
        self._value: float | None = None
        self._shown = 0.0
        self._text = "—"
        self._sub = ""
        self._anim = QVariantAnimation(self)
        self._anim.setDuration(380)
        self._anim.setEasingCurve(QEasingCurve.Type.OutCubic)
        self._anim.valueChanged.connect(self._on_anim)
        self.setMinimumSize(64, 64)
        self.setSizePolicy(QSizePolicy.Policy.Preferred, QSizePolicy.Policy.Preferred)

    def sizeHint(self) -> QSize:
        return QSize(110, 110)

    def _on_anim(self, v) -> None:
        self._shown = float(v)
        self.update()

    def format_value(self, v: float) -> str:
        return f"{v:.{self._decimals}f}{self._unit}"

    def set_value(self, value: float | None, text: str | None = None, sub: str = "") -> None:
        self._sub = sub
        if value is None:
            self._anim.stop()
            self._value, self._shown = None, 0.0
            self._text = text if text is not None else "—"
            self.update()
            return
        v = max(0.0, min(float(value), self._max))
        self._text = text if text is not None else self.format_value(float(value))
        if self._value is None or not theme.get().animations or abs(v - self._value) < 0.05:
            self._anim.stop()
            self._value = self._shown = v
        else:
            self._anim.stop()
            self._anim.setStartValue(self._shown)
            self._anim.setEndValue(v)
            self._value = v
            self._anim.start()
        self.update()

    def _arc_color(self, v: float) -> QColor:
        c = theme.get().colors
        if self._thr:
            warn, crit = self._thr
            if v >= crit:
                return QColor(c["danger"])
            if v >= warn:
                return QColor(c["warning"])
        return QColor(c.get(self._role, c["accent"]))

    def paintEvent(self, _e) -> None:
        p = QPainter(self)
        p.setRenderHint(QPainter.RenderHint.Antialiasing)
        c = theme.get().colors
        w, h = self.width(), self.height()
        side = float(min(w, h))
        t = max(5.0, min(self._thickness, side * 0.13))
        pad = t / 2 + 3
        rect = QRectF((w - side) / 2 + pad, (h - side) / 2 + pad, side - 2 * pad, side - 2 * pad)

        track = QPen(QColor(255, 255, 255, 24), t)
        p.setPen(track)
        p.setBrush(Qt.BrushStyle.NoBrush)
        p.drawEllipse(rect)

        if self._value is not None and self._shown > 0.0:
            span = int(-(self._shown / self._max) * 360 * 16)
            col = self._arc_color(self._shown)
            glow = QColor(col)
            glow.setAlpha(44)
            pen = QPen(glow, t + 6)
            pen.setCapStyle(Qt.PenCapStyle.RoundCap)
            p.setPen(pen)
            p.drawArc(rect, 90 * 16, span)
            pen = QPen(col, t)
            pen.setCapStyle(Qt.PenCapStyle.RoundCap)
            p.setPen(pen)
            p.drawArc(rect, 90 * 16, span)

        inner = rect.adjusted(t + 2, t + 2, -(t + 2), -(t + 2))
        f = QFont(self.font())
        f.setPixelSize(max(10, int(side * (0.2 if self._sub else 0.23))))
        f.setWeight(QFont.Weight.DemiBold)
        p.setFont(f)
        p.setPen(QColor(c["text"] if self._value is not None else c["muted"]))
        if self._sub:
            top = QRectF(inner.x(), inner.y(), inner.width(), inner.height() * 0.58)
            p.drawText(top, int(Qt.AlignmentFlag.AlignHCenter | Qt.AlignmentFlag.AlignBottom), self._text)
            f2 = QFont(f)
            f2.setPixelSize(max(9, int(side * 0.1)))
            f2.setWeight(QFont.Weight.Normal)
            p.setFont(f2)
            p.setPen(QColor(c["muted"]))
            bot = QRectF(inner.x(), inner.y() + inner.height() * 0.6, inner.width(), inner.height() * 0.4)
            p.drawText(bot, int(Qt.AlignmentFlag.AlignHCenter | Qt.AlignmentFlag.AlignTop), self._sub)
        else:
            p.drawText(inner, int(Qt.AlignmentFlag.AlignCenter), self._text)
        p.end()


# =========================================================================== Sparkline
class Sparkline(QWidget):
    """Мини-график без осей. None в данных — разрыв линии."""

    def __init__(self, parent: QWidget | None = None, *, color_role: str = "accent", fill: bool = True):
        super().__init__(parent)
        self._vals: list[float | None] = []
        self._vmin: float | None = None
        self._vmax: float | None = None
        self._role = color_role
        self._fill = fill
        self.setMinimumHeight(28)
        self.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Preferred)

    def set_data(self, values: Sequence[float | None], vmin: float | None = None, vmax: float | None = None) -> None:
        self._vals = list(values)
        self._vmin, self._vmax = vmin, vmax
        self.update()

    def paintEvent(self, _e) -> None:
        p = QPainter(self)
        p.setRenderHint(QPainter.RenderHint.Antialiasing)
        w, h = self.width(), self.height()
        col = _color(self._role)
        real = [v for v in self._vals if v is not None]
        if len(self._vals) < 2 or not real:
            base = QColor(255, 255, 255, 28)
            p.setPen(QPen(base, 1, Qt.PenStyle.DashLine))
            p.drawLine(0, h - 2, w, h - 2)
            p.end()
            return
        lo = self._vmin if self._vmin is not None else min(real)
        hi = self._vmax if self._vmax is not None else max(real)
        if hi - lo < 1e-9:
            hi = lo + 1.0
        n = len(self._vals)
        path = QPainterPath()
        pts: list[QPointF | None] = []
        pen_down = False
        for i, v in enumerate(self._vals):
            if v is None:
                pts.append(None)
                pen_down = False
                continue
            x = i / (n - 1) * (w - 2) + 1
            y = (h - 3) - (max(lo, min(hi, v)) - lo) / (hi - lo) * (h - 6)
            pt = QPointF(x, y)
            pts.append(pt)
            if pen_down:
                path.lineTo(pt)
            else:
                path.moveTo(pt)
                pen_down = True
        if self._fill and all(pt is not None for pt in pts):
            fp = QPainterPath(path)
            fp.lineTo(QPointF(pts[-1].x(), h))
            fp.lineTo(QPointF(pts[0].x(), h))
            fp.closeSubpath()
            g = QLinearGradient(0, 0, 0, h)
            top = QColor(col)
            top.setAlpha(80)
            bottom = QColor(col)
            bottom.setAlpha(0)
            g.setColorAt(0, top)
            g.setColorAt(1, bottom)
            p.fillPath(fp, g)
        pen = QPen(col, 1.8)
        pen.setCapStyle(Qt.PenCapStyle.RoundCap)
        pen.setJoinStyle(Qt.PenJoinStyle.RoundJoin)
        p.setPen(pen)
        p.drawPath(path)
        p.end()


# =========================================================================== ChartWidget (PyQtGraph)
class _Plot(pg.PlotWidget):
    """PlotWidget, не перехватывающий колесо мыши (чтобы страница с графиком продолжала прокручиваться)."""

    def wheelEvent(self, ev) -> None:
        ev.ignore()


class ChartWidget(QWidget):
    """Интерактивный график в стиле приложения.

    plot_lines(series, x_labels=None, y_range=None)  — линии (series: [{name, x, y, color, fill, fmt}])
    plot_bars(series, x_labels, stacked=False)       — столбцы (series: [{name, y, color}])
    prepare_live(defs, y_range) + update_live(x, ys) — график реального времени
    show_empty(text)                                  — состояние «нет данных»
    y=None в данных — разрыв линии / пропуск.
    """

    def __init__(self, parent: QWidget | None = None, *, date_axis: bool = False, show_legend: bool = True,
                 min_height: int = 150, y_axis_width: int = 46, hover: bool = True,
                 empty_text: str = ""):
        super().__init__(parent)
        self._date_axis = date_axis
        self._show_legend = show_legend
        self._hover_on = hover
        self._axis_w = y_axis_width
        self._empty_text = empty_text or _("Нет данных")
        self._replay: tuple[str, tuple, dict] | None = None
        self._hover_xs: np.ndarray | None = None
        self._hover_rows: list[tuple[str, np.ndarray, str, Callable | str | None]] = []
        self._hover_labels: list[str] | None = None
        self._hover_failed = False
        self._live: list[tuple[pg.PlotDataItem, dict]] = []

        self.plot = _Plot(axisItems={"bottom": pg.DateAxisItem(orientation="bottom")}) if date_axis else _Plot()
        self.plot.setMinimumHeight(min_height)

        self._legend = QWidget()
        self._legend_lay = QHBoxLayout(self._legend)
        self._legend_lay.setContentsMargins(0, 0, 0, 0)
        self._legend_lay.setSpacing(14)
        self._legend.setVisible(False)

        self._empty = QLabel(self._empty_text)
        self._empty.setObjectName("Muted")
        self._empty.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self._empty.setWordWrap(True)

        self._stack = QStackedLayout()
        self._stack.addWidget(self.plot)
        self._stack.addWidget(self._empty)

        lay = QVBoxLayout(self)
        lay.setContentsMargins(0, 0, 0, 0)
        lay.setSpacing(6)
        lay.addWidget(self._legend)
        lay.addLayout(self._stack, 1)

        self._vline = pg.InfiniteLine(angle=90, movable=False, pen=pg.mkPen(QColor(255, 255, 255, 60), width=1))
        self._tip = pg.TextItem(anchor=(0, 0), fill=QColor(20, 20, 32, 235), border=pg.mkPen(QColor(255, 255, 255, 40)))
        self._style()
        if hover:
            self.plot.scene().sigMouseMoved.connect(self._on_mouse)
        theme.get().changed.connect(self._on_theme)
        self.show_empty()

    # ------------------------------------------------------------------ оформление
    def _style(self) -> None:
        c = theme.get().colors
        pi = self.plot.getPlotItem()
        self.plot.setBackground(None)
        font = QFont(self.font())
        font.setPixelSize(10)
        for name in ("left", "bottom"):
            ax = pi.getAxis(name)
            ax.setPen(pg.mkPen(QColor(255, 255, 255, 28)))
            ax.setTextPen(pg.mkPen(QColor(c["muted"])))
            ax.setTickFont(font)
        pi.getAxis("left").setWidth(self._axis_w)
        pi.showGrid(x=False, y=True, alpha=0.10)
        pi.hideButtons()
        pi.setMenuEnabled(False)
        pi.vb.setMenuEnabled(False)
        pi.vb.setMouseEnabled(x=False, y=False)
        self._tip.setColor(QColor(c["text"]))

    def _on_theme(self) -> None:
        self._style()
        if self._live:
            for curve, d in self._live:
                curve.setPen(pg.mkPen(_color(d["color"]), width=d.get("width", 2)))
            self._set_legend([(d["name"], d["color"]) for _c, d in self._live if d.get("name")])
        elif self._replay:
            name, a, k = self._replay
            getattr(self, name)(*a, **k)

    def _set_legend(self, items: list[tuple[str, str]]) -> None:
        while self._legend_lay.count():
            it = self._legend_lay.takeAt(0)
            if it.widget():
                it.widget().deleteLater()
        if not self._show_legend or len(items) < 2:
            self._legend.setVisible(False)
            return
        for name, col in items:
            lb = QLabel(f'<span style="color:{_color(col).name()}">●</span>&nbsp;{html.escape(name)}')
            lb.setObjectName("Muted")
            lb.setTextFormat(Qt.TextFormat.RichText)
            self._legend_lay.addWidget(lb)
        self._legend_lay.addStretch(1)
        self._legend.setVisible(True)

    def _reset_plot(self) -> pg.PlotItem:
        pi = self.plot.getPlotItem()
        pi.clear()
        self._live = []
        self._hover_xs = None
        self._hover_rows = []
        pi.addItem(self._vline, ignoreBounds=True)
        pi.addItem(self._tip, ignoreBounds=True)
        self._vline.hide()
        self._tip.hide()
        return pi

    # ------------------------------------------------------------------ публичный API
    def show_empty(self, text: str | None = None) -> None:
        self._empty.setText(text or self._empty_text)
        self._stack.setCurrentWidget(self._empty)
        self._replay = None
        self._set_legend([])

    def clear(self) -> None:
        self.show_empty()

    def _set_x_ticks(self, labels: Sequence[str] | None) -> None:
        ax = self.plot.getPlotItem().getAxis("bottom")
        if labels is None:
            ax.setTicks(None)
            return
        n = len(labels)
        step = max(1, int(np.ceil(n / 8)))
        ax.setTicks([[(i, str(s)) for i, s in enumerate(labels) if i % step == 0]])

    @staticmethod
    def _nice_range(lo: float, hi: float) -> tuple[float, float]:
        if hi - lo < 1e-9:
            pad = max(1.0, abs(hi) * 0.05)
            return lo - pad, hi + pad
        pad = (hi - lo) * 0.12
        return lo - pad, hi + pad

    def plot_lines(self, series: list[dict], *, x_labels: Sequence[str] | None = None,
                   y_range: tuple[float, float] | None = None) -> None:
        self._replay = ("plot_lines", (series,), {"x_labels": x_labels, "y_range": y_range})
        prepared = []
        for s in series:
            y_raw = list(s.get("y") or [])
            if not y_raw:
                continue
            x = np.asarray(s["x"] if s.get("x") is not None else range(len(y_raw)), dtype=float)
            y = np.array([np.nan if v is None else float(v) for v in y_raw], dtype=float)
            if len(x) != len(y) or np.isnan(y).all():
                continue
            prepared.append((s, x, y))
        if not prepared:
            self.show_empty()
            self._replay = ("plot_lines", (series,), {"x_labels": x_labels, "y_range": y_range})
            return
        pi = self._reset_plot()
        all_x = np.concatenate([x for _s, x, _y in prepared])
        all_y = np.concatenate([y[~np.isnan(y)] for _s, _x, y in prepared])
        lo, hi = y_range if y_range else self._nice_range(float(all_y.min()), float(all_y.max()))
        for s, x, y in prepared:
            col = _color(s.get("color", "accent"))
            kw: dict = {}
            if len(x) <= 40:
                kw.update(symbol="o", symbolSize=6, symbolBrush=col, symbolPen=pg.mkPen(None))
            if s.get("fill") and not np.isnan(y).any():
                fc = QColor(col)
                fc.setAlpha(46)
                kw.update(fillLevel=lo, fillBrush=pg.mkBrush(fc))
            pi.plot(x, y, pen=pg.mkPen(col, width=s.get("width", 2)), connect="finite", **kw)
        xmin, xmax = float(all_x.min()), float(all_x.max())
        if x_labels is not None:
            pad = 0.5
        else:
            span = xmax - xmin
            pad = span * 0.04 if span > 0 else (3600.0 if self._date_axis else 1.0)
        pi.setXRange(xmin - pad, xmax + pad, padding=0)
        pi.setYRange(lo, hi, padding=0)
        self._set_x_ticks(x_labels)
        self._set_legend([(s["name"], s.get("color", "accent")) for s, _x, _y in prepared if s.get("name")])
        # данные для подсказки
        self._hover_xs = prepared[0][1]
        self._hover_labels = list(x_labels) if x_labels is not None else None
        self._hover_rows = [(s.get("name") or "", y, s.get("color", "accent"), s.get("fmt")) for s, _x, y in prepared]
        self._stack.setCurrentWidget(self.plot)

    def plot_bars(self, series: list[dict], x_labels: Sequence[str], *, stacked: bool = False,
                  y_range: tuple[float, float] | None = None) -> None:
        self._replay = ("plot_bars", (series, x_labels), {"stacked": stacked, "y_range": y_range})
        n = len(x_labels)
        vals = [np.array([0.0 if v is None else float(v) for v in s.get("y", [])], dtype=float) for s in series]
        if n == 0 or not vals or any(len(v) != n for v in vals) or not any(v.any() for v in vals):
            self.show_empty()
            self._replay = ("plot_bars", (series, x_labels), {"stacked": stacked, "y_range": y_range})
            return
        pi = self._reset_plot()
        xs = np.arange(n, dtype=float)
        k = len(series)
        width = 0.62
        bottoms = np.zeros(n)
        for i, (s, v) in enumerate(zip(series, vals)):
            col = _color(s.get("color", "accent"))
            if stacked:
                x0, x1 = xs - width / 2, xs + width / 2
                y0, y1 = bottoms.copy(), bottoms + v
                bottoms = bottoms + v
            else:
                bw = width / k
                centre = xs + (i - (k - 1) / 2) * bw
                x0, x1, y0, y1 = centre - bw / 2 * 0.92, centre + bw / 2 * 0.92, np.zeros(n), v
            pi.addItem(pg.BarGraphItem(x0=x0, x1=x1, y0=y0, y1=y1, brush=pg.mkBrush(col), pen=pg.mkPen(None)))
        top = float(bottoms.max()) if stacked else float(max(v.max() for v in vals))
        lo, hi = y_range if y_range else (0.0, max(top * 1.15, 1.0))
        pi.setXRange(-0.6, n - 0.4, padding=0)
        pi.setYRange(lo, hi, padding=0)
        self._set_x_ticks(x_labels)
        self._set_legend([(s["name"], s.get("color", "accent")) for s in series if s.get("name")])
        self._hover_xs = xs
        self._hover_labels = list(x_labels)
        self._hover_rows = [(s.get("name") or "", v, s.get("color", "accent"), s.get("fmt") or "{:g}")
                            for s, v in zip(series, vals)]
        self._stack.setCurrentWidget(self.plot)

    # ---- реальное время
    def prepare_live(self, defs: list[dict], y_range: tuple[float, float] = (0, 100)) -> None:
        """defs: [{name, color, width}]. Затем update_live(x, [y1, y2, ...])."""
        self._replay = None
        pi = self._reset_plot()
        self._live = []
        for d in defs:
            curve = pi.plot(pen=pg.mkPen(_color(d["color"]), width=d.get("width", 2)), connect="finite")
            self._live.append((curve, d))
        pi.setYRange(*y_range, padding=0)
        self._set_x_ticks(None)
        self._set_legend([(d["name"], d["color"]) for d in defs if d.get("name")])
        self._hover_xs = None
        self._stack.setCurrentWidget(self.plot)

    def update_live(self, x: Sequence[float], ys: list[Sequence[float | None]]) -> None:
        if not self._live or len(x) < 2:
            return
        xa = np.asarray(x, dtype=float)
        for (curve, _d), y in zip(self._live, ys):
            curve.setData(xa, np.array([np.nan if v is None else float(v) for v in y], dtype=float))
        self.plot.getPlotItem().setXRange(float(xa.min()), float(xa.max()), padding=0)

    def set_y_range(self, lo: float, hi: float) -> None:
        self.plot.getPlotItem().setYRange(lo, hi, padding=0)

    def set_y_formatter(self, fmt: Callable[[float], str] | None) -> None:
        """Пользовательские подписи оси Y (например, «1.2 МБ/с»)."""
        ax = self.plot.getPlotItem().getAxis("left")
        if fmt is None:
            ax.tickStrings = type(ax).tickStrings.__get__(ax)  # вернуть стандартный метод
            return
        ax.tickStrings = lambda values, scale, spacing: [fmt(v) for v in values]

    # ------------------------------------------------------------------ подсказка при наведении
    def _on_mouse(self, pos) -> None:
        if not self._hover_on or self._hover_failed:
            return
        try:
            if self._hover_xs is None or not self._hover_rows or self._stack.currentWidget() is not self.plot:
                return
            pi = self.plot.getPlotItem()
            vb = pi.vb
            if not vb.sceneBoundingRect().contains(pos):
                self._vline.hide()
                self._tip.hide()
                return
            x = vb.mapSceneToView(pos).x()
            idx = int(np.argmin(np.abs(self._hover_xs - x)))
            xv = float(self._hover_xs[idx])
            head = ""
            if self._hover_labels and 0 <= idx < len(self._hover_labels):
                head = html.escape(str(self._hover_labels[idx]))
            elif self._date_axis:
                from datetime import datetime
                head = datetime.fromtimestamp(xv).strftime("%d.%m %H:%M")
            rows = []
            for name, y, col, fmt in self._hover_rows:
                if idx >= len(y) or np.isnan(y[idx]):
                    continue
                v = float(y[idx])
                txt = fmt(v) if callable(fmt) else (fmt.format(v) if fmt else f"{v:.2f}".rstrip("0").rstrip("."))
                rows.append(f'<span style="color:{_color(col).name()}">●</span> {html.escape(name)} <b>{txt}</b>'.replace("  ", " "))
            if not rows:
                self._vline.hide()
                self._tip.hide()
                return
            body = "<br>".join(rows)
            self._tip.setHtml('<div style="font-size:11px;color:#ECECF5">' + (f"<b>{head}</b><br>" if head else "") + body + "</div>")
            xr, yr = vb.viewRange()
            self._tip.setAnchor((1, 0) if xv > (xr[0] + xr[1]) / 2 else (0, 0))
            self._tip.setPos(xv, yr[1])
            self._vline.setPos(xv)
            self._vline.show()
            self._tip.show()
        except Exception:
            self._hover_failed = True
            log.exception("Подсказка графика отключена из-за ошибки")
