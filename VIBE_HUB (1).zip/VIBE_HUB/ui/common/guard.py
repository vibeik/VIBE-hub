"""Страховка от «мигающих окон»: виджет без родителя, которому вызвали show(), становится отдельным окном."""
from __future__ import annotations

import logging

from PySide6.QtCore import QEvent, QObject, Qt, QTimer
from PySide6.QtWidgets import QDialog, QMainWindow, QMenu, QWidget

log = logging.getLogger("vibehub.guard")


class StrayWindowGuard(QObject):
    """Прячет случайные окна верхнего уровня и записывает в журнал, какой виджет их породил.

    Настоящие окна приложения (QMainWindow, QDialog, меню, всплывающие подсказки и списки) не затрагиваются.
    """

    def __init__(self, parent: QObject | None = None):
        super().__init__(parent)
        self._reported: set[str] = set()

    def eventFilter(self, obj: QObject, ev: QEvent) -> bool:
        if ev.type() == QEvent.Type.Show and isinstance(obj, QWidget) and obj.isWindow():
            if not isinstance(obj, (QMainWindow, QDialog, QMenu)) and obj.windowType() == Qt.WindowType.Window:
                name = type(obj).__name__
                if name not in self._reported:
                    self._reported.add(name)
                    log.warning("Случайное окно верхнего уровня скрыто: %s (objectName=%r)", name, obj.objectName())
                QTimer.singleShot(0, lambda w=obj: self._hide_if_still_window(w))
        return False

    @staticmethod
    def _hide_if_still_window(w: QWidget) -> None:
        try:
            if w.isWindow():       # к этому моменту виджет мог получить родителя — тогда он уже не окно
                w.hide()
        except RuntimeError:       # объект уже удалён
            pass
