"""Мелкие помощники для виджетов."""
from __future__ import annotations

import logging
from pathlib import Path
from typing import Callable

from PySide6.QtCore import QObject, QUrl
from PySide6.QtGui import QDesktopServices
from PySide6.QtWidgets import QLayout, QWidget

log = logging.getLogger("vibehub.ui")


def clear_layout(layout: QLayout | None) -> None:
    """Удаляет все элементы layout вместе с виджетами."""
    if layout is None:
        return
    while layout.count():
        item = layout.takeAt(0)
        w = item.widget()
        if w is not None:
            w.setParent(None)
            w.deleteLater()
        elif item.layout() is not None:
            clear_layout(item.layout())


def set_shown(widget: QWidget, shown: bool) -> None:
    """setVisible, безопасный для виджета без родителя.

    Показать (setVisible(True)) виджет, который ещё не лежит ни в каком layout, значит открыть его отдельным окном —
    пользователь видит мигающее окно. Поэтому без родителя показ откладывается: layout покажет виджет сам.
    """
    if shown and widget.parentWidget() is None:
        return
    widget.setVisible(shown)


def set_prop(widget: QWidget, name: str, value) -> None:
    """Меняет динамическое свойство и пере-применяет QSS (иначе селектор [prop=...] не сработает)."""
    if widget.property(name) == value:
        return
    widget.setProperty(name, value)
    st = widget.style()
    st.unpolish(widget)
    st.polish(widget)
    widget.update()


def open_url(url: str | None) -> bool:
    """Открывает ссылку в браузере. Только http(s) — никаких file:// и прочих схем."""
    if not url:
        return False
    low = url.strip().lower()
    if not (low.startswith("https://") or low.startswith("http://127.0.0.1")):
        log.warning("Отказ открыть ссылку с недопустимой схемой")
        return False
    return QDesktopServices.openUrl(QUrl(url.strip()))


def open_path(path: str | Path) -> bool:
    return QDesktopServices.openUrl(QUrl.fromLocalFile(str(path)))


def fmt_dt(iso: str | None, with_year: bool = False) -> str:
    """'2026-11-21 15:51:00' -> '21.11 15:51' (или с годом)."""
    if not iso:
        return "—"
    try:
        from utils.timeutil import parse_iso
        dt = parse_iso(iso)
    except ValueError:
        return iso
    return dt.strftime("%d.%m.%Y %H:%M" if with_year else "%d.%m %H:%M")


def safe_call(fn: Callable, *args, default=None):
    """Вызов, который не роняет интерфейс (ошибка пишется в журнал)."""
    try:
        return fn(*args)
    except Exception:
        log.exception("Ошибка в обработчике интерфейса")
        return default


def disconnect_quiet(signal, slot) -> None:
    try:
        signal.disconnect(slot)
    except (RuntimeError, TypeError):
        pass


def is_alive(obj: QObject | None) -> bool:
    if obj is None:
        return False
    try:
        from shiboken6 import isValid
        return bool(isValid(obj))
    except Exception:
        return True


def fade_in(widget: QWidget, ms: int = 240) -> None:
    """Плавное появление виджета (реализация — ui.anim.fade_in)."""
    from ui import anim
    anim.fade_in(widget, ms)
