"""Таблицы: единый стиль и вспомогательные функции."""
from __future__ import annotations

from typing import Sequence

from PySide6.QtCore import Qt
from PySide6.QtGui import QColor
from PySide6.QtWidgets import QAbstractItemView, QHeaderView, QTableWidget, QTableWidgetItem

from ui import theme

ALIGN_R = Qt.AlignmentFlag.AlignRight | Qt.AlignmentFlag.AlignVCenter
ALIGN_C = Qt.AlignmentFlag.AlignCenter
ALIGN_L = Qt.AlignmentFlag.AlignLeft | Qt.AlignmentFlag.AlignVCenter


def make_table(headers: Sequence[str], stretch_col: int | None = 0, row_h: int = 38) -> QTableWidget:
    t = QTableWidget(0, len(headers))
    t.setHorizontalHeaderLabels(list(headers))
    t.verticalHeader().setVisible(False)
    t.verticalHeader().setDefaultSectionSize(row_h)
    t.setEditTriggers(QAbstractItemView.EditTrigger.NoEditTriggers)
    t.setSelectionBehavior(QAbstractItemView.SelectionBehavior.SelectRows)
    t.setSelectionMode(QAbstractItemView.SelectionMode.SingleSelection)
    t.setShowGrid(False)
    t.setAlternatingRowColors(True)
    t.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)
    t.setVerticalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)
    hh = t.horizontalHeader()
    hh.setHighlightSections(False)
    hh.setDefaultAlignment(Qt.AlignmentFlag.AlignLeft | Qt.AlignmentFlag.AlignVCenter)
    for i in range(len(headers)):
        hh.setSectionResizeMode(i, QHeaderView.ResizeMode.Stretch if i == stretch_col
                                else QHeaderView.ResizeMode.ResizeToContents)
    return t


def cell(text, *, align: Qt.AlignmentFlag | None = None, tone: str | None = None, data=None) -> QTableWidgetItem:
    it = QTableWidgetItem("" if text is None else str(text))
    it.setTextAlignment(int(align if align is not None else ALIGN_L))
    if tone:
        it.setForeground(QColor(theme.get().colors.get(tone, tone)))
    if data is not None:
        it.setData(Qt.ItemDataRole.UserRole, data)
    return it


def fit_height(t: QTableWidget, max_rows: int | None = None, min_rows: int = 1) -> None:
    """Высота таблицы по числу строк — прокручивается вся страница, а не таблица внутри неё."""
    n = t.rowCount()
    if max_rows is not None:
        n = min(n, max_rows)
    n = max(n, min_rows)
    hh = t.horizontalHeader()
    head = max(hh.height(), hh.sizeHint().height(), 30)
    t.setFixedHeight(head + n * t.verticalHeader().defaultSectionSize() + 6)
