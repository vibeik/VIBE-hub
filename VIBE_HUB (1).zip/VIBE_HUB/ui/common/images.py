"""Асинхронная загрузка картинок (аватары, обложки) без блокировки интерфейса."""
from __future__ import annotations

import logging
from pathlib import Path

from PySide6.QtCore import QRectF, Qt
from PySide6.QtGui import QColor, QPainter, QPainterPath, QPixmap
from PySide6.QtWidgets import QLabel, QWidget

from config.settings import cache_dir
from modules import workers
from ui import icons, theme
from utils.images import cached_image

log = logging.getLogger("vibehub.images")


def rounded_pixmap(src: QPixmap, size: int, shape: str = "circle", radius: float = 10.0, dpr: float = 2.0) -> QPixmap:
    """Обрезает картинку по центру до квадрата и скругляет (circle | rounded | square)."""
    px = int(size * dpr)
    scaled = src.scaled(px, px, Qt.AspectRatioMode.KeepAspectRatioByExpanding, Qt.TransformationMode.SmoothTransformation)
    out = QPixmap(px, px)
    out.setDevicePixelRatio(dpr)
    out.fill(Qt.GlobalColor.transparent)
    p = QPainter(out)
    p.setRenderHint(QPainter.RenderHint.Antialiasing)
    p.setRenderHint(QPainter.RenderHint.SmoothPixmapTransform)
    path = QPainterPath()
    rect = QRectF(0, 0, size, size)
    if shape == "circle":
        path.addEllipse(rect)
    elif shape == "rounded":
        path.addRoundedRect(rect, radius, radius)
    else:
        path.addRect(rect)
    p.setClipPath(path)
    dx = (scaled.width() - px) / 2 / dpr
    dy = (scaled.height() - px) / 2 / dpr
    p.drawPixmap(QRectF(-dx, -dy, scaled.width() / dpr, scaled.height() / dpr), scaled, QRectF(scaled.rect()))
    p.end()
    return out


class AsyncImage(QLabel):
    """Квадратная картинка с плейсхолдером. set_url() — https-адрес (кэшируется на диск), set_path() — файл."""

    def __init__(self, size: int = 40, shape: str = "circle", placeholder: str = "user", radius: float = 10.0,
                 parent: QWidget | None = None):
        super().__init__(parent)
        self._size, self._shape, self._ph, self._radius = size, shape, placeholder, radius
        self._url: str | None = None
        self._path: str | None = None
        self._loaded = False
        self.setFixedSize(size, size)
        self._draw_placeholder()
        theme.get().changed.connect(self._on_theme)

    # ---- API
    def set_url(self, url: str | None) -> None:
        if url == self._url and (self._loaded or url is None):
            return
        self._url, self._path, self._loaded = url, None, False
        self._draw_placeholder()
        if not url:
            return
        token = url

        def work() -> Path | None:
            return cached_image(token, cache_dir("images"))

        def done(path: Path | None) -> None:
            if token != self._url or path is None:
                return
            self._apply(str(path))

        workers.run_async(work, done, lambda _e: None, owner=self)

    def set_path(self, path: str | None) -> None:
        if path == self._path and self._loaded:
            return
        self._url, self._path, self._loaded = None, path, False
        self._draw_placeholder()
        if path:
            self._apply(path)

    def clear_image(self) -> None:
        self._url = self._path = None
        self._loaded = False
        self._draw_placeholder()

    # ---- внутреннее
    def _apply(self, path: str) -> None:
        pm = QPixmap(path)
        if pm.isNull():
            return
        self.setPixmap(rounded_pixmap(pm, self._size, self._shape, self._radius))
        self._loaded = True

    def _draw_placeholder(self) -> None:
        c = theme.get().colors
        dpr = 2.0
        px = int(self._size * dpr)
        out = QPixmap(px, px)
        out.setDevicePixelRatio(dpr)
        out.fill(Qt.GlobalColor.transparent)
        p = QPainter(out)
        p.setRenderHint(QPainter.RenderHint.Antialiasing)
        path = QPainterPath()
        rect = QRectF(0, 0, self._size, self._size)
        if self._shape == "circle":
            path.addEllipse(rect)
        else:
            path.addRoundedRect(rect, self._radius, self._radius)
        p.fillPath(path, QColor(255, 255, 255, 14))
        ic = max(14, int(self._size * 0.5))
        pm = icons.pixmap(self._ph, c["muted"], ic)
        p.drawPixmap(int((self._size - ic) / 2), int((self._size - ic) / 2), pm)
        p.end()
        self.setPixmap(out)

    def _on_theme(self) -> None:
        if not self._loaded:
            self._draw_placeholder()
