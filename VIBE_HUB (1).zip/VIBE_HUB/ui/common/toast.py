"""Всплывающие уведомления (toast) в правом нижнем углу окна."""
from __future__ import annotations

from PySide6.QtCore import QTimer, Qt
from PySide6.QtWidgets import QFrame, QHBoxLayout, QLabel, QVBoxLayout, QWidget

from ui import icons, theme
from ui.common.base import IconButton, label
from ui import anim

_ICON = {"info": ("info", "accent2"), "success": ("check-circle", "success"),
         "warning": ("alert", "warning"), "error": ("alert", "danger")}


class Toast(QFrame):
    def __init__(self, kind: str, title: str, text: str, on_close):
        super().__init__()
        self.setObjectName("Toast")
        self.setProperty("kind", kind if kind in _ICON else "info")
        self.setFixedWidth(340)
        lay = QHBoxLayout(self)
        lay.setContentsMargins(14, 12, 10, 12)
        lay.setSpacing(12)
        name, role = _ICON.get(kind, _ICON["info"])
        ic = QLabel()
        ic.setPixmap(icons.pixmap(name, theme.get().colors[role], 22))
        ic.setFixedSize(22, 22)
        col = QVBoxLayout()
        col.setSpacing(2)
        col.addWidget(label(title, "H3", wrap=True))
        if text:
            col.addWidget(label(text, "Muted", wrap=True))
        close = IconButton("x", size=14, on_click=lambda: on_close(self))
        lay.addWidget(ic, 0, Qt.AlignmentFlag.AlignTop)
        lay.addLayout(col, 1)
        lay.addWidget(close, 0, Qt.AlignmentFlag.AlignTop)
        self.adjustSize()


class ToastHost(QWidget):
    """Прозрачный контейнер поверх окна; не перехватывает клики вне самих тостов."""
    MAX_VISIBLE = 4

    def __init__(self, parent: QWidget):
        super().__init__(parent)
        self.setAttribute(Qt.WidgetAttribute.WA_TransparentForMouseEvents, False)
        self._lay = QVBoxLayout(self)
        self._lay.setContentsMargins(0, 0, 0, 0)
        self._lay.setSpacing(10)
        self._toasts: list[Toast] = []
        self.hide()

    def show_toast(self, kind: str, title: str, text: str = "", timeout_ms: int = 5000) -> None:
        while len(self._toasts) >= self.MAX_VISIBLE:
            self._dismiss(self._toasts[0])
        t = Toast(kind, title, text, self._dismiss)
        self._toasts.append(t)
        self._lay.addWidget(t)
        anim.fade_in(t, 260)
        self.show()
        self.reposition()
        self.raise_()
        QTimer.singleShot(timeout_ms, lambda tt=t: self._dismiss(tt))

    def _dismiss(self, t: Toast) -> None:
        if t not in self._toasts:
            return
        self._toasts.remove(t)
        self._lay.removeWidget(t)
        t.setParent(None)
        t.deleteLater()
        if not self._toasts:
            self.hide()
        else:
            self.reposition()

    def reposition(self) -> None:
        p = self.parentWidget()
        if p is None:
            return
        self.adjustSize()
        w, h = self.sizeHint().width(), self.sizeHint().height()
        self.setGeometry(p.width() - w - 22, p.height() - h - 22, w, h)
