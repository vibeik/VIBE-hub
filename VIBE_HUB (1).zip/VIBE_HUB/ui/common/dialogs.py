"""Диалоги: подтверждение, сообщения, базовая форма."""
from __future__ import annotations

from PySide6.QtCore import Qt
from PySide6.QtWidgets import (QCheckBox, QDialog, QDialogButtonBox, QFormLayout, QLabel, QMessageBox, QVBoxLayout,
                               QWidget)

from ui.common.base import Banner
from utils.i18n import _


def confirm(parent: QWidget | None, title: str, text: str, *, ok: str = "Удалить", cancel: str = "Отмена",
            danger: bool = True) -> bool:
    box = QMessageBox(parent)
    box.setWindowTitle(title)
    box.setText(text)
    box.setIcon(QMessageBox.Icon.Warning if danger else QMessageBox.Icon.Question)
    ok_btn = box.addButton(_(ok), QMessageBox.ButtonRole.AcceptRole)
    cancel_btn = box.addButton(_(cancel), QMessageBox.ButtonRole.RejectRole)
    ok_btn.setProperty("kind", "danger" if danger else "primary")
    box.setDefaultButton(cancel_btn)
    box.exec()
    return box.clickedButton() is ok_btn


def confirm_with_option(parent: QWidget | None, title: str, text: str, option_text: str, *, ok: str = "Отключить",
                        option_default: bool = True) -> tuple[bool, bool]:
    """Подтверждение с флажком. Возвращает (подтверждено, флажок)."""
    box = QMessageBox(parent)
    box.setWindowTitle(title)
    box.setText(text)
    box.setIcon(QMessageBox.Icon.Warning)
    cb = QCheckBox(option_text)
    cb.setChecked(option_default)
    box.setCheckBox(cb)
    ok_btn = box.addButton(_(ok), QMessageBox.ButtonRole.AcceptRole)
    cancel_btn = box.addButton(_("Отмена"), QMessageBox.ButtonRole.RejectRole)
    ok_btn.setProperty("kind", "danger")
    box.setDefaultButton(cancel_btn)
    box.exec()
    return box.clickedButton() is ok_btn, cb.isChecked()


def message(parent: QWidget | None, title: str, text: str, kind: str = "info") -> None:
    box = QMessageBox(parent)
    box.setWindowTitle(title)
    box.setText(text)
    box.setIcon({"info": QMessageBox.Icon.Information, "warning": QMessageBox.Icon.Warning,
                 "error": QMessageBox.Icon.Critical}.get(kind, QMessageBox.Icon.Information))
    box.addButton("OK", QMessageBox.ButtonRole.AcceptRole)
    box.exec()


class FormDialog(QDialog):
    """Диалог с формой. Подклассы заполняют self.form и переопределяют validate()/apply().

    validate() -> str | None  (текст ошибки — диалог не закрывается),
    apply() — применяется при успешной проверке.
    """

    def __init__(self, parent: QWidget | None, title: str, *, ok_text: str = "Сохранить", width: int = 460,
                 intro: str = ""):
        super().__init__(parent)
        self.setWindowTitle(title)
        self.setModal(True)
        self.setMinimumWidth(width)
        self._lay = QVBoxLayout(self)
        self._lay.setContentsMargins(22, 20, 22, 18)
        self._lay.setSpacing(14)
        if intro:
            lb = QLabel(intro)
            lb.setObjectName("Muted")
            lb.setWordWrap(True)
            self._lay.addWidget(lb)
        self.form = QFormLayout()
        self.form.setLabelAlignment(Qt.AlignmentFlag.AlignLeft)
        self.form.setFieldGrowthPolicy(QFormLayout.FieldGrowthPolicy.ExpandingFieldsGrow)
        self.form.setHorizontalSpacing(16)
        self.form.setVerticalSpacing(10)
        self._lay.addLayout(self.form)
        self.error = Banner("", "error")
        self._lay.addWidget(self.error)
        self.buttons = QDialogButtonBox(QDialogButtonBox.StandardButton.Cancel | QDialogButtonBox.StandardButton.Ok)
        ok = self.buttons.button(QDialogButtonBox.StandardButton.Ok)
        ok.setText(_(ok_text))
        ok.setProperty("kind", "primary")
        self.buttons.button(QDialogButtonBox.StandardButton.Cancel).setText(_("Отмена"))
        self.buttons.accepted.connect(self._try_accept)
        self.buttons.rejected.connect(self.reject)
        self._lay.addWidget(self.buttons)

    def add_content(self, w: QWidget) -> None:
        """Добавить виджет между формой и кнопками."""
        self._lay.insertWidget(self._lay.indexOf(self.error), w)

    def validate(self) -> str | None:
        return None

    def apply(self) -> None:
        pass

    def _try_accept(self) -> None:
        err = self.validate()
        if err:
            self.error.set_text(err, "error")
            return
        try:
            self.apply()
        except Exception as exc:  # ошибки БД и т.п. показываем в диалоге
            self.error.set_text(str(exc) or _("Не удалось сохранить."), "error")
            return
        self.accept()
