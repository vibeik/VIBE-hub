"""Локальный музыкальный плеер: папки, библиотека, плейлисты, управление воспроизведением (Qt Multimedia)."""
from __future__ import annotations

import logging
import os
from pathlib import Path

from PySide6.QtCore import Qt
from PySide6.QtWidgets import (QFileDialog, QHBoxLayout, QInputDialog, QLineEdit, QListWidget, QListWidgetItem, QMenu,
                               QSlider, QStackedWidget, QVBoxLayout, QWidget)

from modules import music_scan, workers
from ui.common.base import Banner, Card, EmptyState, IconButton, Page, SegmentedControl, button, label
from ui.common.dialogs import confirm, message
from ui.common.images import AsyncImage
from ui.common.tables import ALIGN_R, cell, make_table
from ui.common.util import clear_layout, open_path
from utils.format import fmt_ms
from utils.i18n import _

log = logging.getLogger("vibehub.music.ui")
LIB_LIMIT = 2000


class MusicPage(Page):
    def __init__(self, ctx, parent=None):
        super().__init__(ctx, parent)
        self.player = ctx.player
        self.repo = ctx.repos.music
        self._tracks: list[dict] = []
        self._pl_tracks: list[dict] = []
        self._seeking = False
        self._scanning = False
        root = QVBoxLayout(self)
        root.setContentsMargins(28, 22, 28, 28)
        root.setSpacing(16)

        head, _col = self.page_header("Music", _("Локальные файлы: mp3, flac, wav, ogg, m4a и другие"))
        self.btn_add = button(_("Добавить папку"), icon="folder-plus", on_click=self.add_folder)
        self.btn_scan = button(_("Сканировать"), "primary", "refresh", self.scan_all)
        head.addWidget(self.btn_add)
        head.addWidget(self.btn_scan)
        root.addLayout(head)

        self.status = Banner("", "info")
        root.addWidget(self.status)
        self.player.error.connect(lambda msg: self.status.set_text(msg, "warning"))

        self.empty = EmptyState(_("Музыкальных папок пока нет"), _("Добавьте папку с музыкой — приложение найдёт треки и прочитает теги. "
                                                                     "Ничего не копируется и не загружается в интернет."),
                                icon="music", button_text=_("Добавить папку"), on_click=self.add_folder)
        root.addWidget(self.empty)

        self.content = QWidget()
        cl = QVBoxLayout(self.content)
        cl.setContentsMargins(0, 0, 0, 0)
        cl.setSpacing(16)
        root.addWidget(self.content)

        # ---- плеер
        pc = Card(_("Плеер"), "headphones")
        row = QHBoxLayout()
        row.setSpacing(16)
        self.cover = AsyncImage(84, "rounded", "music", radius=12)
        col = QVBoxLayout()
        col.setSpacing(2)
        self.now_title = label(_("Ничего не играет"), "H2")
        self.now_artist = label("", "Muted")
        seek = QHBoxLayout()
        self.pos_lbl, self.dur_lbl = label("0:00", "Muted"), label("0:00", "Muted")
        self.slider = QSlider(Qt.Orientation.Horizontal)
        self.slider.setRange(0, 0)
        self.slider.sliderPressed.connect(lambda: setattr(self, "_seeking", True))
        self.slider.sliderReleased.connect(self._seek_release)
        seek.addWidget(self.pos_lbl)
        seek.addWidget(self.slider, 1)
        seek.addWidget(self.dur_lbl)
        ctl = QHBoxLayout()
        ctl.setSpacing(4)
        self.b_shuffle = IconButton("shuffle", _("Перемешать"), size=20, checkable=True, on_click=self._toggle_shuffle)
        self.b_prev = IconButton("prev", _("Предыдущий"), size=22, role="text", on_click=self.player.previous)
        self.b_play = IconButton("play", _("Играть / пауза"), size=28, role="text", on_click=self.player.toggle)
        self.b_next = IconButton("next", _("Следующий"), size=22, role="text", on_click=lambda: self.player.next())
        self.b_repeat = IconButton("repeat", _("Повтор: выкл"), size=20, checkable=True, on_click=self._cycle_repeat)
        self.vol_icon = IconButton("volume", _("Громкость"), size=18)
        self.vol = QSlider(Qt.Orientation.Horizontal)
        self.vol.setRange(0, 100)
        self.vol.setFixedWidth(120)
        self.vol.setValue(self.player.volume)
        self.vol.valueChanged.connect(self._on_volume)
        ctl.addStretch(1)
        for b in (self.b_shuffle, self.b_prev, self.b_play, self.b_next, self.b_repeat):
            ctl.addWidget(b)
        ctl.addStretch(1)
        ctl.addWidget(self.vol_icon)
        ctl.addWidget(self.vol)
        col.addWidget(self.now_title)
        col.addWidget(self.now_artist)
        col.addLayout(seek)
        col.addLayout(ctl)
        row.addWidget(self.cover, 0, Qt.AlignmentFlag.AlignTop)
        row.addLayout(col, 1)
        pc.body.addLayout(row)
        cl.addWidget(pc)

        # ---- вкладки
        self.tabs = SegmentedControl([("lib", _("Библиотека")), ("pl", _("Плейлисты")), ("folders", _("Папки"))], "lib")
        self.tabs.changed.connect(self._on_tab)
        cl.addWidget(self.tabs, 0, Qt.AlignmentFlag.AlignLeft)
        self.stack = QStackedWidget()
        cl.addWidget(self.stack)

        # библиотека
        lib = Card()
        self.search = QLineEdit()
        self.search.setPlaceholderText(_("Поиск по названию, исполнителю, альбому"))
        self.search.setClearButtonEnabled(True)
        self.search.textChanged.connect(lambda _t: self._fill_library())
        lib.body.addWidget(self.search)
        self.lib_table = make_table([_("Название"), _("Исполнитель"), _("Альбом"), _("Время")], stretch_col=0)
        self.lib_table.setVerticalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAsNeeded)
        self.lib_table.setFixedHeight(380)
        self.lib_table.cellDoubleClicked.connect(self._play_from_library)
        self.lib_table.setContextMenuPolicy(Qt.ContextMenuPolicy.CustomContextMenu)
        self.lib_table.customContextMenuRequested.connect(self._lib_menu)
        lib.body.addWidget(self.lib_table)
        self.lib_note = label("", "Muted")
        lib.body.addWidget(self.lib_note)
        self.stack.addWidget(lib)

        # плейлисты
        plc = Card()
        pl_row = QHBoxLayout()
        pl_row.setSpacing(16)
        left = QVBoxLayout()
        self.pl_list = QListWidget()
        self.pl_list.setFixedWidth(230)
        self.pl_list.setMinimumHeight(300)
        self.pl_list.currentRowChanged.connect(lambda _r: self._fill_playlist())
        pl_btns = QHBoxLayout()
        pl_btns.addWidget(IconButton("plus", _("Новый плейлист"), on_click=self.new_playlist))
        pl_btns.addWidget(IconButton("edit", _("Переименовать"), on_click=self.rename_playlist))
        pl_btns.addWidget(IconButton("trash", _("Удалить плейлист"), on_click=self.delete_playlist))
        pl_btns.addStretch(1)
        left.addWidget(self.pl_list, 1)
        left.addLayout(pl_btns)
        right = QVBoxLayout()
        self.pl_title = label("", "H3")
        self.pl_table = make_table([_("Название"), _("Исполнитель"), _("Время")], stretch_col=0)
        self.pl_table.setVerticalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAsNeeded)
        self.pl_table.setMinimumHeight(300)
        self.pl_table.cellDoubleClicked.connect(self._play_from_playlist)
        self.pl_table.setContextMenuPolicy(Qt.ContextMenuPolicy.CustomContextMenu)
        self.pl_table.customContextMenuRequested.connect(self._pl_menu)
        self.pl_hint = label("", "Muted", wrap=True)
        right.addWidget(self.pl_title)
        right.addWidget(self.pl_table, 1)
        right.addWidget(self.pl_hint)
        pl_row.addLayout(left)
        pl_row.addLayout(right, 1)
        plc.body.addLayout(pl_row)
        self.stack.addWidget(plc)

        # папки
        fc = Card()
        self.folders_lay = QVBoxLayout()
        self.folders_lay.setSpacing(8)
        fc.body.addLayout(self.folders_lay)
        self.stack.addWidget(fc)
        root.addStretch(1)

        p = self.player
        p.track_changed.connect(self._on_track)
        p.playing_changed.connect(self._on_playing)
        p.position_changed.connect(self._on_pos)
        self.b_shuffle.setChecked(p.queue.shuffle)
        self._sync_repeat()

    # ------------------------------------------------------------------ плеер
    def _on_tab(self, key: str) -> None:
        self.stack.setCurrentIndex({"lib": 0, "pl": 1, "folders": 2}[key])

    def _on_track(self, tr) -> None:
        if not tr:
            self.now_title.setText(_("Ничего не играет"))
            self.now_artist.setText("")
            self.cover.clear_image()
            return
        self.now_title.setText(tr["title"])
        self.now_artist.setText(" · ".join(x for x in (tr["artist"], tr["album"]) if x))
        self.cover.set_path(tr.get("cover"))
        self.status.set_text("")

    def _on_playing(self, playing: bool) -> None:
        self.b_play.set_icon_name("pause" if playing else "play")

    def _on_pos(self, pos: int, dur: int) -> None:
        self.dur_lbl.setText(fmt_ms(dur))
        if self._seeking:
            return
        self.slider.setRange(0, max(0, dur))
        self.slider.setValue(min(pos, max(0, dur)))
        self.pos_lbl.setText(fmt_ms(pos))

    def _seek_release(self) -> None:
        self._seeking = False
        self.player.seek(self.slider.value())

    def _on_volume(self, v: int) -> None:
        self.player.set_volume(v)
        self.vol_icon.set_icon_name("volume-off" if v == 0 else "volume")

    def _toggle_shuffle(self) -> None:
        self.player.set_shuffle(self.b_shuffle.isChecked())

    def _cycle_repeat(self) -> None:
        order = ("off", "all", "one")
        nxt = order[(order.index(self.player.queue.repeat) + 1) % 3]
        self.player.set_repeat(nxt)
        self._sync_repeat()

    def _sync_repeat(self) -> None:
        mode = self.player.queue.repeat
        self.b_repeat.set_icon_name("repeat-one" if mode == "one" else "repeat")
        self.b_repeat.setChecked(mode != "off")
        self.b_repeat.setToolTip({"off": _("Повтор: выкл"), "all": _("Повтор: все треки"), "one": _("Повтор: один трек")}[mode])

    # ------------------------------------------------------------------ данные
    def refresh(self) -> None:
        folders = self.repo.folders()
        self.empty.setVisible(not folders)
        self.content.setVisible(bool(folders))
        self.btn_scan.setVisible(bool(folders))
        self._fill_folders(folders)
        if not folders:
            return
        self._fill_library()
        self._fill_playlist_list()

    def _fill_library(self) -> None:
        self._tracks = self.repo.tracks(self.search.text())
        shown = self._tracks[:LIB_LIMIT]
        t = self.lib_table
        t.setRowCount(len(shown))
        for r, tr in enumerate(shown):
            t.setItem(r, 0, cell(tr["title"], data=tr["id"]))
            t.setItem(r, 1, cell(tr["artist"] or "—"))
            t.setItem(r, 2, cell(tr["album"] or "—"))
            t.setItem(r, 3, cell(fmt_ms(tr["duration_ms"]) if tr["duration_ms"] else "—", align=ALIGN_R))
        total = self.repo.count_tracks()
        if not total:
            self.lib_note.setText(_("В выбранных папках треков не найдено. Нажмите «Сканировать» после добавления файлов."))
        elif len(self._tracks) > LIB_LIMIT:
            self.lib_note.setText(f"{_('Показаны первые')} {LIB_LIMIT} {_('из')} {len(self._tracks)}. {_('Уточните поиск.')}")
        else:
            self.lib_note.setText(f"{_('Треков')}: {len(self._tracks)}")

    def _selected_id(self, table, rows: list[dict]) -> int | None:
        r = table.currentRow()
        return rows[r]["id"] if 0 <= r < len(rows) else None

    def _play_from_library(self, row: int, _c: int) -> None:
        shown = self._tracks[:LIB_LIMIT]
        if 0 <= row < len(shown):
            self.player.play_tracks([t["id"] for t in shown], shown[row]["id"])

    def _lib_menu(self, pos) -> None:
        tid = self._selected_id(self.lib_table, self._tracks[:LIB_LIMIT])
        if tid is None:
            return
        menu = QMenu(self)
        menu.addAction(_("Играть"), lambda: self._play_from_library(self.lib_table.currentRow(), 0))
        sub = menu.addMenu(_("Добавить в плейлист"))
        for pl in self.repo.playlists():
            sub.addAction(pl["name"], lambda pid=pl["id"]: self._add_to_playlist(pid, tid))
        sub.addSeparator()
        sub.addAction(_("Новый плейлист…"), lambda: self._add_to_new_playlist(tid))
        tr = self.repo.get_track(tid)
        if tr:
            menu.addAction(_("Показать в папке"), lambda: open_path(Path(tr["path"]).parent))
        menu.exec(self.lib_table.viewport().mapToGlobal(pos))

    # ------------------------------------------------------------------ плейлисты
    def _fill_playlist_list(self) -> None:
        cur = self._current_pl_id()
        self.pl_list.blockSignals(True)
        self.pl_list.clear()
        for pl in self.repo.playlists():
            it = QListWidgetItem(f"{pl['name']}  ({pl['count']})")
            it.setData(Qt.ItemDataRole.UserRole, pl["id"])
            self.pl_list.addItem(it)
            if pl["id"] == cur:
                self.pl_list.setCurrentItem(it)
        self.pl_list.blockSignals(False)
        if self.pl_list.currentRow() < 0 and self.pl_list.count():
            self.pl_list.setCurrentRow(0)
        self._fill_playlist()

    def _current_pl_id(self) -> int | None:
        it = self.pl_list.currentItem()
        return int(it.data(Qt.ItemDataRole.UserRole)) if it else None

    def _fill_playlist(self) -> None:
        pid = self._current_pl_id()
        if pid is None:
            self._pl_tracks = []
            self.pl_table.setRowCount(0)
            self.pl_title.setText("")
            self.pl_hint.setText(_("Создайте плейлист кнопкой «+», затем добавляйте треки через правый клик в библиотеке."))
            return
        self._pl_tracks = self.repo.playlist_tracks(pid)
        t = self.pl_table
        t.setRowCount(len(self._pl_tracks))
        for r, tr in enumerate(self._pl_tracks):
            t.setItem(r, 0, cell(tr["title"]))
            t.setItem(r, 1, cell(tr["artist"] or "—"))
            t.setItem(r, 2, cell(fmt_ms(tr["duration_ms"]) if tr["duration_ms"] else "—", align=ALIGN_R))
        it = self.pl_list.currentItem()
        self.pl_title.setText(it.text() if it else "")
        self.pl_hint.setText("" if self._pl_tracks else _("Плейлист пуст. Добавьте треки через правый клик в библиотеке."))

    def _play_from_playlist(self, row: int, _c: int) -> None:
        if 0 <= row < len(self._pl_tracks):
            self.player.play_tracks([t["id"] for t in self._pl_tracks], self._pl_tracks[row]["id"])

    def _pl_menu(self, pos) -> None:
        r = self.pl_table.currentRow()
        pid = self._current_pl_id()
        if pid is None or not 0 <= r < len(self._pl_tracks):
            return
        tid = self._pl_tracks[r]["id"]
        menu = QMenu(self)
        menu.addAction(_("Играть"), lambda: self._play_from_playlist(r, 0))
        menu.addAction(_("Убрать из плейлиста"), lambda: self._remove_from_playlist(pid, tid))
        menu.exec(self.pl_table.viewport().mapToGlobal(pos))

    def _remove_from_playlist(self, pid: int, tid: int) -> None:
        self.repo.remove_from_playlist(pid, tid)
        self._fill_playlist_list()

    def new_playlist(self) -> int | None:
        name, ok = QInputDialog.getText(self, _("Новый плейлист"), _("Название"))
        if not ok or not name.strip():
            return None
        try:
            pid = self.repo.create_playlist(name)
        except Exception as exc:
            message(self, _("Плейлист"), _("Не удалось создать плейлист (возможно, такое имя уже есть).") + f"\n{exc}", "warning")
            return None
        self._fill_playlist_list()
        return pid

    def rename_playlist(self) -> None:
        pid = self._current_pl_id()
        if pid is None:
            return
        old = self.pl_list.currentItem().text().rsplit("  (", 1)[0]
        name, ok = QInputDialog.getText(self, _("Переименовать"), _("Название"), text=old)
        if ok and name.strip():
            try:
                self.repo.rename_playlist(pid, name)
            except Exception:
                message(self, _("Плейлист"), _("Такое имя уже используется."), "warning")
            self._fill_playlist_list()

    def delete_playlist(self) -> None:
        pid = self._current_pl_id()
        if pid is not None and confirm(self, _("Удалить плейлист"), _("Плейлист будет удалён. Файлы на диске не затрагиваются.")):
            self.repo.delete_playlist(pid)
            self._fill_playlist_list()

    def _add_to_playlist(self, pid: int, tid: int) -> None:
        self.repo.add_to_playlist(pid, [tid])
        self._fill_playlist_list()

    def _add_to_new_playlist(self, tid: int) -> None:
        pid = self.new_playlist()
        if pid is not None:
            self._add_to_playlist(pid, tid)

    # ------------------------------------------------------------------ папки
    def _fill_folders(self, folders: list[str]) -> None:
        clear_layout(self.folders_lay)
        if not folders:
            return
        for f in folders:
            row = QHBoxLayout()
            ok = os.path.isdir(f)
            row.addWidget(label(f, tone=None if ok else "danger"), 1)
            if not ok:
                row.addWidget(label(_("папка недоступна"), "Muted"))
            row.addWidget(IconButton("external", _("Открыть папку"), on_click=lambda p=f: open_path(p)))
            row.addWidget(IconButton("trash", _("Убрать папку из библиотеки"), on_click=lambda p=f: self.remove_folder(p)))
            w = QWidget()
            w.setLayout(row)
            self.folders_lay.addWidget(w)

    def add_folder(self) -> None:
        path = QFileDialog.getExistingDirectory(self, _("Выберите папку с музыкой"))
        if not path:
            return
        self.repo.add_folder(os.path.normpath(path))
        self.ctx.log_activity("music", f"{_('Добавлена папка с музыкой')}: {os.path.basename(path) or path}")
        self.mark_dirty()
        self.scan_all()

    def remove_folder(self, path: str) -> None:
        if confirm(self, _("Убрать папку"), _("Треки этой папки исчезнут из библиотеки (файлы на диске останутся)."), ok=_("Убрать")):
            self.repo.remove_folder(path)
            self.mark_dirty()

    def scan_all(self) -> None:
        if self._scanning:
            return
        folders = [f for f in self.repo.folders() if os.path.isdir(f)]
        if not folders:
            message(self, _("Сканирование"), _("Нет доступных папок для сканирования."), "warning")
            return
        self._scanning = True
        self.btn_scan.setEnabled(False)
        self.btn_add.setEnabled(False)
        self.status.set_text(_("Сканирование библиотеки…"), "info")
        repo, cover_dir = self.repo, self.ctx.cover_cache()

        def work() -> dict:
            total = {"added": 0, "updated": 0, "removed": 0, "total": 0}
            for f in folders:
                res = music_scan.scan_folder(
                    repo, f, cover_dir,
                    progress=lambda n: workers.post(lambda: self.status.set_text(f"{_('Сканирование')}… {n}", "info")))
                for k in total:
                    total[k] += res[k]
            return total

        def done(res: dict) -> None:
            self._scanning = False
            self.btn_scan.setEnabled(True)
            self.btn_add.setEnabled(True)
            self.status.set_text(f"{_('Готово')}: {_('найдено')} {res['total']}, {_('новых')} {res['added']}, "
                                 f"{_('обновлено')} {res['updated']}, {_('удалено')} {res['removed']}", "info")
            self.mark_dirty()

        def fail(exc: BaseException) -> None:
            self._scanning = False
            self.btn_scan.setEnabled(True)
            self.btn_add.setEnabled(True)
            self.status.set_text(workers.describe_error(exc), "warning")

        workers.run_async(work, done, fail, owner=self)
