"""Раскладка Dashboard: чистая логика сетки (без Qt) — перемещение, изменение размера, вытеснение, «гравитация».

Сетка из COLS колонок; у каждого виджета целые координаты (x, y) и размер (w, h) в ячейках.
Невидимые виджеты места не занимают. Инварианты после любой операции:
  * виджеты не пересекаются;
  * 0 <= x, x + w <= COLS, y >= 0;
  * min_w <= w, min_h <= h;
  * виджеты прижаты вверх (нет пустот над ними).
"""
from __future__ import annotations

import copy
from dataclasses import dataclass, field
from typing import Any, Iterable

COLS = 12
VERSION = 1


@dataclass
class Item:
    id: str
    x: int
    y: int
    w: int
    h: int
    visible: bool = True
    min_w: int = 2
    min_h: int = 2

    def right(self) -> int:
        return self.x + self.w

    def bottom(self) -> int:
        return self.y + self.h


def collides(a: Item, b: Item) -> bool:
    return a.x < b.right() and b.x < a.right() and a.y < b.bottom() and b.y < a.bottom()


def _int(v: Any, default: int) -> int:
    try:
        if isinstance(v, bool):
            return default
        return int(v)
    except (TypeError, ValueError, OverflowError):
        return default


@dataclass
class Layout:
    items: dict[str, Item] = field(default_factory=dict)
    cols: int = COLS

    # ------------------------------------------------------------------ служебное
    def copy(self) -> "Layout":
        return copy.deepcopy(self)

    def visible_items(self) -> list[Item]:
        return sorted((i for i in self.items.values() if i.visible), key=lambda i: (i.y, i.x, i.id))

    def rows(self) -> int:
        return max((i.bottom() for i in self.items.values() if i.visible), default=0)

    def _clamp(self, it: Item) -> None:
        it.w = max(it.min_w, min(it.w, self.cols))
        it.h = max(it.min_h, it.h)
        it.x = max(0, min(it.x, self.cols - it.w))
        it.y = max(0, it.y)

    def _push_down(self, anchor: Item) -> None:
        """Сдвигает вниз всё, что пересекается с anchor (и каскадом — то, что пересекается со сдвинутым)."""
        stack = [anchor]
        guard = 0
        while stack:
            cur = stack.pop()
            for other in self.visible_items():
                if other is anchor or other is cur:
                    continue
                if collides(cur, other):
                    other.y = cur.bottom()
                    stack.append(other)
                    guard += 1
                    if guard > 10_000:       # страховка от зацикливания при некорректных данных
                        return

    def compact(self) -> None:
        """Прижимает все видимые виджеты вверх, не допуская пересечений."""
        placed: list[Item] = []
        for it in self.visible_items():
            while it.y > 0:
                it.y -= 1
                if any(collides(it, p) for p in placed):
                    it.y += 1
                    break
            # если после сдвига всё ещё пересекается (исходные данные были «грязные») — опускаем ниже
            while any(collides(it, p) for p in placed):
                it.y += 1
            placed.append(it)

    # ------------------------------------------------------------------ операции
    def move(self, item_id: str, x: int, y: int) -> None:
        it = self.items.get(item_id)
        if it is None or not it.visible:
            return
        it.x, it.y = x, y
        self._clamp(it)
        self._push_down(it)
        self.compact()

    def resize(self, item_id: str, w: int, h: int) -> None:
        it = self.items.get(item_id)
        if it is None or not it.visible:
            return
        it.w, it.h = w, h
        self._clamp(it)
        self._push_down(it)
        self.compact()

    def set_visible(self, item_id: str, visible: bool) -> None:
        it = self.items.get(item_id)
        if it is None or it.visible == visible:
            return
        it.visible = visible
        if visible:
            it.y = self.rows()          # новый виджет — в самый низ
            it.x = 0
            self._clamp(it)
        self.compact()

    # ------------------------------------------------------------------ сериализация
    def to_json(self) -> dict:
        return {"version": VERSION,
                "items": [{"id": i.id, "x": i.x, "y": i.y, "w": i.w, "h": i.h, "visible": i.visible}
                          for i in sorted(self.items.values(), key=lambda i: (not i.visible, i.y, i.x, i.id))]}

    @classmethod
    def from_defaults(cls, defaults: Iterable[Item]) -> "Layout":
        lay = cls({i.id: copy.copy(i) for i in defaults})
        for it in lay.items.values():
            lay._clamp(it)
        lay._resolve_all()
        return lay

    @classmethod
    def from_saved(cls, saved: Any, defaults: Iterable[Item]) -> "Layout":
        """Восстанавливает раскладку из настроек. Мусор и неизвестные id игнорируются;
        новые виджеты (появились в обновлении) добавляются в конец; пересечения устраняются."""
        defaults = list(defaults)
        lay = cls.from_defaults(defaults)
        if not isinstance(saved, dict) or not isinstance(saved.get("items"), list):
            return lay
        by_id = {i.id: i for i in defaults}
        seen: set[str] = set()
        restored: dict[str, Item] = {}
        for raw in saved["items"]:
            if not isinstance(raw, dict):
                continue
            wid = raw.get("id")
            base = by_id.get(wid) if isinstance(wid, str) else None
            if base is None or wid in seen:
                continue
            seen.add(wid)
            it = Item(id=base.id, x=_int(raw.get("x"), base.x), y=_int(raw.get("y"), base.y),
                      w=_int(raw.get("w"), base.w), h=_int(raw.get("h"), base.h),
                      visible=bool(raw.get("visible", True)), min_w=base.min_w, min_h=base.min_h)
            lay._clamp(it)
            restored[wid] = it
        missing = [copy.copy(d) for d in defaults if d.id not in restored]
        out = cls(restored)
        out._resolve_all()
        for d in missing:                       # новые виджеты — в конец
            d.y = out.rows()
            d.x = 0
            out._clamp(d)
            out.items[d.id] = d
        out._resolve_all()
        return out

    def _resolve_all(self) -> None:
        # порядок (y, x): ранние элементы остаются на месте, пересекающиеся с ними уезжают вниз
        self.compact()


def default_layout(defaults: Iterable[Item]) -> Layout:
    return Layout.from_defaults(defaults)
