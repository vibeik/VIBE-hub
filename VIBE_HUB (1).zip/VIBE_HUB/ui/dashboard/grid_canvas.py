"""Холст Dashboard: размещает карточки по сетке и в режиме «Настроить» позволяет их двигать,
менять размер и скрывать. Логика позиций — в layout_engine (без Qt); здесь только ввод мыши и геометрия."""
from __future__ import annotations

import logging

from PySide6.QtCore import QPoint, QRect, QRectF, Qt, Signal
from PySide6.QtGui import QColor, QMouseEvent, QPainter, QPen
from PySide6.QtWidgets import QLayout, QWidget

from ui import anim, icons, theme
from ui.dashboard.layout_engine import COLS, Layout

log = logging.getLogger("vibehub.dashboard")

ROW_H = 64
GAP = 14
GRIP = 22


class _Overlay(QWidget):
    """Слой поверх карточки в режиме редактирования: перетаскивание, resize-ручка, кнопка «скрыть»."""

    def __init__(self, tile: "_Tile"):
        super().__init__(tile)
        self.tile = tile
        self.setCursor(Qt.CursorShape.SizeAllCursor)
        self.setMouseTracking(True)
        self._mode: str | None = None
        self._start = QPoint()

    # геометрия «кнопок»
    def _grip_rect(self) -> QRect:
        return QRect(self.width() - GRIP - 4, self.height() - GRIP - 4, GRIP, GRIP)

    def _close_rect(self) -> QRect:
        return QRect(self.width() - GRIP - 6, 6, GRIP, GRIP)

    def paintEvent(self, _e) -> None:
        p = QPainter(self)
        p.setRenderHint(QPainter.RenderHint.Antialiasing)
        c = theme.get().colors
        accent = QColor(c["accent"])
        fill = QColor(accent)
        fill.setAlpha(34)
        p.setBrush(fill)
        pen = QPen(accent, 1.5, Qt.PenStyle.DashLine)
        p.setPen(pen)
        p.drawRoundedRect(QRectF(self.rect()).adjusted(1, 1, -1, -1), 22, 22)       # как у карточек (QFrame#Card)
        g = self._grip_rect()
        p.drawPixmap(g.topLeft(), icons.pixmap("grip", c["text"], GRIP))
        x = self._close_rect()
        p.setPen(Qt.PenStyle.NoPen)
        p.setBrush(QColor(0, 0, 0, 120))
        p.drawEllipse(x.adjusted(-2, -2, 2, 2))
        p.drawPixmap(x.topLeft() + QPoint(3, 3), icons.pixmap("eye-off", c["text"], GRIP - 6))
        p.end()

    def mouseMoveEvent(self, e: QMouseEvent) -> None:
        pos = e.position().toPoint()
        if self._mode is None:
            if self._grip_rect().contains(pos):
                self.setCursor(Qt.CursorShape.SizeFDiagCursor)
            elif self._close_rect().contains(pos):
                self.setCursor(Qt.CursorShape.PointingHandCursor)
            else:
                self.setCursor(Qt.CursorShape.SizeAllCursor)
            return
        d = e.globalPosition().toPoint() - self._start
        self.tile.canvas._drag_update(self.tile.item_id, self._mode, d.x(), d.y())

    def mousePressEvent(self, e: QMouseEvent) -> None:
        if e.button() != Qt.MouseButton.LeftButton:
            return
        pos = e.position().toPoint()
        if self._close_rect().contains(pos):
            self.tile.canvas.hide_tile(self.tile.item_id)
            return
        self._mode = "resize" if self._grip_rect().contains(pos) else "move"
        self._start = e.globalPosition().toPoint()
        self.tile.canvas._drag_begin(self.tile.item_id)
        self.tile.raise_()

    def mouseReleaseEvent(self, e: QMouseEvent) -> None:
        if self._mode is not None:
            self._mode = None
            self.tile.canvas._drag_end()


class _Tile(QWidget):
    """Обёртка карточки: сама карточка + оверлей редактирования."""

    def __init__(self, canvas: "GridCanvas", item_id: str, widget: QWidget):
        super().__init__(canvas)
        self.canvas = canvas
        self.item_id = item_id
        self.widget = widget
        widget.setParent(self)
        widget.setMinimumSize(0, 0)
        lay = widget.layout()
        if lay is not None:      # карточка не должна «распирать» ячейку сетки
            lay.setSizeConstraint(QLayout.SizeConstraint.SetNoConstraint)
        self.overlay = _Overlay(self)
        self.overlay.hide()

    def resizeEvent(self, _e) -> None:
        self.widget.setGeometry(0, 0, self.width(), self.height())
        self.overlay.setGeometry(0, 0, self.width(), self.height())

    def set_edit(self, on: bool) -> None:
        self.overlay.setVisible(on)
        if on:
            self.overlay.raise_()


class GridCanvas(QWidget):
    """Сигнал layout_changed(dict) — пользователь изменил раскладку (JSON для сохранения)."""
    layout_changed = Signal(object)

    def __init__(self, parent: QWidget | None = None):
        super().__init__(parent)
        self.layout_model = Layout()
        self._tiles: dict[str, _Tile] = {}
        self._edit = False
        self._snapshot: Layout | None = None
        self._drag_id: str | None = None

    # ------------------------------------------------------------------ наполнение
    def add_widget(self, item_id: str, widget: QWidget) -> None:
        self._tiles[item_id] = _Tile(self, item_id, widget)

    def set_layout_model(self, model: Layout) -> None:
        self.layout_model = model
        self._relayout(animate=True)

    def visible_tiles(self) -> list[QWidget]:
        """Видимые карточки в порядке «сверху вниз, слева направо» — для каскадного появления."""
        items = self.layout_model.items
        ids = [i for i in self._tiles if i in items and items[i].visible]
        ids.sort(key=lambda i: (items[i].y, items[i].x))
        return [self._tiles[i] for i in ids]

    def set_edit(self, on: bool) -> None:
        self._edit = on
        for t in self._tiles.values():
            t.set_edit(on)

    @property
    def editing(self) -> bool:
        return self._edit

    def hide_tile(self, item_id: str) -> None:
        self.layout_model.set_visible(item_id, False)
        self._relayout(animate=True)
        self.layout_changed.emit(self.layout_model.to_json())

    def set_widget_visible(self, item_id: str, visible: bool) -> None:
        self.layout_model.set_visible(item_id, visible)
        self._relayout(animate=True)
        self.layout_changed.emit(self.layout_model.to_json())

    # ------------------------------------------------------------------ геометрия
    def _cell_w(self) -> float:
        return max(20.0, (self.width() - GAP * (COLS - 1)) / COLS)

    def _rect_for(self, x: int, y: int, w: int, h: int) -> QRect:
        cw = self._cell_w()
        return QRect(int(x * (cw + GAP)), y * (ROW_H + GAP), int(w * cw + (w - 1) * GAP), h * ROW_H + (h - 1) * GAP)

    def _relayout(self, animate: bool = False, follow: str | None = None) -> None:
        """Расставляет карточки. animate=True — соседи плавно «уступают место»;
        `follow` — карточка под курсором: она двигается сразу, без анимации."""
        live = animate and self.isVisible()
        for wid, tile in self._tiles.items():
            it = self.layout_model.items.get(wid)
            if it is None or not it.visible:
                anim.stop_geometry(tile)
                tile.hide()
                continue
            rect = self._rect_for(it.x, it.y, it.w, it.h)
            appearing = live and not tile.isVisible()
            if live and not appearing and wid != follow:
                anim.animate_geometry(tile, rect)
            else:
                anim.stop_geometry(tile)
                tile.setGeometry(rect)
            tile.show()
            if appearing:
                anim.fade_in(tile, 260)
            if self._edit:
                tile.overlay.raise_()
        rows = self.layout_model.rows()
        self.setMinimumHeight(max(0, rows * (ROW_H + GAP) - GAP) + (ROW_H if self._edit else 0))

    def resizeEvent(self, e) -> None:
        super().resizeEvent(e)
        self._relayout()

    # ------------------------------------------------------------------ перетаскивание
    def _drag_begin(self, item_id: str) -> None:
        self._drag_id = item_id
        self._snapshot = self.layout_model.copy()

    def _drag_update(self, item_id: str, mode: str, dx: int, dy: int) -> None:
        if self._snapshot is None or self._drag_id != item_id:
            return
        base = self._snapshot.items.get(item_id)
        if base is None:
            return
        step_x = self._cell_w() + GAP
        step_y = ROW_H + GAP
        trial = self._snapshot.copy()
        if mode == "move":
            trial.move(item_id, base.x + round(dx / step_x), base.y + round(dy / step_y))
        else:
            trial.resize(item_id, base.w + round(dx / step_x), base.h + round(dy / step_y))
        self.layout_model = trial
        self._relayout(animate=True, follow=item_id)

    def _drag_end(self) -> None:
        if self._snapshot is not None:
            self._snapshot = None
            self._drag_id = None
            self.layout_changed.emit(self.layout_model.to_json())
