"""Карточки Dashboard. Каждая карточка — Card + метод refresh(); данные берутся из реальных источников,
при их отсутствии показывается Empty State (никаких выдуманных значений)."""
from __future__ import annotations

import logging
from datetime import date

from PySide6.QtCore import Qt
from PySide6.QtWidgets import (QGridLayout, QHBoxLayout, QProgressBar, QSizePolicy, QVBoxLayout, QWidget)

from modules import dashboard_data, goals as goals_logic
from ui import anim, theme
from ui.common.base import (Card, Chip, ClickableLabel, EmptyState, IconButton, SegmentedControl, StatTile, button,
                            label, set_tone)
from ui.common.charts import ChartWidget, RingGauge
from ui.common.flow import FlowLayout
from ui.common.images import AsyncImage
from ui.common.util import clear_layout, fmt_dt
from utils.format import fmt_bytes, fmt_minutes, fmt_ms, fmt_num, fmt_pct, fmt_signed
from utils.i18n import _
from utils.timeutil import human_ago

log = logging.getLogger("vibehub.dashboard")


class DashCard(Card):
    """Базовая карточка Dashboard."""

    def __init__(self, ctx, title: str, icon: str | None = None, **kw):
        super().__init__(title, icon, **kw)
        self.ctx = ctx

    def refresh(self) -> None:  # pragma: no cover
        pass

    def on_sensors(self, snap) -> None:
        pass

    def tick(self) -> None:
        """Раз в секунду, пока Dashboard на экране (например, прогресс трека)."""


def _go(ctx, page: str):
    return lambda: ctx.bus.navigate.emit(page)


# ============================================================ PC Status
class PCMetricCard(DashCard):
    SPECS = {
        "cpu": ("Загрузка CPU", "cpu", "%", 100.0, (75.0, 90.0)),
        "gpu": ("Загрузка GPU", "gpu", "%", 100.0, (75.0, 90.0)),
        "ram": ("Память RAM", "memory", "%", 100.0, (75.0, 90.0)),
        "cpu_temp": ("Температура CPU", "thermometer", "°C", 110.0, (75.0, 90.0)),
        "gpu_temp": ("Температура GPU", "thermometer", "°C", 110.0, (75.0, 88.0)),
        "disk": ("Диск", "hard-drive", "%", 100.0, (85.0, 95.0)),
    }

    def __init__(self, ctx, key: str, clickable: bool = True):
        title, icon, unit, maximum, thr = self.SPECS[key]
        super().__init__(ctx, _(title), icon, clickable=clickable, margins=(14, 14, 14, 12))
        self._nav_tip = _("Открыть PC Monitor") if clickable else ""
        self.key = key
        self.gauge = RingGauge(thickness=9, maximum=maximum, thresholds=thr, unit=unit)
        self.detail = label("", "Muted", wrap=True, align=Qt.AlignmentFlag.AlignCenter)
        self.body.addWidget(self.gauge, 1)
        self.body.addWidget(self.detail)
        if clickable:
            self.clicked.connect(_go(ctx, "pc_monitor"))
        self.setToolTip(self._nav_tip)

    def refresh(self) -> None:
        snap = self.ctx.monitor.latest
        if snap is None:
            self.gauge.set_value(None)
            self.detail.setText(_("Ожидание данных…"))
            return
        self.on_sensors(snap)

    def on_sensors(self, s) -> None:
        k = self.key
        val: float | None
        detail = ""
        if k == "cpu":
            val = s.cpu
            if s.cpu_freq_mhz:
                detail = f"{s.cpu_freq_mhz / 1000:.1f} {_('ГГц')}"
            if s.cpu_per_core:
                detail += (" · " if detail else "") + f"{len(s.cpu_per_core)} " + _("потоков")
        elif k == "gpu":
            val = s.gpu
            detail = s.gpu_name or ""
            if s.vram_used_mb is not None and s.vram_total_mb:
                detail = (detail + " · " if detail else "") + f"VRAM {s.vram_used_mb / 1024:.1f}/{s.vram_total_mb / 1024:.0f} {_('ГБ')}"
            if val is None:
                detail = _("Нет данных")
                self.setToolTip(s.gpu_note or _("Датчик GPU недоступен"))
        elif k == "ram":
            val = s.ram
            detail = f"{fmt_bytes(s.ram_used)} / {fmt_bytes(s.ram_total)}" if s.ram_total else ""
        elif k == "cpu_temp":
            val = s.cpu_temp
            if val is None:
                detail = _("Нет данных")
                self.setToolTip(s.cpu_temp_note or _("Windows не отдаёт температуру CPU без сторонних драйверов"))
        elif k == "gpu_temp":
            val = s.gpu_temp
            if val is None:
                detail = _("Нет данных")
                self.setToolTip(s.gpu_note or _("Датчик температуры GPU недоступен"))
        else:  # disk
            val = s.disk_percent
            if s.disks:
                d = s.disks[0]
                detail = f"{d['mount']} · {fmt_bytes(d['used'])} / {fmt_bytes(d['total'])}"
        self.gauge.set_value(val)
        self.detail.setText(detail)
        if val is not None:
            self.setToolTip(self._nav_tip)


# ============================================================ Gaming Statistics
class GamingStatsCard(DashCard):
    def __init__(self, ctx):
        super().__init__(ctx, _("Игровая статистика"), "crosshair")
        self.seg = SegmentedControl([("all", _("Все")), ("faceit", "FACEIT"), ("manual", _("Вручную"))],
                                    ctx.settings.get("dashboard_source") or "all")
        self.seg.changed.connect(lambda k: ctx.settings.set("dashboard_source", k))
        self.add_header_widget(self.seg)
        self.empty = EmptyState(_("Матчей пока нет"),
                                _("Добавьте матч вручную или подключите FACEIT — статистика появится здесь."),
                                icon="crosshair", button_text=_("Добавить матч"), compact=True,
                                on_click=lambda: ctx.bus.request_action.emit("add_match"))
        self.grid_host = QWidget()
        g = QGridLayout(self.grid_host)
        g.setContentsMargins(0, 0, 0, 0)
        g.setSpacing(10)
        self.t_matches = StatTile(_("Матчей"))
        self.t_wr = StatTile(_("Win Rate"))
        self.t_kd = StatTile("K/D")
        self.t_kills = StatTile(_("Убийств за матч"))
        for i, t in enumerate((self.t_matches, self.t_wr, self.t_kd, self.t_kills)):
            g.addWidget(t, 0, i)
        self.week = label("", "Muted")
        self.body.addWidget(self.empty)
        self.body.addWidget(self.grid_host)
        self.body.addWidget(self.week)
        self.body.addStretch(1)

    def refresh(self) -> None:
        src = self.ctx.settings.get("dashboard_source") or "all"
        self.seg.set_current(src)
        ov = dashboard_data.overview(self.ctx.repos, src)
        a, w = ov["all"], ov["week"]
        has = a["matches"] > 0
        self.empty.setVisible(not has)
        self.grid_host.setVisible(has)
        self.week.setVisible(has)
        if not has:
            return
        self.t_matches.set_value(str(a["matches"]), f"{a['wins']} {_('поб.')} / {a['losses']} {_('пор.')}")
        wr = a["win_rate"]
        self.t_wr.set_value(fmt_pct(wr, 1), tone=None if wr is None else ("success" if wr >= 50 else "danger"))
        kd = a["kd"]
        self.t_kd.set_value(fmt_num(kd, 2), tone=None if kd is None else ("success" if kd >= 1 else "danger"))
        self.t_kills.set_value(fmt_num(a["avg_kills"], 1))
        if w["matches"]:
            self.week.setText(f"{_('За 7 дней')}: {w['matches']} {_('матчей')} · WR {fmt_pct(w['win_rate'], 0)} · K/D {fmt_num(w['kd'], 2)}")
        else:
            self.week.setText(_("За последние 7 дней матчей нет"))


# ============================================================ FACEIT
class FaceitCard(DashCard):
    def __init__(self, ctx):
        super().__init__(ctx, "FACEIT", "trophy")
        self.empty = EmptyState(_("FACEIT не подключён"), _("Укажите никнейм и Data API key — и здесь появится ваш ELO."),
                                icon="trophy", button_text=_("Подключить"), compact=True, on_click=_go(ctx, "accounts"))
        self.content = QWidget()
        lay = QVBoxLayout(self.content)
        lay.setContentsMargins(0, 0, 0, 0)
        lay.setSpacing(8)
        top = QHBoxLayout()
        self.avatar = AsyncImage(44)
        col = QVBoxLayout()
        col.setSpacing(0)
        self.nick = label("", "H3")
        self.level = Chip("", "accent")
        col.addWidget(self.nick)
        col.addWidget(self.level)
        top.addWidget(self.avatar)
        top.addLayout(col, 1)
        self.elo = label("—", "Big")
        top.addWidget(self.elo)
        lay.addLayout(top)
        self.delta = label("", "Muted")
        lay.addWidget(self.delta)
        row = QHBoxLayout()
        self.t_wr = StatTile("Win Rate")
        self.t_kd = StatTile("K/D")
        row.addWidget(self.t_wr)
        row.addWidget(self.t_kd)
        lay.addLayout(row)
        self.recent = FlowLayout(hspacing=4, vspacing=4)
        self.recent_host = QWidget()
        self.recent_host.setLayout(self.recent)
        lay.addWidget(self.recent_host)
        self.updated = label("", "Muted")
        lay.addWidget(self.updated)
        lay.addStretch(1)
        self.body.addWidget(self.empty)
        self.body.addWidget(self.content)

    def refresh(self) -> None:
        o = self.ctx.faceit.overview()
        linked = bool(o.get("linked"))
        self.empty.setVisible(not linked)
        self.content.setVisible(linked)
        if not linked:
            return
        self.avatar.set_url(o.get("avatar"))
        self.nick.setText(o.get("nickname") or "")
        self.level.setText(f"Level {o['level']}" if o.get("level") else "Level —")
        self.elo.setText(str(o["elo"]) if o.get("elo") is not None else "—")
        ch = o.get("elo_change")
        if ch and ch.get("delta") is not None:
            self.delta.setText(f"{fmt_signed(ch['delta'])} ELO {_('с')} {fmt_dt(ch['since'])}")
            set_tone(self.delta, "success" if ch["delta"] > 0 else "danger" if ch["delta"] < 0 else None)
        else:
            self.delta.setText(_("Изменение ELO накапливается по мере обновлений"))
            set_tone(self.delta, None)
        self.t_wr.set_value(fmt_pct(o.get("win_rate"), 0) if o.get("win_rate") is not None else "—")
        self.t_kd.set_value(fmt_num(o.get("kd"), 2))
        clear_layout(self.recent)
        for r in (o.get("recent_results") or [])[:10]:
            win = str(r) == "1"
            self.recent.addWidget(Chip("W" if win else "L", "success" if win else "danger"))
        self.recent_host.setVisible(bool(o.get("recent_results")))
        if not o.get("has_key"):
            self.updated.setText(_("Нужен FACEIT API Key — без него данные не обновляются"))
        else:
            self.updated.setText(f"{_('Обновлено')}: {human_ago(o.get('updated_at'))}")


# ============================================================ Steam
class SteamCard(DashCard):
    def __init__(self, ctx):
        super().__init__(ctx, "Steam", "gamepad")
        self.empty = EmptyState(_("Steam не подключён"), _("Войдите через официальный Steam OpenID — пароль приложению не нужен."),
                                icon="gamepad", button_text=_("Подключить"), compact=True, on_click=_go(ctx, "accounts"))
        self.content = QWidget()
        lay = QVBoxLayout(self.content)
        lay.setContentsMargins(0, 0, 0, 0)
        lay.setSpacing(8)
        top = QHBoxLayout()
        self.avatar = AsyncImage(44)
        col = QVBoxLayout()
        col.setSpacing(0)
        self.name = label("", "H3")
        self.status = label("", "Muted", wrap=True)
        col.addWidget(self.name)
        col.addWidget(self.status)
        top.addWidget(self.avatar)
        top.addLayout(col, 1)
        lay.addLayout(top)
        row = QHBoxLayout()
        self.t_games = StatTile(_("Игр"))
        self.t_hours = StatTile(_("Часов"))
        row.addWidget(self.t_games)
        row.addWidget(self.t_hours)
        lay.addLayout(row)
        self.recent = label("", "Muted", wrap=True)
        lay.addWidget(self.recent)
        self.note = label("", "Muted", wrap=True)
        lay.addWidget(self.note)
        lay.addStretch(1)
        self.body.addWidget(self.empty)
        self.body.addWidget(self.content)

    def refresh(self) -> None:
        o = self.ctx.steam.overview()
        linked = bool(o.get("linked"))
        self.empty.setVisible(not linked)
        self.content.setVisible(linked)
        if not linked:
            return
        self.avatar.set_url(o.get("avatar"))
        self.name.setText(o.get("name") or "")
        lvl = f"Level {o['level']}" if o.get("level") is not None else ""
        playing = f"{_('Играет')}: {o['playing']}" if o.get("playing") else ""
        self.status.setText(" · ".join(x for x in (lvl, playing) if x))
        has_games = bool(o.get("games_count"))
        self.t_games.set_value(str(o["games_count"]) if has_games else "—")
        self.t_hours.set_value(fmt_minutes(o["total_minutes"]) if has_games else "—")
        rec = o.get("recent") or []
        if rec:
            self.recent.setText(_("За 2 недели") + ": " + ", ".join(f"{g['name']} ({fmt_minutes(g['playtime_2weeks'])})" for g in rec[:3]))
        else:
            self.recent.setText("")
        self.recent.setVisible(bool(rec))
        notes = o.get("notes") or []
        self.note.setText(notes[0] if notes else "")
        self.note.setVisible(bool(notes))


# ============================================================ Spotify
class SpotifyCard(DashCard):
    def __init__(self, ctx):
        super().__init__(ctx, "Spotify", "headphones")
        self.empty = EmptyState(_("Spotify не подключён"), _("Авторизация OAuth 2.0 (PKCE). Управление воспроизведением требует Spotify Premium."),
                                icon="headphones", button_text=_("Подключить"), compact=True, on_click=_go(ctx, "accounts"))
        self.content = QWidget()
        lay = QVBoxLayout(self.content)
        lay.setContentsMargins(0, 0, 0, 0)
        lay.setSpacing(8)
        top = QHBoxLayout()
        self.cover = AsyncImage(64, "rounded", "music", radius=10)
        col = QVBoxLayout()
        col.setSpacing(1)
        self.title = label("", "H3", wrap=True)
        self.artist = label("", "Muted", wrap=True)
        self.context = label("", "Muted", wrap=True)
        col.addWidget(self.title)
        col.addWidget(self.artist)
        col.addWidget(self.context)
        top.addWidget(self.cover, 0, Qt.AlignmentFlag.AlignTop)
        top.addLayout(col, 1)
        lay.addLayout(top)
        self.bar = QProgressBar()
        self.bar.setRange(0, 1000)
        self.bar.setTextVisible(False)
        lay.addWidget(self.bar)
        self.times = label("", "Muted")
        lay.addWidget(self.times)
        ctl = QHBoxLayout()
        ctl.addStretch(1)
        self.b_prev = IconButton("prev", _("Предыдущий"), size=20, role="text", on_click=lambda: ctx.spotify.control("previous"))
        self.b_play = IconButton("play", _("Пауза / продолжить"), size=22, role="text", on_click=ctx.spotify.toggle_play)
        self.b_next = IconButton("next", _("Следующий"), size=20, role="text", on_click=lambda: ctx.spotify.control("next"))
        for b in (self.b_prev, self.b_play, self.b_next):
            ctl.addWidget(b)
        ctl.addStretch(1)
        lay.addLayout(ctl)
        self.status = label("", "Muted", wrap=True)
        lay.addWidget(self.status)
        lay.addStretch(1)
        self.body.addWidget(self.empty)
        self.body.addWidget(self.content)
        ctx.spotify.state_changed.connect(self.refresh)

    def refresh(self) -> None:
        ctl = self.ctx.spotify
        connected = ctl.connected
        self.empty.setVisible(not connected)
        self.content.setVisible(connected)
        if not connected:
            return
        st = ctl.state
        has = bool(st and st.get("title"))
        for b in (self.b_prev, self.b_play, self.b_next):
            b.setEnabled(has)
        if not has:
            self.title.setText(_("Ничего не играет"))
            self.artist.setText("")
            self.context.setText("")
            self.cover.clear_image()
            self.bar.setValue(0)
            self.times.setText("")
            self.b_play.set_icon_name("play")
            self.status.setText(ctl.status_text or "")
            self.status.setVisible(bool(ctl.status_text))
            return
        assert st is not None
        self.title.setText(st["title"])
        self.artist.setText(st["artists"])
        self.context.setText(st.get("context_name") or st.get("album") or "")
        self.cover.set_url(st.get("cover_url"))
        self.b_play.set_icon_name("pause" if st["is_playing"] else "play")
        self.tick()
        txt = ctl.status_text if ctl.status in ("premium", "error") else ""
        self.status.setText(txt)
        self.status.setVisible(bool(txt))

    def tick(self) -> None:
        st = self.ctx.spotify.state
        if not st or not st.get("duration_ms"):
            return
        pos = self.ctx.spotify.progress_now()
        self.bar.setValue(int(pos / st["duration_ms"] * 1000))
        self.times.setText(f"{fmt_ms(pos)} / {fmt_ms(st['duration_ms'])}")


# ============================================================ Goals
class GoalsCard(DashCard):
    MAX = 4

    def __init__(self, ctx):
        super().__init__(ctx, _("Активные цели"), "target")
        self.empty = EmptyState(_("Активных целей нет"), _("Поставьте цель — например, поднять ELO или K/D."), icon="target",
                                button_text=_("Создать цель"), compact=True,
                                on_click=lambda: ctx.bus.request_action.emit("create_goal"))
        self.list_host = QWidget()
        self.list_lay = QVBoxLayout(self.list_host)
        self.list_lay.setContentsMargins(0, 0, 0, 0)
        self.list_lay.setSpacing(10)
        self._pct_seen: dict[int, int] = {}
        self.more = ClickableLabel("")
        self.more.setObjectName("Muted")
        self.more.clicked.connect(_go(ctx, "goals"))
        self.body.addWidget(self.empty)
        self.body.addWidget(self.list_host)
        self.body.addWidget(self.more)
        self.body.addStretch(1)

    def refresh(self) -> None:
        active = self.ctx.repos.goals.list(status="active")
        self.empty.setVisible(not active)
        self.list_host.setVisible(bool(active))
        clear_layout(self.list_lay)
        for g in active[: self.MAX]:
            pct = goals_logic.progress_percent(g["start_value"], g["current_value"], g["target_value"])
            head = QHBoxLayout()
            head.addWidget(label(g["title"], "H3"), 1)
            head.addWidget(label(f"{pct}%", "Muted"))
            bar = QProgressBar()
            bar.setRange(0, 100)
            bar.setTextVisible(False)
            anim.set_progress(bar, pct, start=self._pct_seen.get(g["id"], 0))
            self._pct_seen[g["id"]] = pct
            sub = label(f"{goals_logic.fmt_value(g['current_value'])} / {goals_logic.fmt_value(g['target_value'])} {g['unit']}".strip(), "Muted")
            w = QWidget()
            v = QVBoxLayout(w)
            v.setContentsMargins(0, 0, 0, 0)
            v.setSpacing(3)
            v.addLayout(head)
            v.addWidget(bar)
            v.addWidget(sub)
            self.list_lay.addWidget(w)
        extra = len(active) - self.MAX
        self.more.setText(f"{_('Ещё целей')}: {extra} →" if extra > 0 else "")
        self.more.setVisible(extra > 0)


# ============================================================ Activity
class ActivityCard(DashCard):
    MAX = 6
    ICONS = {"match": "crosshair", "goal": "target", "account": "link", "steam": "gamepad", "faceit": "trophy",
             "spotify": "headphones", "music": "music", "system": "info"}

    def __init__(self, ctx):
        super().__init__(ctx, _("Последняя активность"), "activity")
        self.empty = EmptyState(_("Событий пока нет"), _("Здесь появятся подключения аккаунтов, матчи и выполненные цели."),
                                icon="activity", compact=True)
        self.list_host = QWidget()
        self.list_lay = QVBoxLayout(self.list_host)
        self.list_lay.setContentsMargins(0, 0, 0, 0)
        self.list_lay.setSpacing(8)
        self.body.addWidget(self.empty)
        self.body.addWidget(self.list_host)
        self.body.addStretch(1)

    def refresh(self) -> None:
        from ui import icons
        items = self.ctx.repos.activity.recent(self.MAX)
        self.empty.setVisible(not items)
        self.list_host.setVisible(bool(items))
        clear_layout(self.list_lay)
        c = theme.get().colors
        for it in items:
            row = QHBoxLayout()
            row.setSpacing(10)
            ic = label("")
            ic.setPixmap(icons.pixmap(self.ICONS.get(it["kind"], "info"), c["muted"], 16))
            ic.setFixedWidth(18)
            txt = label(it["text"], wrap=True)
            when = label(human_ago(it["ts"]), "Muted")
            row.addWidget(ic, 0, Qt.AlignmentFlag.AlignTop)
            row.addWidget(txt, 1)
            row.addWidget(when, 0, Qt.AlignmentFlag.AlignTop)
            w = QWidget()
            w.setLayout(row)
            self.list_lay.addWidget(w)


# ============================================================ Weekly Overview
class WeeklyCard(DashCard):
    def __init__(self, ctx):
        super().__init__(ctx, _("Обзор за неделю"), "bar-chart")
        grid = QGridLayout()
        grid.setSpacing(12)
        self.c_matches = ChartWidget(min_height=110, hover=True, empty_text=_("Нет матчей за неделю"))
        self.c_wl = ChartWidget(min_height=110, empty_text=_("Нет матчей за неделю"))
        self.c_kd = ChartWidget(min_height=110, empty_text=_("Нет данных K/D"))
        self.c_elo = ChartWidget(min_height=110, date_axis=True,
                                 empty_text=_("График ELO строится из снимков FACEIT — накапливается по мере обновлений"))
        self.c_goals = ChartWidget(min_height=110, empty_text=_("За неделю целей не выполнено"))
        specs = [(_("Матчи по дням"), self.c_matches, 0, 0, 1), (_("Победы и поражения"), self.c_wl, 0, 1, 1),
                 (_("Средний K/D по дням"), self.c_kd, 0, 2, 1), (_("FACEIT ELO"), self.c_elo, 1, 0, 2),
                 (_("Выполненные цели"), self.c_goals, 1, 2, 1)]
        for title, chart, r, c, span in specs:
            box = QVBoxLayout()
            box.setSpacing(4)
            box.addWidget(label(title, "H3"))
            box.addWidget(chart, 1)
            host = QWidget()
            host.setLayout(box)
            grid.addWidget(host, r, c, 1, span)
        for r in (0, 1):
            grid.setRowStretch(r, 1)
        for c in range(3):
            grid.setColumnStretch(c, 1)
        self.body.addLayout(grid, 1)

    def refresh(self) -> None:
        src = self.ctx.settings.get("dashboard_source") or "all"
        w = dashboard_data.weekly(self.ctx.repos, src, 7, date.today())
        labels = [d.strftime("%d.%m") for d in w["days"]]
        acc, ok, bad, warn = "accent", "success", "danger", "accent2"
        self.c_matches.plot_bars([{"name": _("Матчи"), "y": w["matches"], "color": acc, "fmt": "{:.0f}"}], labels)
        self.c_wl.plot_bars([{"name": _("Победы"), "y": w["wins"], "color": ok, "fmt": "{:.0f}"},
                             {"name": _("Поражения"), "y": w["losses"], "color": bad, "fmt": "{:.0f}"}], labels)
        if any(v is not None for v in w["kd"]):
            self.c_kd.plot_lines([{"name": "K/D", "y": w["kd"], "color": warn, "fmt": "{:.2f}"}], x_labels=labels)
        else:
            self.c_kd.show_empty()
        elo = dashboard_data.elo_series(self.ctx.repos, 7)
        if len(elo) >= 1:
            self.c_elo.plot_lines([{"name": "ELO", "x": [t for t, _v in elo], "y": [v for _t, v in elo], "color": acc,
                                    "fmt": "{:.0f}"}])
        else:
            self.c_elo.show_empty()
        gc = dashboard_data.goals_completed(self.ctx.repos, 7)
        self.c_goals.plot_bars([{"name": _("Цели"), "y": gc["completed"], "color": ok, "fmt": "{:.0f}"}],
                               [d.strftime("%d.%m") for d in gc["days"]])


# ============================================================ Quick actions
class QuickActionsCard(DashCard):
    ACTIONS = [
        ("Открыть CS2 Tracker", "crosshair", ("nav", "cs2_tracker")),
        ("Открыть PC Monitor", "cpu", ("nav", "pc_monitor")),
        ("Добавить матч", "plus", ("act", "add_match")),
        ("Создать цель", "target", ("act", "create_goal")),
        ("Открыть Steam", "gamepad", ("nav", "steam")),
        ("Открыть FACEIT", "trophy", ("nav", "faceit")),
        ("Открыть Music", "music", ("nav", "music")),
    ]

    def __init__(self, ctx):
        super().__init__(ctx, _("Быстрые действия"), "zap")
        host = QWidget()
        flow = FlowLayout(host, hspacing=10, vspacing=10)
        for text, icon, (kind, target) in self.ACTIONS:
            fn = (lambda t=target: ctx.bus.navigate.emit(t)) if kind == "nav" else (lambda t=target: ctx.bus.request_action.emit(t))
            b = button(_(text), "tile", icon, fn)
            b.setSizePolicy(QSizePolicy.Policy.Maximum, QSizePolicy.Policy.Fixed)
            flow.addWidget(b)
        self.body.addWidget(host)
        self.body.addStretch(1)


# ============================================================ реестр
# id -> (заголовок для панели «Виджеты», фабрика, (x, y, w, h), (min_w, min_h))
def registry() -> list[tuple[str, str, type, tuple[int, int, int, int], tuple[int, int], dict]]:
    pc = lambda k: {"key": k}  # noqa: E731
    return [
        ("pc_cpu", "CPU", PCMetricCard, (0, 0, 2, 3), (2, 3), pc("cpu")),
        ("pc_gpu", "GPU", PCMetricCard, (2, 0, 2, 3), (2, 3), pc("gpu")),
        ("pc_ram", "RAM", PCMetricCard, (4, 0, 2, 3), (2, 3), pc("ram")),
        ("pc_cpu_temp", "Температура CPU", PCMetricCard, (6, 0, 2, 3), (2, 3), pc("cpu_temp")),
        ("pc_gpu_temp", "Температура GPU", PCMetricCard, (8, 0, 2, 3), (2, 3), pc("gpu_temp")),
        ("pc_disk", "Диск", PCMetricCard, (10, 0, 2, 3), (2, 3), pc("disk")),
        ("quick", "Быстрые действия", QuickActionsCard, (0, 3, 12, 2), (4, 2), {}),
        ("stats", "Игровая статистика", GamingStatsCard, (0, 5, 6, 5), (4, 4), {}),
        ("faceit", "FACEIT", FaceitCard, (6, 5, 3, 5), (3, 5), {}),
        ("steam", "Steam", SteamCard, (9, 5, 3, 5), (3, 5), {}),
        ("spotify", "Spotify", SpotifyCard, (0, 10, 4, 5), (3, 5), {}),
        ("goals", "Активные цели", GoalsCard, (4, 10, 4, 5), (3, 4), {}),
        ("activity", "Последняя активность", ActivityCard, (8, 10, 4, 5), (3, 4), {}),
        ("weekly", "Обзор за неделю", WeeklyCard, (0, 15, 12, 7), (6, 6), {}),
    ]
