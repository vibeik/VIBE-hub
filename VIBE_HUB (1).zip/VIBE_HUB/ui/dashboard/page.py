"""Страница Dashboard: сетка карточек + режим «Настроить» (перемещение, размер, скрытие, включение виджетов)."""
from __future__ import annotations

import logging

from PySide6.QtCore import QTimer
from PySide6.QtWidgets import QMenu, QVBoxLayout, QWidget

from ui.common.base import Banner, Page, button
from ui.common.dialogs import confirm
from ui.common.util import disconnect_quiet
from ui.dashboard import cards as C
from ui.dashboard.grid_canvas import GridCanvas
from ui.dashboard.layout_engine import Item, Layout
from utils.i18n import _

log = logging.getLogger("vibehub.dashboard")


def default_items() -> list[Item]:
    return [Item(wid, x, y, w, h, True, mw, mh) for wid, _t, _c, (x, y, w, h), (mw, mh), _k in C.registry()]


class DashboardPage(Page):
    scrollable = True

    def __init__(self, ctx, parent=None):
        super().__init__(ctx, parent)
        self.cards: dict[str, C.DashCard] = {}
        self._titles: dict[str, str] = {}
        self._timer = QTimer(self)
        self._timer.setInterval(1000)
        self._timer.timeout.connect(self._tick)
        self._pending = False

        root = QVBoxLayout(self)
        root.setContentsMargins(28, 22, 28, 28)
        root.setSpacing(16)

        head, _col = self.page_header("Dashboard", _("Обзор вашего ПК, аккаунтов и целей"))
        self.btn_widgets = button(_("Виджеты"), icon="layout", on_click=self._show_widget_menu)
        self.btn_reset = button(_("Сбросить"), "ghost", "refresh", self._reset_layout, _("Вернуть раскладку по умолчанию"))
        self.btn_edit = button(_("Настроить"), icon="settings", on_click=self._toggle_edit)
        for b in (self.btn_widgets, self.btn_reset):
            b.setVisible(False)
            head.addWidget(b)
        head.addWidget(self.btn_edit)
        root.addLayout(head)

        self.hint = Banner(_("Режим настройки: перетаскивайте карточки, тяните за правый нижний угол, чтобы изменить размер, "
                             "значок «глаз» скрывает карточку. Скрытые карточки включаются в меню «Виджеты». "
                             "Раскладка сохраняется автоматически."), "info")
        self.hint.setVisible(False)
        root.addWidget(self.hint)

        self.canvas = GridCanvas()
        defaults = default_items()
        for wid, title, cls, _geom, _min, kw in C.registry():
            card = cls(ctx, **kw) if kw else cls(ctx)
            self.cards[wid] = card
            self._titles[wid] = title
            self.canvas.add_widget(wid, card)
        self.canvas.set_layout_model(Layout.from_saved(ctx.settings.get("dashboard_layout"), defaults))
        self.canvas.layout_changed.connect(self._save_layout)
        root.addWidget(self.canvas)
        root.addStretch(1)

        b = ctx.bus
        for sig in (b.matches_changed, b.goals_changed, b.activity_changed, b.accounts_changed):
            sig.connect(self.schedule)
        for ctl in (ctx.faceit, ctx.steam):
            ctl.updated.connect(self.schedule)
        b.settings_changed.connect(self._on_setting)

    def _on_setting(self, key: str, value) -> None:
        if key == "dashboard_source":
            self.schedule()
        elif key == "dashboard_layout" and value is None:      # «Сбросить раскладку» из настроек
            self.canvas.set_layout_model(Layout.from_defaults(default_items()))

    def entrance_targets(self) -> list[QWidget]:
        return self.canvas.visible_tiles()

    # ------------------------------------------------------------------ жизненный цикл
    def activated(self) -> None:
        self.ctx.monitor.snapshot.connect(self._on_sensors)
        self.ctx.monitor.watch()
        self._timer.start()

    def deactivated(self) -> None:
        disconnect_quiet(self.ctx.monitor.snapshot, self._on_sensors)
        self.ctx.monitor.unwatch()
        self._timer.stop()
        if self.canvas.editing:
            self._toggle_edit()

    def schedule(self) -> None:
        """Склеивает серию сигналов в одно обновление."""
        if self._pending:
            return
        self._pending = True

        def run() -> None:
            self._pending = False
            self.mark_dirty()
        QTimer.singleShot(80, run)

    def refresh(self) -> None:
        for wid, card in self.cards.items():
            try:
                card.refresh()
            except Exception:
                log.exception("Не удалось обновить карточку %s", wid)

    def _on_sensors(self, snap) -> None:
        for card in self.cards.values():
            if isinstance(card, C.PCMetricCard):
                try:
                    card.on_sensors(snap)
                except Exception:
                    log.exception("Ошибка обновления карточки датчика")

    def _tick(self) -> None:
        for card in self.cards.values():
            if isinstance(card, C.SpotifyCard) and self.ctx.spotify.connected:
                card.tick()

    # ------------------------------------------------------------------ настройка
    def _toggle_edit(self) -> None:
        on = not self.canvas.editing
        self.canvas.set_edit(on)
        self.btn_edit.setText(_("Готово") if on else _("Настроить"))
        self.btn_widgets.setVisible(on)
        self.btn_reset.setVisible(on)
        self.hint.setVisible(on)

    def _show_widget_menu(self) -> None:
        menu = QMenu(self)
        for wid, title in self._titles.items():
            it = self.canvas.layout_model.items.get(wid)
            act = menu.addAction(_(title))
            act.setCheckable(True)
            act.setChecked(bool(it and it.visible))
            act.toggled.connect(lambda on, w=wid: self.canvas.set_widget_visible(w, on))
        menu.exec(self.btn_widgets.mapToGlobal(self.btn_widgets.rect().bottomLeft()))

    def _reset_layout(self) -> None:
        if not confirm(self, _("Сбросить раскладку"), _("Вернуть расположение и размеры карточек по умолчанию?"),
                       ok=_("Сбросить"), danger=False):
            return
        self.canvas.set_layout_model(Layout.from_defaults(default_items()))
        self._save_layout(self.canvas.layout_model.to_json())

    def _save_layout(self, data) -> None:
        self.ctx.settings.set("dashboard_layout", data, notify=False)
        # карточкам, которые были скрыты, нужны свежие данные при показе
        self.schedule()
