"""Таблица стилей (QSS) из шаблона. Без Qt, поэтому сборка проверяется тестами (все подстановки заполнены)."""
from __future__ import annotations

from string import Template

from config.settings import app_root
from ui.palettes import hex_to_rgb, mix, on_accent


def rgba(hex_color: str, alpha: float) -> str:
    r, g, b = hex_to_rgb(hex_color)
    return f"rgba({r},{g},{b},{alpha:.2f})"


def _icon_url(name: str) -> str:
    p = (app_root() / "assets" / "icons" / name).as_posix()
    return f"url('{p}')"


_QSS = Template("""
* { font-family: "Segoe UI Variable Text", "Segoe UI", "Inter", sans-serif; color: $text; outline: none; }
QWidget { background: transparent; font-size: 13px; }
QMainWindow { background: $win_bg; }
QDialog, QMessageBox { background: $bg; }
QWidget#Root { background: $root_bg; }
QToolTip { background: $surface2; color: $text; border: 1px solid $border; padding: 6px 10px; border-radius: 10px; }

QLabel#H1 { font-size: 24px; font-weight: 600; }
QLabel#H2 { font-size: 16px; font-weight: 600; }
QLabel#H3 { font-size: 13px; font-weight: 600; }
QLabel#Muted, QLabel[muted="true"] { color: $muted; }
QLabel#Big { font-size: 28px; font-weight: 600; }
QLabel#Value { font-size: 20px; font-weight: 600; }
QLabel#Chip { border-radius: 10px; padding: 2px 10px; font-size: 11px; font-weight: 600;
  background: $chip_neutral; color: $muted; }
QLabel#Chip[kind="success"] { background: $chip_success; color: $success; }
QLabel#Chip[kind="warning"] { background: $chip_warning; color: $warning; }
QLabel#Chip[kind="danger"] { background: $chip_danger; color: $danger; }
QLabel#Chip[kind="accent"] { background: $chip_accent; color: $accent2; }

QFrame#Card { background: qlineargradient(x1:0,y1:0,x2:0,y2:1, stop:0 $card_top, stop:1 $card);
  border: 1px solid $card_border; border-radius: 22px; }
QFrame#Card[clickable="true"]:hover { border: 1px solid $accent; background: $card_hover; }
QFrame#Inset { background: $inset; border: 1px solid $card_border; border-radius: 16px; }
QFrame#Sidebar { background: $sidebar; border-right: 1px solid $card_border; }
QFrame#Line { background: $card_border; max-height: 1px; min-height: 1px; border: none; }

QPushButton { background: $surface2; border: 1px solid $border; border-radius: 14px; padding: 8px 18px; font-weight: 500; }
QPushButton:hover { border-color: $accent; background: $surface3; }
QPushButton:pressed { background: $surface; }
QPushButton:disabled { color: $muted; background: $surface; border-color: $card_border; }
QPushButton[kind="primary"] { border: none; color: $on_accent; font-weight: 600;
  background: qlineargradient(x1:0,y1:0,x2:1,y2:0, stop:0 $accent, stop:1 $accent2); }
QPushButton[kind="primary"]:hover { background: qlineargradient(x1:0,y1:0,x2:1,y2:0, stop:0 $accent_hi, stop:1 $accent2_hi); }
QPushButton[kind="primary"]:pressed { background: qlineargradient(x1:0,y1:0,x2:1,y2:0, stop:0 $accent_lo, stop:1 $accent2_lo); }
QPushButton[kind="primary"]:disabled { background: $surface2; color: $muted; }
QPushButton[kind="danger"] { color: $danger; border-color: $chip_danger; background: transparent; }
QPushButton[kind="danger"]:hover { background: $chip_danger; border-color: $danger; }
QPushButton[kind="ghost"] { background: transparent; border: none; color: $muted; padding: 6px 10px; }
QPushButton[kind="ghost"]:hover { color: $text; background: $inset; }
QPushButton[kind="tile"] { text-align: left; padding: 12px 14px; border-radius: 16px; background: $inset; border: 1px solid $card_border; }
QPushButton[kind="tile"]:hover { border-color: $accent; background: $chip_accent; }

QToolButton { background: transparent; border: none; border-radius: 10px; padding: 6px; }
QToolButton:hover { background: $inset; }
QToolButton:checked { background: $chip_accent; }
QPushButton[nav="true"] { border: 1px solid transparent; border-radius: 16px; padding: 10px 14px; text-align: left; font-weight: 500;
  color: $muted; background: transparent; }
QPushButton[nav="true"]:hover { background: $inset; color: $text; border: 1px solid transparent; }
QPushButton[nav="true"]:checked { background: qlineargradient(x1:0,y1:0,x2:1,y2:0, stop:0 $accent_soft, stop:1 $accent_faint);
  color: $text; border: 1px solid $accent_line; }
QFrame#Topbar { background: $topbar; border-bottom: 1px solid $card_border; }

QLineEdit, QSpinBox, QDoubleSpinBox, QDateEdit, QDateTimeEdit, QComboBox, QTextEdit, QPlainTextEdit {
  background: $inset; border: 1px solid $border; border-radius: 14px; padding: 7px 12px;
  selection-background-color: $accent; selection-color: $on_accent; }
QLineEdit:focus, QSpinBox:focus, QDoubleSpinBox:focus, QDateEdit:focus, QDateTimeEdit:focus,
QComboBox:focus, QTextEdit:focus, QPlainTextEdit:focus { border: 1px solid $accent; }
QLineEdit:disabled, QSpinBox:disabled, QComboBox:disabled { color: $muted; }
QSpinBox::up-button, QSpinBox::down-button, QDoubleSpinBox::up-button, QDoubleSpinBox::down-button { width: 0; border: none; }
QDateEdit::drop-down, QDateTimeEdit::drop-down, QComboBox::drop-down { border: none; width: 26px; }
QDateEdit::down-arrow, QDateTimeEdit::down-arrow, QComboBox::down-arrow { image: $img_chevron; width: 12px; height: 12px; }
QComboBox QAbstractItemView, QListView { background: $surface2; border: 1px solid $border; border-radius: 12px;
  selection-background-color: $accent; padding: 4px; outline: none; }
QCalendarWidget QWidget { background: $surface2; color: $text; }
QCalendarWidget QAbstractItemView:enabled { selection-background-color: $accent; color: $text; }

QCheckBox, QRadioButton { spacing: 8px; }
QCheckBox::indicator { width: 18px; height: 18px; border-radius: 6px; border: 1px solid $border; background: $inset; }
QCheckBox::indicator:checked { background: $accent; border-color: $accent; image: $img_check; }
QRadioButton::indicator { width: 16px; height: 16px; border-radius: 9px; border: 1px solid $border; background: $inset; }
QRadioButton::indicator:checked { background: $accent; border: 4px solid $inset; }

QSlider::groove:horizontal { height: 6px; border-radius: 3px; background: $border; }
QSlider::sub-page:horizontal { border-radius: 3px; background: qlineargradient(x1:0,y1:0,x2:1,y2:0, stop:0 $accent, stop:1 $accent2); }
QSlider::handle:horizontal { width: 14px; height: 14px; margin: -5px 0; border-radius: 7px; background: #FFFFFF; }
QProgressBar { background: $border; border: none; border-radius: 4px; max-height: 8px; min-height: 8px; text-align: center; color: transparent; }
QProgressBar::chunk { border-radius: 4px; background: qlineargradient(x1:0,y1:0,x2:1,y2:0, stop:0 $accent, stop:1 $accent2); }
QProgressBar[done="true"]::chunk { background: $success; }

QScrollArea, QScrollArea > QWidget > QWidget { background: transparent; border: none; }
QScrollBar:vertical { background: transparent; width: 10px; margin: 2px; }
QScrollBar::handle:vertical { background: $border; border-radius: 4px; min-height: 30px; }
QScrollBar::handle:vertical:hover { background: $muted; }
QScrollBar:horizontal { background: transparent; height: 10px; margin: 2px; }
QScrollBar::handle:horizontal { background: $border; border-radius: 4px; min-width: 30px; }
QScrollBar::add-line, QScrollBar::sub-line, QScrollBar::add-page, QScrollBar::sub-page { background: none; border: none; height: 0; width: 0; }
QScrollBar::add-page:vertical, QScrollBar::sub-page:vertical, QScrollBar::add-page:horizontal, QScrollBar::sub-page:horizontal { background: none; height: auto; width: auto; }

QTableWidget, QTableView, QTreeWidget { background: transparent; border: none; gridline-color: transparent;
  alternate-background-color: $inset; selection-background-color: $chip_accent; selection-color: $text; }
QTableWidget::item, QTableView::item { padding: 6px 8px; border: none; }
QHeaderView { background: transparent; }
QHeaderView::section { background: transparent; color: $muted; border: none; border-bottom: 1px solid $card_border;
  padding: 8px; font-weight: 600; font-size: 11px; }
QTableCornerButton::section { background: transparent; border: none; }
QListWidget { background: transparent; border: none; }
QListWidget::item { padding: 8px 10px; border-radius: 12px; }
QListWidget::item:hover { background: $inset; }
QListWidget::item:selected { background: $chip_accent; color: $text; }

QMenu { background: $surface2; border: 1px solid $border; border-radius: 14px; padding: 6px; }
QMenu::item { padding: 8px 22px 8px 14px; border-radius: 9px; }
QMenu::item:selected { background: $chip_accent; }
QMenu::separator { height: 1px; background: $border; margin: 6px 4px; }
QDialogButtonBox QPushButton { min-width: 90px; }
QGroupBox { border: 1px solid $card_border; border-radius: 16px; margin-top: 12px; padding-top: 14px; }
QGroupBox::title { subcontrol-origin: margin; left: 12px; padding: 0 6px; color: $muted; }

QLabel#CardTitle { color: $muted; font-size: 11px; font-weight: 600; }
QLabel#Value[tone="success"], QLabel#Big[tone="success"] { color: $success; }
QLabel#Value[tone="danger"], QLabel#Big[tone="danger"] { color: $danger; }
QLabel#Value[tone="warning"], QLabel#Big[tone="warning"] { color: $warning; }
QLabel#Value[tone="accent"], QLabel#Big[tone="accent"] { color: $accent2; }
QLabel#Value[tone="muted"], QLabel#Big[tone="muted"] { color: $muted; }
QLabel#Badge { background: $danger; color: #FFFFFF; border-radius: 9px; font-size: 10px; font-weight: 700; padding: 0 4px; }

QFrame#Seg { background: $inset; border: 1px solid $card_border; border-radius: 15px; }
QPushButton[kind="seg"] { background: transparent; border: none; border-radius: 11px; padding: 5px 12px; color: $muted; font-weight: 500; }
QPushButton[kind="seg"]:hover { color: $text; background: transparent; }
QPushButton[kind="seg"]:checked { background: $chip_accent; color: $text; }

QFrame#Toast { background: $surface2; border: 1px solid $border; border-radius: 16px; }
QFrame#Toast[kind="success"] { border-color: $success; }
QFrame#Toast[kind="warning"] { border-color: $warning; }
QFrame#Toast[kind="error"] { border-color: $danger; }
QFrame#Popup { background: $surface2; border: 1px solid $border; border-radius: 18px; }
QFrame#Row { background: $inset; border: 1px solid $card_border; border-radius: 14px; }
QFrame#Row:hover { border-color: $border; }
QFrame#Banner { background: $chip_warning; border: 1px solid $warning; border-radius: 14px; }
QFrame#Banner[kind="info"] { background: $chip_accent; border: 1px solid $accent; }
QFrame#Banner[kind="error"] { background: $chip_danger; border: 1px solid $danger; }
QSplitter::handle { background: transparent; }
QTabBar::tab { background: transparent; color: $muted; padding: 8px 14px; border: none; border-bottom: 2px solid transparent; }
QTabBar::tab:selected { color: $text; border-bottom: 2px solid $accent; }
QTabWidget::pane { border: none; }
""")


def build_qss(c: dict[str, str], glass_alpha: float | None = None) -> str:
    """Собирает QSS. glass_alpha — непрозрачность фона окна в режиме стекла (None — обычный непрозрачный фон)."""
    accent, accent2 = c["accent"], c["accent2"]
    ctx = dict(c)
    if glass_alpha is None:
        win_bg, root_bg = c["bg"], c["bg"]
        sidebar, topbar = rgba(c["surface"], 0.92), rgba(c["surface"], 0.55)
    else:
        a = max(0.30, min(0.95, glass_alpha))
        win_bg, root_bg = "transparent", rgba(c["bg"], a)
        sidebar, topbar = rgba(c["surface"], min(0.92, a * 0.85 + 0.05)), rgba(c["surface"], a * 0.55)
    ctx.update({
        "win_bg": win_bg, "root_bg": root_bg,
        "card": rgba(c["surface2"], 0.58), "card_top": rgba(mix(c["surface2"], "#FFFFFF", 0.07), 0.72),
        "card_hover": rgba(c["surface2"], 0.85),
        "card_border": rgba("#FFFFFF", 0.09), "inset": rgba("#FFFFFF", 0.04), "sidebar": sidebar,
        "surface3": rgba("#FFFFFF", 0.09), "topbar": topbar,
        "chip_neutral": rgba("#FFFFFF", 0.07), "chip_success": rgba(c["success"], 0.16),
        "chip_warning": rgba(c["warning"], 0.16), "chip_danger": rgba(c["danger"], 0.16),
        "chip_accent": rgba(accent, 0.22), "accent_soft": rgba(accent, 0.34), "accent_faint": rgba(accent, 0.10),
        "accent_line": rgba(accent, 0.45),
        "accent_hi": mix(accent, "#FFFFFF", 0.14), "accent2_hi": mix(accent2, "#FFFFFF", 0.14),
        "accent_lo": mix(accent, "#000000", 0.14), "accent2_lo": mix(accent2, "#000000", 0.14),
        "on_accent": on_accent(accent, accent2),
        "img_chevron": _icon_url("chevron-down.png"), "img_check": _icon_url("check.png"),
    })
    return _QSS.safe_substitute(ctx)
