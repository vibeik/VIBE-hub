"""Цели: создание, редактирование, ручной прогресс, авто-метрики из FACEIT/трекера, история."""
from __future__ import annotations

import logging

from PySide6.QtWidgets import (QComboBox, QDialog, QDoubleSpinBox, QHBoxLayout, QLineEdit, QProgressBar, QVBoxLayout, QWidget)

from modules import goal_service
from modules.goals import AUTO_METRICS, CATEGORIES, auto_value, fmt_value, is_reached, progress_percent
from ui import anim
from ui.common.base import Banner, Card, Chip, EmptyState, IconButton, Page, SegmentedControl, button, label
from ui.common.dialogs import FormDialog, confirm
from ui.common.tables import ALIGN_C, cell, fit_height, make_table
from ui.common.util import clear_layout, fmt_dt
from utils.i18n import _

log = logging.getLogger("vibehub.goals.ui")
FIELD_LABELS = {"created": "Создана", "title": "Название", "description": "Описание", "category": "Категория",
                "metric": "Метрика", "unit": "Единица", "start_value": "Старт", "current_value": "Прогресс",
                "target_value": "Цель", "status": "Статус"}
STATUS_LABELS = {"active": "активна", "completed": "выполнена"}


def _spin() -> QDoubleSpinBox:
    s = QDoubleSpinBox()
    s.setRange(-1_000_000, 1_000_000)
    s.setDecimals(2)
    return s


class GoalDialog(FormDialog):
    def __init__(self, parent, ctx, goal: dict | None = None):
        super().__init__(parent, _("Редактировать цель") if goal else _("Создать цель"),
                         ok_text=_("Сохранить") if goal else _("Создать"), width=500)
        self.ctx, self.goal = ctx, goal
        self.title_edit = QLineEdit()
        self.title_edit.setMaxLength(120)
        self.title_edit.setPlaceholderText(_("Например: Поднять ELO до 2000"))
        self.desc = QLineEdit()
        self.desc.setMaxLength(300)
        self.category = QComboBox()
        self.category.addItems(CATEGORIES)
        self.metric = QComboBox()
        for key, (text, _unit) in AUTO_METRICS.items():
            self.metric.addItem(_(text), key)
        self.unit = QLineEdit()
        self.unit.setMaxLength(20)
        self.start, self.current, self.target = _spin(), _spin(), _spin()
        self.auto_note = label("", "Muted", wrap=True)
        for text, w in ((_("Название"), self.title_edit), (_("Описание"), self.desc), (_("Категория"), self.category),
                        (_("Как отслеживать"), self.metric), (_("Единица"), self.unit), (_("Старт"), self.start),
                        (_("Сейчас"), self.current), (_("Цель"), self.target)):
            self.form.addRow(text, w)
        self.add_content(self.auto_note)
        self.metric.currentIndexChanged.connect(self._on_metric)
        if goal:
            self.title_edit.setText(goal["title"])
            self.desc.setText(goal["description"])
            self.category.setCurrentText(goal["category"])
            self.metric.setCurrentIndex(max(0, self.metric.findData(goal["metric"])))
            self.unit.setText(goal["unit"])
            self.start.setValue(goal["start_value"])
            self.current.setValue(goal["current_value"])
            self.target.setValue(goal["target_value"])
        self._on_metric()

    def _auto_context(self) -> dict:
        return goal_service.build_context(self.ctx.repos, self.ctx.faceit.overview(), self.ctx.settings.get("dashboard_source") or "all")

    def _on_metric(self) -> None:
        key = self.metric.currentData()
        auto = key != "manual"
        self.current.setEnabled(not auto)
        if not auto:
            self.auto_note.setVisible(False)
            return
        unit = AUTO_METRICS[key][1]
        if not self.unit.text() or self.unit.text() in {u for _t, u in AUTO_METRICS.values()}:
            self.unit.setText(unit)
        val = auto_value(key, self._auto_context())
        if val is None:
            self.auto_note.setText(_("Данных для этой метрики пока нет (нужны подключённый FACEIT или матчи в трекере). "
                                     "Прогресс начнёт обновляться, как только они появятся."))
        else:
            self.current.setValue(val)
            if not self.goal:
                self.start.setValue(val)
            self.auto_note.setText(f"{_('Сейчас')}: {fmt_value(val)}. {_('Значение обновляется автоматически.')}")
        self.auto_note.setVisible(True)

    def validate(self) -> str | None:
        if not self.title_edit.text().strip():
            return _("Введите название цели.")
        if self.target.value() == self.start.value():
            return _("Цель должна отличаться от стартового значения.")
        return None

    def apply(self) -> None:
        repo = self.ctx.repos.goals
        d = dict(title=self.title_edit.text().strip(), description=self.desc.text().strip(), category=self.category.currentText(),
                 metric=self.metric.currentData(), unit=self.unit.text().strip())
        if self.goal:
            repo.update(self.goal["id"], start_value=self.start.value(), target_value=self.target.value(), **d)
            repo.set_current(self.goal["id"], self.current.value(), note=_("правка"))
            self.gid = self.goal["id"]
        else:
            self.gid = repo.create(d["title"], self.target.value(), description=d["description"], category=d["category"],
                                   metric=d["metric"], unit=d["unit"], start=self.start.value(), current=self.current.value())


class ProgressDialog(FormDialog):
    def __init__(self, parent, goal: dict):
        super().__init__(parent, _("Обновить прогресс"), ok_text=_("Сохранить"), width=420,
                         intro=f"{goal['title']}\n{_('Цель')}: {fmt_value(goal['target_value'])} {goal['unit']}")
        self.value = _spin()
        self.value.setValue(goal["current_value"])
        self.note = QLineEdit()
        self.note.setPlaceholderText(_("Комментарий (необязательно)"))
        self.form.addRow(_("Текущее значение"), self.value)
        self.form.addRow(_("Заметка"), self.note)


class HistoryDialog(QDialog):
    def __init__(self, parent, goal: dict, rows: list[dict]):
        super().__init__(parent)
        self.setWindowTitle(f"{_('История')}: {goal['title']}")
        self.setMinimumSize(640, 380)
        lay = QVBoxLayout(self)
        lay.setContentsMargins(20, 18, 20, 18)
        t = make_table([_("Когда"), _("Что"), _("Было"), _("Стало"), _("Комментарий")], stretch_col=4)
        t.setRowCount(len(rows))
        for r, h in enumerate(rows):
            t.setItem(r, 0, cell(fmt_dt(h["changed_at"], True)))
            t.setItem(r, 1, cell(_(FIELD_LABELS.get(h["field"], h["field"]))))
            old, new = h["old_value"], h["new_value"]
            if h["field"] == "status":
                old, new = (_(STATUS_LABELS.get(old, old)) if old else "—"), _(STATUS_LABELS.get(new, new))
            t.setItem(r, 2, cell(old if old is not None else "—", align=ALIGN_C))
            t.setItem(r, 3, cell(new if new is not None else "—", align=ALIGN_C))
            t.setItem(r, 4, cell(h["note"] or ""))
        fit_height(t, 12)
        lay.addWidget(t)
        close = button(_("Закрыть"), on_click=self.accept)
        lay.addWidget(close)


class GoalsPage(Page):
    def __init__(self, ctx, parent=None):
        super().__init__(ctx, parent)
        self._pct_seen: dict[int, int] = {}      # прежний прогресс целей: полоска доезжает, а не стартует с нуля
        root = QVBoxLayout(self)
        root.setContentsMargins(28, 22, 28, 28)
        root.setSpacing(16)
        head, _col = self.page_header(_("Цели"), _("Личные и игровые цели с прогрессом"))
        self.seg = SegmentedControl([("active", _("Активные")), ("completed", _("Выполненные")), ("all", _("Все"))], "active")
        self.seg.changed.connect(lambda _k: self.refresh())
        head.addWidget(self.seg)
        head.addWidget(button(_("Создать цель"), "primary", "plus", self.create_goal))
        root.addLayout(head)
        self.info = Banner("", "info")
        root.addWidget(self.info)
        self.empty = EmptyState(_("Целей пока нет"), _("Поставьте цель — например, «ELO 2000» или «K/D 1.2». "
                                                         "Цели с авто-метрикой обновляются сами."),
                                icon="target", button_text=_("Создать цель"), on_click=self.create_goal)
        root.addWidget(self.empty)
        self.list_host = QWidget()
        self.list_lay = QVBoxLayout(self.list_host)
        self.list_lay.setContentsMargins(0, 0, 0, 0)
        self.list_lay.setSpacing(12)
        root.addWidget(self.list_host)
        root.addStretch(1)
        ctx.bus.goals_changed.connect(self.mark_dirty)

    # ------------------------------------------------------------------ действия
    def handle_action(self, action: str) -> None:
        if action == "create_goal":
            self.create_goal()

    def _changed(self) -> None:
        self.ctx.bus.goals_changed.emit()
        self.ctx.bus.activity_changed.emit()

    def create_goal(self) -> None:
        dlg = GoalDialog(self, self.ctx)
        if dlg.exec():
            g = self.ctx.repos.goals.get(dlg.gid)
            if g:
                self.ctx.log_activity("goal", f"{_('Создана цель')}: {g['title']}", ref=str(g["id"]))
                if g["status"] == "active" and is_reached(g["start_value"], g["current_value"], g["target_value"]):
                    self._complete(g["id"], g["current_value"])
            self._changed()

    def edit_goal(self, gid: int) -> None:
        g = self.ctx.repos.goals.get(gid)
        if g and GoalDialog(self, self.ctx, g).exec():
            self._changed()
            self.ctx.sync_goals()

    def update_progress(self, gid: int) -> None:
        g = self.ctx.repos.goals.get(gid)
        if g is None:
            return
        dlg = ProgressDialog(self, g)
        if dlg.exec():
            self._complete(gid, dlg.value.value(), dlg.note.text().strip())
            self._changed()

    def _complete(self, gid: int, value: float, note: str = "") -> None:
        if self.ctx.repos.goals.set_current(gid, value, note):
            g = self.ctx.repos.goals.get(gid)
            if g:
                self.ctx.notify("success", _("Цель выполнена 🎯"), g["title"])
                self.ctx.log_activity("goal", f"{_('Цель выполнена')}: {g['title']}", ref=str(gid))

    def delete_goal(self, gid: int) -> None:
        g = self.ctx.repos.goals.get(gid)
        if g and confirm(self, _("Удалить цель"), f"{_('Удалить цель')} «{g['title']}»? {_('История изменений тоже будет удалена.')}"):
            self.ctx.repos.goals.delete(gid)
            self._changed()

    def show_history(self, gid: int) -> None:
        g = self.ctx.repos.goals.get(gid)
        if g:
            HistoryDialog(self, g, self.ctx.repos.goals.history(gid)).exec()

    # ------------------------------------------------------------------ отображение
    def refresh(self) -> None:
        kind = self.seg.current()
        goals = self.ctx.repos.goals.list(status=None if kind == "all" else kind)
        total = self.ctx.repos.goals.list()
        self.empty.setVisible(not goals)
        if not goals and total:
            self.empty.set_texts(_("Здесь пока пусто"), _("В этой вкладке целей нет."))
        elif not total:
            self.empty.set_texts(_("Целей пока нет"), _("Поставьте цель — например, «ELO 2000» или «K/D 1.2». Цели с авто-метрикой обновляются сами."))
        self.list_host.setVisible(bool(goals))
        gctx = goal_service.build_context(self.ctx.repos, self.ctx.faceit.overview(), self.ctx.settings.get("dashboard_source") or "all")
        auto_missing = [g for g in total if g["metric"] != "manual" and g["status"] == "active"
                        and auto_value(g["metric"], gctx) is None]
        self.info.set_text(_("Для некоторых авто-целей пока нет данных: подключите FACEIT или добавьте матчи — прогресс обновится сам.")
                           if auto_missing else "")
        clear_layout(self.list_lay)
        for g in goals:
            self.list_lay.addWidget(self._goal_card(g))

    def _goal_card(self, g: dict) -> Card:
        done = g["status"] == "completed"
        pct = progress_percent(g["start_value"], g["current_value"], g["target_value"])
        card = Card()
        top = QHBoxLayout()
        top.setSpacing(8)
        top.addWidget(label(g["title"], "H2"))
        top.addWidget(Chip(g["category"], "neutral"))
        if g["metric"] != "manual":
            top.addWidget(Chip(_("Авто"), "accent"))
        if done:
            top.addWidget(Chip(_("Выполнена"), "success"))
        top.addStretch(1)
        if g["metric"] == "manual" and not done:
            top.addWidget(button(_("Обновить прогресс"), icon="trending-up", on_click=lambda gid=g["id"]: self.update_progress(gid)))
        top.addWidget(IconButton("history", _("История изменений"), on_click=lambda gid=g["id"]: self.show_history(gid)))
        top.addWidget(IconButton("edit", _("Изменить"), on_click=lambda gid=g["id"]: self.edit_goal(gid)))
        top.addWidget(IconButton("trash", _("Удалить"), on_click=lambda gid=g["id"]: self.delete_goal(gid)))
        card.body.addLayout(top)
        if g["description"]:
            card.body.addWidget(label(g["description"], "Muted", wrap=True))
        bar = QProgressBar()
        bar.setRange(0, 100)
        bar.setTextVisible(False)
        bar.setProperty("done", done)
        anim.set_progress(bar, pct, start=self._pct_seen.get(g["id"], 0))
        self._pct_seen[g["id"]] = pct
        card.body.addWidget(bar)
        unit = f" {g['unit']}" if g["unit"] else ""
        line = QHBoxLayout()
        line.addWidget(label(f"{fmt_value(g['current_value'])} / {fmt_value(g['target_value'])}{unit}", "H3"))
        line.addStretch(1)
        extra = f" · {_('выполнена')} {fmt_dt(g['completed_at'], True)}" if done and g.get("completed_at") else ""
        line.addWidget(label(f"{pct}%{extra}", "Muted"))
        card.body.addLayout(line)
        return card
