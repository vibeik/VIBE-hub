"""Сторож цикла событий Qt: измеряет, насколько опаздывает таймер, то есть как долго интерфейс «подвисал».

Накопленные данные (utils.perf.PerfStats) попадают в журнал при выходе и в отчёт, который можно скопировать
из Настроек. Сам сторож почти ничего не стоит: один таймер раз в 50 мс и несколько арифметических операций."""
from __future__ import annotations

import logging
import platform
import time
from collections.abc import Callable

from PySide6.QtCore import QObject, Qt, QTimer, qVersion

from config.settings import APP_NAME, APP_VERSION
from utils.perf import STALL_MS, PerfStats

log = logging.getLogger("vibehub.perf")

INTERVAL_MS = 50
LOG_EVERY_S = 1.0          # отдельные строки про подвисания не чаще раза в секунду, чтобы не засорять журнал


class LoopWatchdog(QObject):
    def __init__(self, stats: PerfStats, provider: Callable[[], str] | None = None, parent: QObject | None = None):
        super().__init__(parent)
        self.stats = stats
        self._provider = provider                          # что сейчас на экране: «page:steam», «minimized»...
        self._transient: tuple[str, float] | None = None   # (контекст, до какого момента монотонных часов)
        self._last = time.perf_counter()
        self._last_log = 0.0
        self._suppressed = 0
        self._timer = QTimer(self)
        self._timer.setTimerType(Qt.TimerType.PreciseTimer)
        self._timer.setInterval(INTERVAL_MS)
        self._timer.timeout.connect(self._tick)

    def start(self) -> None:
        self._last = time.perf_counter()
        self._timer.start()

    def stop(self) -> None:
        self._timer.stop()

    def transient(self, name: str, ms: int) -> None:
        """Следующие `ms` миллисекунд подвисания относятся к `name` (например, переход между вкладками)."""
        self._transient = (name, time.monotonic() + ms / 1000.0)

    def context(self) -> str:
        tr = self._transient
        if tr is not None:
            if time.monotonic() < tr[1]:
                return tr[0]
            self._transient = None
        if self._provider is not None:
            try:
                return self._provider()
            except Exception:
                return "?"
        return "app"

    def _tick(self) -> None:
        now = time.perf_counter()
        late_ms = (now - self._last) * 1000.0 - INTERVAL_MS
        self._last = now
        ctx = self.context()
        self.stats.record(ctx, late_ms)
        if late_ms >= STALL_MS and late_ms < 5000.0:
            mono = time.monotonic()
            if mono - self._last_log >= LOG_EVERY_S:
                extra = f" (+{self._suppressed} похожих)" if self._suppressed else ""
                log.warning("Подвисание интерфейса на %.0f мс, экран: %s%s", late_ms, ctx, extra)
                self._last_log, self._suppressed = mono, 0
            else:
                self._suppressed += 1


def collect_env(ctx) -> dict[str, str]:
    """Сведения о машине и настройках, без которых цифры задержек трудно понять (разрешение, масштаб, стекло)."""
    env: dict[str, str] = {"app": f"{APP_NAME} {APP_VERSION}", "os": platform.platform(),
                           "python": platform.python_version()}
    try:
        import PySide6
        from PySide6.QtGui import QGuiApplication
        env["qt"] = f"PySide6 {PySide6.__version__} / Qt {qVersion()}"
        env["qpa"] = QGuiApplication.platformName()
        scr = QGuiApplication.primaryScreen()
        if scr is not None:
            g = scr.geometry()
            env["screen"] = (f"{g.width()}x{g.height()} logical, DPR {scr.devicePixelRatio():.2f}, "
                             f"{scr.refreshRate():.0f} Hz, screens: {len(QGuiApplication.screens())}")
    except Exception:
        log.debug("Не удалось собрать сведения об экране", exc_info=True)
    try:
        import psutil
        env["cpu"] = f"{psutil.cpu_count(logical=False)} cores / {psutil.cpu_count()} threads"
    except Exception:
        pass
    try:
        tm = ctx.theme
        env["glass"] = f"{tm.glass_mode} (background alpha {tm.glass_alpha():.2f})"
        env["animations"] = "on" if tm.animations else "off"
        env["theme"] = str(ctx.settings.get("theme"))
        env["sensors"] = (f"interval {ctx.monitor.interval_ms} ms, effective {ctx.monitor.effective_interval()} ms, "
                          f"watchers {ctx.monitor.watchers}, history {'on' if ctx.monitor.record else 'off'}")
    except Exception:
        log.debug("Не удалось собрать сведения о настройках", exc_info=True)
    return env


def build_report(ctx) -> str:
    ctx.perf.env = collect_env(ctx)
    return ctx.perf.report()
