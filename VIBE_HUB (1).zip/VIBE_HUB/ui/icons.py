"""Векторные иконки (SVG, 24×24, штриховой стиль) с перекраской под тему.

Использование:
    icon("dashboard", color="#8D8DA6", on_color="#FFFFFF")  -> QIcon
    pixmap("bell", "#ECECF5", 20)                           -> QPixmap
    service_logo("spotify", 40)                             -> QPixmap (нейтральный значок-монограмма сервиса;
                                                               если есть assets/images/logos/<service>.png|svg — берётся он)
    app_logo(64, "yellow")                                   -> QPixmap (логотип V; варианты — utils/logo.py)
    app_icon("violet")                                       -> QIcon (все размеры, для окна и панели задач)
Рендер — через QtSvg, результат кэшируется.
"""
from __future__ import annotations

from functools import lru_cache
from pathlib import Path

from PySide6.QtCore import QByteArray, QRectF, Qt
from PySide6.QtGui import QColor, QFont, QGuiApplication, QIcon, QLinearGradient, QPainter, QPixmap
from PySide6.QtSvg import QSvgRenderer

from utils import logo

_G = '<g fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round">{}</g>'

# имя -> внутренняя разметка (viewBox 0 0 24 24)
ICONS: dict[str, str] = {
    "dashboard": '<rect x="3" y="3" width="7" height="7" rx="1.5"/><rect x="14" y="3" width="7" height="7" rx="1.5"/>'
                 '<rect x="14" y="14" width="7" height="7" rx="1.5"/><rect x="3" y="14" width="7" height="7" rx="1.5"/>',
    "crosshair": '<circle cx="12" cy="12" r="9"/><path d="M22 12h-4M6 12H2M12 6V2M12 22v-4"/>',
    "activity": '<path d="M3 12h4l3-8 4 16 3-8h4"/>',
    "cpu": '<rect x="5" y="5" width="14" height="14" rx="2"/><rect x="9" y="9" width="6" height="6"/>'
           '<path d="M9 2v3M15 2v3M9 19v3M15 19v3M2 9h3M2 15h3M19 9h3M19 15h3"/>',
    "gpu": '<rect x="2" y="6" width="18" height="11" rx="2"/><circle cx="9" cy="11.5" r="2.6"/>'
           '<path d="M15 9.5h2M15 13.5h2M5 20h14"/>',
    "memory": '<rect x="2" y="6" width="20" height="12" rx="2"/><path d="M6 10v4M10 10v4M14 10v4M18 10v4"/>',
    "thermometer": '<path d="M14 14.76V3.5a2.5 2.5 0 0 0-5 0v11.26a4.5 4.5 0 1 0 5 0z"/>',
    "hard-drive": '<path d="M22 12H2"/><path d="M5.45 5.11 2 12v6a2 2 0 0 0 2 2h16a2 2 0 0 0 2-2v-6l-3.45-6.89A2 2 0 0 0 16.76 4H7.24a2 2 0 0 0-1.79 1.11z"/>'
                  '<path d="M6 16h.01M10 16h.01"/>',
    "network": '<path d="M8 4v16M4 16l4 4 4-4"/><path d="M16 20V4M12 8l4-4 4 4"/>',
    "gamepad": '<path d="M6 11h4M8 9v4"/><path d="M15 12h.01M18 10h.01"/>'
               '<path d="M17.32 5H6.68a4 4 0 0 0-3.978 3.59C2.604 9.416 2 14.456 2 16a3 3 0 0 0 3 3c1 0 1.5-.5 2-1l1.414-1.414A2 2 0 0 1 9.828 16h4.344a2 2 0 0 1 1.414.586L17 18c.5.5 1 1 2 1a3 3 0 0 0 3-3c0-1.545-.604-6.584-.685-7.258A4 4 0 0 0 17.32 5z"/>',
    "trophy": '<path d="M6 9H4.5a2.5 2.5 0 0 1 0-5H6"/><path d="M18 9h1.5a2.5 2.5 0 0 0 0-5H18"/><path d="M4 22h16"/>'
              '<path d="M10 14.66V17c0 .55-.47.98-.97 1.21C7.85 18.75 7 20.24 7 22"/>'
              '<path d="M14 14.66V17c0 .55.47.98.97 1.21C16.15 18.75 17 20.24 17 22"/><path d="M18 2H6v7a6 6 0 0 0 12 0V2z"/>',
    "headphones": '<path d="M3 14v-2a9 9 0 0 1 18 0v2"/>'
                  '<path d="M21 19a2 2 0 0 1-2 2h-1a2 2 0 0 1-2-2v-3a2 2 0 0 1 2-2h3zM3 19a2 2 0 0 0 2 2h1a2 2 0 0 0 2-2v-3a2 2 0 0 0-2-2H3z"/>',
    "music": '<path d="M9 18V5l12-2v13"/><circle cx="6" cy="18" r="3"/><circle cx="18" cy="16" r="3"/>',
    "target": '<circle cx="12" cy="12" r="10"/><circle cx="12" cy="12" r="6"/><circle cx="12" cy="12" r="2"/>',
    "link": '<path d="M10 13a5 5 0 0 0 7.54.54l3-3a5 5 0 0 0-7.07-7.07l-1.72 1.71"/>'
            '<path d="M14 11a5 5 0 0 0-7.54-.54l-3 3a5 5 0 0 0 7.07 7.07l1.71-1.71"/>',
    "settings": '<path d="M10.36 4.89 L10.58 2.51 L13.42 2.51 L13.64 4.89 A7.3 7.3 0 0 1 15.87 5.81 L17.71 4.28 L19.72 6.29 L18.19 8.13 A7.3 7.3 0 0 1 19.11 10.36 L21.49 10.58 L21.49 13.42 L19.11 13.64 A7.3 7.3 0 0 1 18.19 15.87 L19.72 17.71 L17.71 19.72 L15.87 18.19 A7.3 7.3 0 0 1 13.64 19.11 L13.42 21.49 L10.58 21.49 L10.36 19.11 A7.3 7.3 0 0 1 8.13 18.19 L6.29 19.72 L4.28 17.71 L5.81 15.87 A7.3 7.3 0 0 1 4.89 13.64 L2.51 13.42 L2.51 10.58 L4.89 10.36 A7.3 7.3 0 0 1 5.81 8.13 L4.28 6.29 L6.29 4.28 L8.13 5.81 A7.3 7.3 0 0 1 10.36 4.89 Z"/><circle cx="12" cy="12" r="3.1"/>',
    "bell": '<path d="M6 8a6 6 0 0 1 12 0c0 7 3 9 3 9H3s3-2 3-9"/><path d="M10.3 21a1.94 1.94 0 0 0 3.4 0"/>',
    "plus": '<path d="M12 5v14M5 12h14"/>',
    "play": '<path d="M7 4.5v15a.8.8 0 0 0 1.2.7l12-7.5a.8.8 0 0 0 0-1.4L8.2 3.8A.8.8 0 0 0 7 4.5z" fill="currentColor"/>',
    "pause": '<rect x="6" y="4" width="4" height="16" rx="1.2" fill="currentColor"/><rect x="14" y="4" width="4" height="16" rx="1.2" fill="currentColor"/>',
    "next": '<path d="M5 5v14l11-7z" fill="currentColor"/><path d="M19 5v14"/>',
    "prev": '<path d="M19 5v14L8 12z" fill="currentColor"/><path d="M5 5v14"/>',
    "shuffle": '<path d="M16 3h5v5"/><path d="M4 20 21 3"/><path d="M21 16v5h-5"/><path d="M15 15l6 6"/><path d="M4 4l5 5"/>',
    "repeat": '<path d="m17 2 4 4-4 4"/><path d="M3 11v-1a4 4 0 0 1 4-4h14"/><path d="m7 22-4-4 4-4"/><path d="M21 13v1a4 4 0 0 1-4 4H3"/>',
    "repeat-one": '<path d="m17 2 4 4-4 4"/><path d="M3 11v-1a4 4 0 0 1 4-4h14"/><path d="m7 22-4-4 4-4"/>'
                  '<path d="M21 13v1a4 4 0 0 1-4 4H3"/><path d="M11 10h1v4"/>',
    "volume": '<path d="M11 5 6 9H2v6h4l5 4z"/><path d="M15.5 8.5a5 5 0 0 1 0 7"/><path d="M19 5a10 10 0 0 1 0 14"/>',
    "volume-off": '<path d="M11 5 6 9H2v6h4l5 4z"/><path d="m22 9-6 6M16 9l6 6"/>',
    "search": '<circle cx="11" cy="11" r="7"/><path d="m21 21-4.3-4.3"/>',
    "edit": '<path d="M12 20h9"/><path d="M16.5 3.5a2.12 2.12 0 0 1 3 3L7 19l-4 1 1-4z"/>',
    "trash": '<path d="M3 6h18"/><path d="M8 6V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"/>'
             '<path d="m19 6-1 14a2 2 0 0 1-2 2H8a2 2 0 0 1-2-2L5 6"/><path d="M10 11v6M14 11v6"/>',
    "refresh": '<path d="M21 12a9 9 0 0 0-15.5-6.3L3 8"/><path d="M3 3v5h5"/><path d="M3 12a9 9 0 0 0 15.5 6.3L21 16"/><path d="M16 16h5v5"/>',
    "x": '<path d="M18 6 6 18M6 6l12 12"/>',
    "check": '<path d="M20 6 9 17l-5-5"/>',
    "check-circle": '<circle cx="12" cy="12" r="10"/><path d="m8 12 3 3 5-6"/>',
    "chevron-down": '<path d="m6 9 6 6 6-6"/>',
    "chevron-up": '<path d="m18 15-6-6-6 6"/>',
    "chevron-left": '<path d="m15 18-6-6 6-6"/>',
    "chevron-right": '<path d="m9 18 6-6-6-6"/>',
    "grip": '<g fill="currentColor" stroke="none"><circle cx="9" cy="6" r="1.4"/><circle cx="15" cy="6" r="1.4"/>'
            '<circle cx="9" cy="12" r="1.4"/><circle cx="15" cy="12" r="1.4"/><circle cx="9" cy="18" r="1.4"/><circle cx="15" cy="18" r="1.4"/></g>',
    "eye": '<path d="M2 12s3.5-7 10-7 10 7 10 7-3.5 7-10 7S2 12 2 12z"/><circle cx="12" cy="12" r="3"/>',
    "eye-off": '<path d="M17.94 17.94A10.07 10.07 0 0 1 12 19c-6.5 0-10-7-10-7a18.5 18.5 0 0 1 5.06-5.94M9.9 4.24A9.1 9.1 0 0 1 12 4c6.5 0 10 7 10 7a18.5 18.5 0 0 1-2.16 3.19"/><path d="M1 1l22 22"/>',
    "layout": '<rect x="3" y="3" width="18" height="18" rx="2"/><path d="M3 9h18M9 21V9"/>',
    "folder": '<path d="M20 20a2 2 0 0 0 2-2V8a2 2 0 0 0-2-2h-7.9a2 2 0 0 1-1.69-.9L9.6 3.9A2 2 0 0 0 7.93 3H4a2 2 0 0 0-2 2v13a2 2 0 0 0 2 2z"/>',
    "folder-plus": '<path d="M20 20a2 2 0 0 0 2-2V8a2 2 0 0 0-2-2h-7.9a2 2 0 0 1-1.69-.9L9.6 3.9A2 2 0 0 0 7.93 3H4a2 2 0 0 0-2 2v13a2 2 0 0 0 2 2z"/><path d="M12 10v6M9 13h6"/>',
    "download": '<path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><path d="m7 10 5 5 5-5"/><path d="M12 15V3"/>',
    "upload": '<path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><path d="m17 8-5-5-5 5"/><path d="M12 3v12"/>',
    "external": '<path d="M15 3h6v6"/><path d="M10 14 21 3"/><path d="M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6"/>',
    "clock": '<circle cx="12" cy="12" r="10"/><path d="M12 6v6l4 2"/>',
    "user": '<path d="M19 21v-2a4 4 0 0 0-4-4H9a4 4 0 0 0-4 4v2"/><circle cx="12" cy="7" r="4"/>',
    "history": '<path d="M3 12a9 9 0 1 0 3-6.7L3 8"/><path d="M3 3v5h5"/><path d="M12 7v5l4 2"/>',
    "list": '<path d="M8 6h13M8 12h13M8 18h13M3 6h.01M3 12h.01M3 18h.01"/>',
    "lock": '<rect x="3" y="11" width="18" height="11" rx="2"/><path d="M7 11V7a5 5 0 0 1 10 0v4"/>',
    "bar-chart": '<path d="M12 20V10M18 20V4M6 20v-4"/>',
    "zap": '<path d="M13 2 3 14h9l-1 8 10-12h-9z"/>',
    "trending-up": '<path d="m22 7-8.5 8.5-5-5L2 17"/><path d="M16 7h6v6"/>',
    "alert": '<path d="m21.73 18-8-14a2 2 0 0 0-3.48 0l-8 14A2 2 0 0 0 4 21h16a2 2 0 0 0 1.73-3z"/><path d="M12 9v4M12 17h.01"/>',
    "info": '<circle cx="12" cy="12" r="10"/><path d="M12 16v-4M12 8h.01"/>',
    "panel-left": '<rect x="3" y="3" width="18" height="18" rx="2"/><path d="M9 3v18"/>',
    "copy": '<rect x="9" y="9" width="13" height="13" rx="2"/><path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"/>',
    "key": '<circle cx="7.5" cy="15.5" r="4.5"/><path d="m10.7 12.3 9.8-9.8M16 7l3 3M14 9l2 2"/>',
    "disc": '<circle cx="12" cy="12" r="10"/><circle cx="12" cy="12" r="3"/>',
    "list-music": '<path d="M21 15V6"/><circle cx="18.5" cy="18" r="2.5"/><path d="M12 12H3M16 6H3M12 18H3"/>',
    "calendar": '<rect x="3" y="4" width="18" height="18" rx="2"/><path d="M16 2v4M8 2v4M3 10h18"/>',
    "flag": '<path d="M4 22V4a1 1 0 0 1 1-1h13l-2 5 2 5H5"/>',
    "database": '<ellipse cx="12" cy="5" rx="9" ry="3"/><path d="M3 5v14c0 1.7 4 3 9 3s9-1.3 9-3V5"/><path d="M3 12c0 1.7 4 3 9 3s9-1.3 9-3"/>',
    "palette": '<circle cx="13.5" cy="6.5" r="1" fill="currentColor"/><circle cx="17.5" cy="10.5" r="1" fill="currentColor"/>'
               '<circle cx="8.5" cy="7.5" r="1" fill="currentColor"/><circle cx="6.5" cy="12.5" r="1" fill="currentColor"/>'
               '<path d="M12 2a10 10 0 1 0 0 20c1.1 0 2-.9 2-2 0-.5-.2-1-.5-1.3-.3-.4-.5-.8-.5-1.3 0-1.1.9-2 2-2h2.4a4.6 4.6 0 0 0 4.6-4.6C22 6 17.5 2 12 2z"/>',
    "globe": '<circle cx="12" cy="12" r="10"/><path d="M2 12h20"/><path d="M12 2a15.3 15.3 0 0 1 4 10 15.3 15.3 0 0 1-4 10 15.3 15.3 0 0 1-4-10 15.3 15.3 0 0 1 4-10z"/>',
    "power": '<path d="M12 2v10"/><path d="M18.4 6.6a9 9 0 1 1-12.8 0"/>',
}

# Нейтральные значки сервисов: монограмма на градиенте. Официальные логотипы в приложение не вшиты;
# при желании положите свои файлы steam / faceit / spotify (.png, .svg или .jpg) в папку logos в папке данных
# (кнопка «Открыть папку логотипов» в Настройках) или в assets/images/logos — они будут использованы.
SERVICE_BADGES: dict[str, tuple[str, str, str]] = {
    "steam": ("S", "#334155", "#64748B"),
    "faceit": ("F", "#B45309", "#F59E0B"),
    "spotify": ("S", "#047857", "#34D399"),
}

def _dpr() -> float:
    try:
        scr = QGuiApplication.primaryScreen()
        return max(2.0, float(scr.devicePixelRatio())) if scr else 2.0
    except Exception:
        return 2.0


def _render(svg: str, size: int) -> QPixmap:
    dpr = _dpr()
    pm = QPixmap(int(size * dpr), int(size * dpr))
    pm.setDevicePixelRatio(dpr)
    pm.fill(Qt.GlobalColor.transparent)
    renderer = QSvgRenderer(QByteArray(svg.encode("utf-8")))
    p = QPainter(pm)
    p.setRenderHint(QPainter.RenderHint.Antialiasing)
    renderer.render(p, QRectF(0, 0, size, size))
    p.end()
    return pm


@lru_cache(maxsize=512)
def pixmap(name: str, color: str = "#ECECF5", size: int = 20) -> QPixmap:
    inner = ICONS.get(name)
    if inner is None:
        inner = ICONS["info"]
    svg = ('<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24">' + _G.format(inner) + '</svg>').replace("currentColor", color)
    return _render(svg, size)


def _logo_candidates(service: str) -> list[Path]:
    """Где искать логотип сервиса: сначала папка пользователя (переживает обновления), затем assets/images/logos."""
    from config.settings import app_root, data_dir_path
    folders = (data_dir_path() / "logos", app_root() / "assets" / "images" / "logos")
    return [d / f"{service}{ext}" for d in folders for ext in (".svg", ".png", ".jpg")]


def _load_user_logo(f: Path, size: int) -> QPixmap | None:
    try:
        if f.suffix == ".svg":
            svg = f.read_text(encoding="utf-8")
            if not QSvgRenderer(QByteArray(svg.encode("utf-8"))).isValid():
                return None
            return _render(svg, size)
        pm = QPixmap(str(f))
    except OSError:
        return None
    if pm.isNull():
        return None
    dpr = _dpr()
    out = pm.scaled(int(size * dpr), int(size * dpr), Qt.AspectRatioMode.KeepAspectRatio,
                    Qt.TransformationMode.SmoothTransformation)
    out.setDevicePixelRatio(dpr)
    return out


@lru_cache(maxsize=128)
def service_logo(service: str, size: int = 40) -> QPixmap:
    """Значок сервиса: файл пользователя (папка logos в данных приложения или assets/images/logos) либо нейтральная монограмма.
    Результат кэшируется — после добавления файла перезапустите приложение."""
    for f in _logo_candidates(service):
        if f.is_file():
            pm = _load_user_logo(f, size)
            if pm is not None:
                return pm
    badge = SERVICE_BADGES.get(service)
    if badge is None:
        return pixmap("link", "#8D8DA6", size)
    letter, c1, c2 = badge
    dpr = _dpr()
    pm = QPixmap(int(size * dpr), int(size * dpr))
    pm.setDevicePixelRatio(dpr)
    pm.fill(Qt.GlobalColor.transparent)
    p = QPainter(pm)
    p.setRenderHint(QPainter.RenderHint.Antialiasing)
    grad = QLinearGradient(0, 0, size, size)
    grad.setColorAt(0, QColor(c1))
    grad.setColorAt(1, QColor(c2))
    p.setBrush(grad)
    p.setPen(Qt.PenStyle.NoPen)
    p.drawRoundedRect(QRectF(0, 0, size, size), size * 0.28, size * 0.28)
    f = QFont()
    f.setPixelSize(int(size * 0.5))
    f.setWeight(QFont.Weight.Bold)
    p.setFont(f)
    p.setPen(QColor("#FFFFFF"))
    p.drawText(QRectF(0, 0, size, size), int(Qt.AlignmentFlag.AlignCenter), letter)
    p.end()
    return pm


@lru_cache(maxsize=32)
def _app_logo(size: int, style: str) -> QPixmap:
    return _render(logo.logo_svg(style), size)


def app_logo(size: int = 48, style: str | None = None) -> QPixmap:
    """Логотип приложения (буква V); style — "violet" / "yellow", по умолчанию — вариант из настроек по умолчанию."""
    return _app_logo(size, logo.normalize(style))


def app_icon(style: str | None = None) -> QIcon:
    """Иконка окна и панели задач: логотип нескольких размеров."""
    ic = QIcon()
    for px in (16, 24, 32, 48, 64, 128, 256):
        ic.addPixmap(app_logo(px, style))
    return ic


def icon(name: str, color: str = "#ECECF5", size: int = 20, *, on_color: str | None = None,
         disabled_color: str | None = "#55556A") -> QIcon:
    """QIcon с состояниями: обычное, включённое (checked) и выключенное."""
    ic = QIcon()
    ic.addPixmap(pixmap(name, color, size), QIcon.Mode.Normal, QIcon.State.Off)
    ic.addPixmap(pixmap(name, on_color or color, size), QIcon.Mode.Normal, QIcon.State.On)
    if disabled_color:
        ic.addPixmap(pixmap(name, disabled_color, size), QIcon.Mode.Disabled, QIcon.State.Off)
    return ic


def available() -> list[str]:
    return sorted(ICONS)
