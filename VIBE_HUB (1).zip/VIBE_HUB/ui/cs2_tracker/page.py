"""CS2 Tracker: ручной ввод матчей + матчи из FACEIT, статистика, графики, история."""
from __future__ import annotations

import logging
from datetime import datetime

from PySide6.QtCore import QDateTime, Qt
from PySide6.QtWidgets import (QComboBox, QDateTimeEdit, QGridLayout, QHBoxLayout, QLineEdit, QSpinBox, QVBoxLayout,
                               QWidget)

from modules import stats
from ui.common.base import Card, EmptyState, IconButton, Page, SegmentedControl, StatTile, button, label
from ui.common.charts import ChartWidget
from ui.common.dialogs import FormDialog, confirm, message
from ui.common.tables import ALIGN_C, ALIGN_R, cell, fit_height, make_table
from ui.common.util import fmt_dt
from utils.format import fmt_num, fmt_pct
from utils.i18n import _
from utils.timeutil import parse_iso, period_start, to_iso

log = logging.getLogger("vibehub.tracker")

# подсказки для списка карт (поле редактируемое — можно ввести любую)
KNOWN_MAPS = ["de_mirage", "de_inferno", "de_nuke", "de_overpass", "de_ancient", "de_anubis", "de_dust2", "de_vertigo",
              "de_train"]
RESULTS = [("win", "Победа"), ("loss", "Поражение"), ("draw", "Ничья")]
RESULT_TONE = {"win": "success", "loss": "danger", "draw": "muted"}
SOURCE_LABEL = {"manual": "Вручную", "faceit": "FACEIT"}
TABLE_LIMIT = 200


class MatchDialog(FormDialog):
    def __init__(self, parent, repo, match: dict | None = None):
        super().__init__(parent, _("Редактировать матч") if match else _("Добавить матч"),
                         ok_text=_("Сохранить") if match else _("Добавить"))
        self.repo, self.match = repo, match
        self.dt = QDateTimeEdit(QDateTime.currentDateTime())
        self.dt.setCalendarPopup(True)
        self.dt.setDisplayFormat("dd.MM.yyyy HH:mm")
        self.map = QComboBox()
        self.map.setEditable(True)
        self.map.addItems(sorted(set(KNOWN_MAPS) | set(repo.maps())))
        self.map.setCurrentText("")
        self.result = QComboBox()
        for key, text in RESULTS:
            self.result.addItem(_(text), key)
        self.kills, self.deaths, self.assists = QSpinBox(), QSpinBox(), QSpinBox()
        for sp in (self.kills, self.deaths, self.assists):
            sp.setRange(0, 200)
        self.hs = QSpinBox()
        self.hs.setRange(-1, 100)
        self.hs.setValue(-1)
        self.hs.setSpecialValueText("—")
        self.hs.setSuffix(" %")
        self.score = QLineEdit()
        self.score.setPlaceholderText("13:7")
        self.notes = QLineEdit()
        self.notes.setMaxLength(300)
        rows = [(_("Дата и время"), self.dt), (_("Карта"), self.map), (_("Результат"), self.result),
                (_("Убийства"), self.kills), (_("Смерти"), self.deaths), (_("Ассисты"), self.assists),
                (_("Headshot %"), self.hs), (_("Счёт"), self.score), (_("Заметка"), self.notes)]
        for text, w in rows:
            self.form.addRow(text, w)
        if match:
            self.dt.setDateTime(QDateTime(parse_iso(match["played_at"])))
            self.map.setCurrentText(match["map"] or "")
            self.result.setCurrentIndex(max(0, self.result.findData(match["result"])))
            self.kills.setValue(match["kills"])
            self.deaths.setValue(match["deaths"])
            self.assists.setValue(match["assists"])
            self.hs.setValue(int(match["headshot_pct"]) if match["headshot_pct"] is not None else -1)
            self.score.setText(match["score"] or "")
            self.notes.setText(match["notes"] or "")

    def validate(self) -> str | None:
        if self.dt.dateTime() > QDateTime.currentDateTime().addSecs(300):
            return _("Дата матча не может быть в будущем.")
        if not self.map.currentText().strip():
            return _("Укажите карту.")
        return None

    def apply(self) -> None:
        dt: datetime = self.dt.dateTime().toPython()
        data = dict(map=self.map.currentText().strip(), played_at=to_iso(dt.replace(microsecond=0, tzinfo=None)),
                    result=self.result.currentData(), kills=self.kills.value(), deaths=self.deaths.value(),
                    assists=self.assists.value(), headshot_pct=None if self.hs.value() < 0 else float(self.hs.value()),
                    score=self.score.text().strip() or None, notes=self.notes.text().strip())
        if self.match:
            self.repo.update(self.match["id"], **data)
        else:
            self.repo.add(source="manual", **data)
        self.saved = data


class TrackerPage(Page):
    def __init__(self, ctx, parent=None):
        super().__init__(ctx, parent)
        self._matches: list[dict] = []
        root = QVBoxLayout(self)
        root.setContentsMargins(28, 22, 28, 28)
        root.setSpacing(16)

        head, _col = self.page_header("CS2 Tracker", _("Матчи, добавленные вручную, и матчи из FACEIT"))
        self.btn_sync = button(_("Синхронизировать FACEIT"), icon="refresh", on_click=self._sync_faceit)
        self.btn_add = button(_("Добавить матч"), "primary", "plus", self.add_match)
        head.addWidget(self.btn_sync)
        head.addWidget(self.btn_add)
        root.addLayout(head)

        self.empty = EmptyState(_("Матчей пока нет"), _("Добавьте первый матч вручную или подключите FACEIT — "
                                                         "последние матчи подтянутся автоматически."),
                                icon="crosshair", button_text=_("Добавить матч"), on_click=self.add_match)
        root.addWidget(self.empty)

        self.content = QWidget()
        cl = QVBoxLayout(self.content)
        cl.setContentsMargins(0, 0, 0, 0)
        cl.setSpacing(16)
        root.addWidget(self.content)

        # --- фильтры
        flt = QHBoxLayout()
        flt.setSpacing(10)
        self.period = SegmentedControl([("week", _("7 дней")), ("month", _("30 дней")), ("all", _("Всё время"))], "month")
        self.source = QComboBox()
        for key, text in (("all", _("Все источники")), ("manual", _("Вручную")), ("faceit", "FACEIT")):
            self.source.addItem(text, key)
        self.map_filter = QComboBox()
        self.period.changed.connect(lambda _k: self.refresh())
        self.source.currentIndexChanged.connect(lambda _i: self.refresh())
        self.map_filter.currentIndexChanged.connect(lambda _i: self.refresh())
        flt.addWidget(self.period)
        flt.addWidget(self.source)
        flt.addWidget(self.map_filter)
        flt.addStretch(1)
        cl.addLayout(flt)

        # --- плитки
        tiles = QGridLayout()
        tiles.setSpacing(12)
        self.t_matches, self.t_wr = StatTile(_("Матчей")), StatTile("Win Rate")
        self.t_kd, self.t_kills = StatTile("K/D"), StatTile(_("Убийств за матч"))
        self.t_hs = StatTile(_("Средний HS%"))
        for i, t in enumerate((self.t_matches, self.t_wr, self.t_kd, self.t_kills, self.t_hs)):
            tiles.addWidget(t, 0, i)
            tiles.setColumnStretch(i, 1)
        cl.addLayout(tiles)

        # --- графики
        charts = QHBoxLayout()
        charts.setSpacing(16)
        self.c_kd = ChartWidget(min_height=200, empty_text=_("Недостаточно данных"))
        self.c_wr = ChartWidget(min_height=200, empty_text=_("Недостаточно данных"))
        for title, ch in ((_("Динамика K/D (накопленный)"), self.c_kd), (_("Динамика Win Rate, %"), self.c_wr)):
            card = Card(title)
            card.body.addWidget(ch, 1)
            charts.addWidget(card, 1)
        cl.addLayout(charts)

        # --- по картам
        self.maps_card = Card(_("По картам"), "target")
        self.maps_table = make_table([_("Карта"), _("Матчей"), _("Побед"), "Win Rate", "K/D"])
        self.maps_card.body.addWidget(self.maps_table)
        cl.addWidget(self.maps_card)

        # --- история
        self.hist_card = Card(_("История матчей"), "history")
        self.hist_note = label("", "Muted")
        self.hist_table = make_table([_("Дата"), _("Карта"), _("Результат"), "K / D / A", "K/D", "HS%", _("Счёт"),
                                      _("Источник"), ""], stretch_col=1)
        self.hist_card.body.addWidget(self.hist_table)
        self.hist_card.body.addWidget(self.hist_note)
        cl.addWidget(self.hist_card)

        ctx.bus.matches_changed.connect(self.mark_dirty)
        ctx.bus.accounts_changed.connect(self._update_sync_button)

    # ------------------------------------------------------------------ действия
    def handle_action(self, action: str) -> None:
        if action == "add_match":
            self.add_match()

    def add_match(self) -> None:
        dlg = MatchDialog(self, self.ctx.repos.matches)
        if dlg.exec():
            d = dlg.saved
            self.ctx.log_activity("match", f"{_('Добавлен матч')}: {d['map']} — {_(dict(RESULTS)[d['result']])}")
            self._changed()

    def edit_match(self, match_id: int) -> None:
        m = self.ctx.repos.matches.get(match_id)
        if m is None:
            return
        if MatchDialog(self, self.ctx.repos.matches, m).exec():
            self._changed()

    def delete_match(self, match_id: int) -> None:
        if confirm(self, _("Удалить матч"), _("Удалить этот матч из статистики? Действие нельзя отменить.")):
            self.ctx.repos.matches.delete(match_id)
            self._changed()

    def _changed(self) -> None:
        self.ctx.bus.matches_changed.emit()
        self.ctx.sync_goals()

    def _sync_faceit(self) -> None:
        if not self.ctx.faceit.linked or not self.ctx.faceit.service.has_key():
            message(self, "FACEIT", _("Подключите FACEIT и укажите API Key в разделе «Подключённые аккаунты»."))
            self.ctx.bus.navigate.emit("accounts")
            return
        self.ctx.faceit.refresh(True)

    def _update_sync_button(self) -> None:
        self.btn_sync.setVisible(self.ctx.faceit.linked)

    # ------------------------------------------------------------------ данные
    def _filtered(self) -> list[dict]:
        kind = self.period.current()
        date_from = None if kind == "all" else period_start(kind)
        src = self.source.currentData() or "all"
        mp = self.map_filter.currentData() or None
        return self.ctx.repos.matches.list(date_from=date_from, source=None if src == "all" else src, map_name=mp)

    def refresh(self) -> None:
        self._update_sync_button()
        total = self.ctx.repos.matches.list(limit=1)
        self.empty.setVisible(not total)
        self.content.setVisible(bool(total))
        self.btn_add.setVisible(True)
        if not total:
            return
        # список карт для фильтра
        cur = self.map_filter.currentData()
        self.map_filter.blockSignals(True)
        self.map_filter.clear()
        self.map_filter.addItem(_("Все карты"), "")
        for m in self.ctx.repos.matches.maps():
            self.map_filter.addItem(m, m)
        idx = self.map_filter.findData(cur or "")
        self.map_filter.setCurrentIndex(max(0, idx))
        self.map_filter.blockSignals(False)

        ms = self._filtered()
        self._matches = ms
        s = stats.summarize(ms)
        self.t_matches.set_value(str(s["matches"]), f"{s['wins']} {_('поб.')} / {s['losses']} {_('пор.')}" if s["matches"] else "")
        wr = s["win_rate"]
        self.t_wr.set_value(fmt_pct(wr, 1), tone=None if wr is None else ("success" if wr >= 50 else "danger"))
        self.t_kd.set_value(fmt_num(s["kd"], 2), tone=None if s["kd"] is None else ("success" if s["kd"] >= 1 else "danger"))
        self.t_kills.set_value(fmt_num(s["avg_kills"], 1))
        hs = [m["headshot_pct"] for m in ms if m["headshot_pct"] is not None]
        self.t_hs.set_value(fmt_pct(sum(hs) / len(hs), 0) if hs else "—", "" if hs else _("не указан в матчах"))

        self._fill_charts(ms)
        self._fill_maps(ms)
        self._fill_history(ms)

    def _fill_charts(self, ms: list[dict]) -> None:
        kd = stats.kd_trend(ms)[-80:]
        wr = stats.winrate_trend(ms)[-80:]
        if len(kd) >= 2:
            self.c_kd.plot_lines([{"name": "K/D", "y": [v for _t, v in kd], "color": "accent2", "fmt": "{:.2f}"}],
                                 x_labels=[fmt_dt(t) for t, _v in kd])
        else:
            self.c_kd.show_empty(_("Нужно минимум 2 матча"))
        if len(wr) >= 2:
            self.c_wr.plot_lines([{"name": "Win Rate", "y": [v for _t, v in wr], "color": "success", "fmt": "{:.1f}%"}],
                                 x_labels=[fmt_dt(t) for t, _v in wr], y_range=(0, 100))
        else:
            self.c_wr.show_empty(_("Нужно минимум 2 матча"))

    def _fill_maps(self, ms: list[dict]) -> None:
        rows = stats.per_map(ms)
        t = self.maps_table
        t.setRowCount(len(rows))
        for r, row in enumerate(rows):
            t.setItem(r, 0, cell(row["map"]))
            t.setItem(r, 1, cell(row["matches"], align=ALIGN_R))
            t.setItem(r, 2, cell(row["wins"], align=ALIGN_R))
            wr = row["win_rate"]
            t.setItem(r, 3, cell(fmt_pct(wr, 0), align=ALIGN_R, tone=None if wr is None else ("success" if wr >= 50 else "danger")))
            t.setItem(r, 4, cell(fmt_num(row["kd"], 2), align=ALIGN_R))
        fit_height(t, 12)
        self.maps_card.setVisible(bool(rows))

    def _fill_history(self, ms: list[dict]) -> None:
        t = self.hist_table
        shown = ms[:TABLE_LIMIT]
        t.setRowCount(len(shown))
        for r, m in enumerate(shown):
            t.setItem(r, 0, cell(fmt_dt(m["played_at"], True)))
            t.setItem(r, 1, cell(m["map"] or "—"))
            t.setItem(r, 2, cell(_(dict(RESULTS)[m["result"]]), tone=RESULT_TONE[m["result"]]))
            t.setItem(r, 3, cell(f"{m['kills']} / {m['deaths']} / {m['assists']}", align=ALIGN_C))
            t.setItem(r, 4, cell(fmt_num(stats.kd(m["kills"], m["deaths"]), 2), align=ALIGN_R))
            t.setItem(r, 5, cell(fmt_pct(m["headshot_pct"], 0) if m["headshot_pct"] is not None else "—", align=ALIGN_R))
            t.setItem(r, 6, cell(m["score"] or "—", align=ALIGN_C))
            t.setItem(r, 7, cell(_(SOURCE_LABEL.get(m["source"], m["source"]))))
            if m["source"] == "manual":
                host = QWidget()
                lay = QHBoxLayout(host)
                lay.setContentsMargins(0, 0, 0, 0)
                lay.setSpacing(0)
                lay.addWidget(IconButton("edit", _("Изменить"), size=16, on_click=lambda mid=m["id"]: self.edit_match(mid)))
                lay.addWidget(IconButton("trash", _("Удалить"), size=16, on_click=lambda mid=m["id"]: self.delete_match(mid)))
                t.setCellWidget(r, 8, host)
            else:
                it = cell("", align=Qt.AlignmentFlag.AlignCenter)
                it.setToolTip(_("Матчи FACEIT импортируются автоматически и не редактируются"))
                t.setItem(r, 8, it)
        fit_height(t, TABLE_LIMIT)
        if not shown:
            self.hist_note.setText(_("По выбранным фильтрам матчей нет."))
        elif len(ms) > TABLE_LIMIT:
            self.hist_note.setText(f"{_('Показаны последние')} {TABLE_LIMIT} {_('из')} {len(ms)}")
        else:
            self.hist_note.setText("")
        self.hist_note.setVisible(bool(self.hist_note.text()))

