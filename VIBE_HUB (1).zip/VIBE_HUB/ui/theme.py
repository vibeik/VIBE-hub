"""Дизайн-система: палитры, QSS, доступ к цветам из кастомных виджетов."""
from __future__ import annotations

from PySide6.QtCore import QObject, Signal
from PySide6.QtGui import QColor, QFont

from ui.palettes import DEFAULT_THEME, PALETTES, STATUS, THEME_LABELS
from ui.qss import build_qss, rgba

__all__ = ["PALETTES", "STATUS", "THEME_LABELS", "build_qss", "rgba"]


def qcolor(hex_color: str, alpha: float | None = None) -> QColor:
    c = QColor(hex_color)
    if alpha is not None:
        c.setAlphaF(alpha)
    return c


class ThemeManager(QObject):
    changed = Signal()

    def __init__(self, settings):
        super().__init__()
        self.settings = settings
        self.colors: dict[str, str] = {}
        self.animations = True
        self.glass_mode = "off"          # "off" | "acrylic" | "mica" — задаётся при запуске (main.py), после проверки поддержки
        self.reload(emit=False)

    def reload(self, emit: bool = True) -> None:
        base = dict(PALETTES.get(self.settings.get("theme"), PALETTES[DEFAULT_THEME]))
        for key in ("accent", "accent2"):
            val = self.settings.get(key)
            if val and QColor(val).isValid():
                base[key] = val
        base.update(STATUS)
        self.colors = base
        self.animations = bool(self.settings.get("animations"))
        if emit:
            self.changed.emit()

    def color(self, name: str, alpha: float | None = None) -> QColor:
        return qcolor(self.colors.get(name, name), alpha)

    def glass_alpha(self) -> float | None:
        """Непрозрачность фона окна в режиме стекла (None — стекло выключено). Не ниже 0.30, чтобы окно не становилось «пустым»."""
        if self.glass_mode == "off":
            return None
        t = int(self.settings.get("glass_transparency") or 30)
        return 1.0 - max(10, min(70, t)) / 100.0

    def apply(self, app) -> None:
        font = QFont("Segoe UI Variable Text")
        font.setStyleHint(QFont.StyleHint.SansSerif)
        font.setPointSizeF(9.5)
        app.setFont(font)
        app.setStyleSheet(build_qss(self.colors, self.glass_alpha()))


_theme: ThemeManager | None = None


def init(settings) -> ThemeManager:
    global _theme
    _theme = ThemeManager(settings)
    return _theme


def get() -> ThemeManager:
    if _theme is None:
        raise RuntimeError("theme.init() не вызван")
    return _theme


def color(name: str, alpha: float | None = None) -> QColor:
    return get().color(name, alpha)
