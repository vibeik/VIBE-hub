"""Файлы логотипа: assets/icons/vibehub.ico (фиолетовый, используется сборкой), vibehub-yellow.ico и PNG для README.

    python tools/make_logo.py

Рисунок берётся из utils/logo.py (один источник), растеризация — через PySide6 (QtSvg), упаковка .ico — без внешних библиотек.
Готовые файлы уже лежат в assets/; скрипт нужен только если вы меняете рисунок логотипа.
"""
from __future__ import annotations

import struct
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))

from utils import logo  # noqa: E402

ICO_SIZES = (16, 24, 32, 48, 64, 128, 256)
FILES = {"violet": ("vibehub.ico", "logo.png"), "yellow": ("vibehub-yellow.ico", "logo-yellow.png")}


def pack_ico(pngs: dict[int, bytes]) -> bytes:
    """Собирает .ico из PNG разных размеров (формат с PNG внутри поддерживается Windows с Vista, PyInstaller и Inno Setup)."""
    sizes = sorted(pngs)
    head = struct.pack("<HHH", 0, 1, len(sizes))
    offset = 6 + 16 * len(sizes)
    entries, blobs = b"", b""
    for s in sizes:
        data = pngs[s]
        dim = 0 if s >= 256 else s       # 0 в заголовке означает 256
        entries += struct.pack("<BBBBHHII", dim, dim, 0, 0, 1, 32, len(data), offset)
        blobs += data
        offset += len(data)
    return head + entries + blobs


def render_png(style: str, size: int) -> bytes:
    from PySide6.QtCore import QBuffer, QByteArray, QIODevice, QRectF
    from PySide6.QtGui import QGuiApplication, QImage, QPainter
    from PySide6.QtSvg import QSvgRenderer

    app = QGuiApplication.instance() or QGuiApplication([])
    del app
    img = QImage(size, size, QImage.Format.Format_ARGB32)
    img.fill(0)
    r = QSvgRenderer(QByteArray(logo.logo_svg(style).encode("utf-8")))
    p = QPainter(img)
    p.setRenderHint(QPainter.RenderHint.Antialiasing)
    r.render(p, QRectF(0, 0, size, size))
    p.end()
    buf = QBuffer()
    buf.open(QIODevice.OpenModeFlag.WriteOnly)
    img.save(buf, "PNG")
    return bytes(buf.data())


def main() -> None:
    icons, images = ROOT / "assets" / "icons", ROOT / "assets" / "images"
    icons.mkdir(parents=True, exist_ok=True)
    images.mkdir(parents=True, exist_ok=True)
    for style, (ico_name, png_name) in FILES.items():
        pngs = {s: render_png(style, s) for s in ICO_SIZES}
        (icons / ico_name).write_bytes(pack_ico(pngs))
        (images / png_name).write_bytes(pngs[256])
        print("OK:", ico_name, png_name)


if __name__ == "__main__":
    main()
