"""Генерация PNG-стрелок для QSS (chevron-down.png, check.png).

Запуск (нужен Pillow):  python tools/make_assets.py
Логотип приложения (.ico/.png) делает отдельный скрипт tools/make_logo.py.
Результат уже лежит в assets/ — скрипт нужен, только если хотите изменить стрелки.
"""
from __future__ import annotations

from pathlib import Path

from PIL import Image, ImageDraw

ROOT = Path(__file__).resolve().parent.parent
ICONS = ROOT / "assets" / "icons"
IMAGES = ROOT / "assets" / "images"


def _thick_polyline(draw: ImageDraw.ImageDraw, pts, width: int, fill) -> None:
    draw.line(pts, fill=fill, width=width, joint="curve")
    r = width / 2
    for x, y in (pts[0], pts[-1]):
        draw.ellipse((x - r, y - r, x + r, y + r), fill=fill)


def make_chevron(color=(141, 141, 166), size: int = 24) -> Image.Image:
    ss = 8
    big = size * ss
    img = Image.new("RGBA", (big, big), (0, 0, 0, 0))
    d = ImageDraw.Draw(img)
    pts = [(big * 0.27, big * 0.38), (big * 0.5, big * 0.62), (big * 0.73, big * 0.38)]
    _thick_polyline(d, pts, int(big * 0.09), color + (255,))
    return img.resize((size, size), Image.LANCZOS)


def make_check(size: int = 24) -> Image.Image:
    ss = 8
    big = size * ss
    img = Image.new("RGBA", (big, big), (0, 0, 0, 0))
    d = ImageDraw.Draw(img)
    pts = [(big * 0.24, big * 0.52), (big * 0.43, big * 0.70), (big * 0.77, big * 0.32)]
    _thick_polyline(d, pts, int(big * 0.11), (255, 255, 255, 255))
    return img.resize((size, size), Image.LANCZOS)


def main() -> None:
    ICONS.mkdir(parents=True, exist_ok=True)
    IMAGES.mkdir(parents=True, exist_ok=True)
    make_chevron().save(ICONS / "chevron-down.png")
    make_check().save(ICONS / "check.png")
    print("OK:", sorted(p.name for p in list(ICONS.iterdir()) + list(IMAGES.iterdir())))


if __name__ == "__main__":
    main()
