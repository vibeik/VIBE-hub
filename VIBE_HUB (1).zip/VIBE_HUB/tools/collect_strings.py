"""Собирает русские строки интерфейса из исходников (для assets/lang/en.json и теста покрытия перевода).

    python tools/collect_strings.py          # печатает ключи, которых нет в en.json
"""
from __future__ import annotations

import ast
import json
import re
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
CYR = re.compile("[А-Яа-яЁё]")
SOURCES = ("ui", "modules", "utils")

# Строки, которым перевод не нужен: названия языков, русские дни/месяцы (в main_window.py есть свой английский список)
# и текст внутренней ошибки разработчика.
NO_TRANSLATION = {
    "Русский", "theme.init() не вызван",
    "пн", "вт", "ср", "чт", "пт", "сб", "вс",
    "января", "февраля", "марта", "апреля", "мая", "июня", "июля", "августа", "сентября", "октября", "ноября", "декабря",
}
# Фрагменты, которые переводятся внутри f-строк через _('...') и потому не находятся автоматически
EXTRA_KEYS = {"мин", "назад", "ГГц", "ГБ", "ч",
              # main.py (вне просматриваемых папок)
              "База данных восстановлена", "Предыдущий сеанс завершился некорректно",
              "Проверка локальной базы данных пройдена, данные на месте."}

_LOGGER_NAMES = {"log", "logging", "logger"}
_LOG_METHODS = {"exception", "warning", "error", "info", "debug", "critical"}


def collect() -> dict[str, str]:
    """{русская строка: файл}. Пропускает docstring'и, сообщения журнала и записи активности (они хранятся в БД)."""
    out: dict[str, str] = {}
    files: list[Path] = []
    for d in SOURCES:
        files += sorted((ROOT / d).rglob("*.py"))
    for p in files:
        rel = str(p.relative_to(ROOT))
        tree = ast.parse(p.read_text(encoding="utf-8"))
        parent: dict[ast.AST, ast.AST] = {}
        for n in ast.walk(tree):
            for c in ast.iter_child_nodes(n):
                parent[c] = n
        docs = set()
        for n in ast.walk(tree):
            if isinstance(n, (ast.Module, ast.ClassDef, ast.FunctionDef, ast.AsyncFunctionDef)) and n.body \
                    and isinstance(n.body[0], ast.Expr) and isinstance(n.body[0].value, ast.Constant):
                docs.add(n.body[0].value)
        for n in ast.walk(tree):
            if not (isinstance(n, ast.Constant) and isinstance(n.value, str) and CYR.search(n.value)) or n in docs:
                continue
            anc: list[ast.AST] = []
            x: ast.AST = n
            while x in parent:
                x = parent[x]
                anc.append(x)
            if any(isinstance(a, ast.JoinedStr) for a in anc):
                continue
            if any(isinstance(a, ast.Call) and isinstance(a.func, ast.Attribute) and a.func.attr in _LOG_METHODS
                   and (isinstance(a.func.value, ast.Call)
                        or (isinstance(a.func.value, ast.Name) and a.func.value.id in _LOGGER_NAMES))
                   for a in anc):
                continue
            if any(isinstance(a, ast.Call) and isinstance(a.func, ast.Attribute) and a.func.attr in ("add", "log_activity")
                   and "activity" in ast.unparse(a.func) for a in anc):
                continue
            if any(isinstance(a, ast.keyword) and a.arg == "note" for a in anc):
                continue
            out.setdefault(n.value, rel)
    return out


def load_en() -> dict[str, str]:
    return json.loads((ROOT / "assets" / "lang" / "en.json").read_text(encoding="utf-8"))


def missing() -> list[str]:
    en = load_en()
    need = (set(collect()) | EXTRA_KEYS) - NO_TRANSLATION
    return sorted(k for k in need if not en.get(k))


if __name__ == "__main__":
    miss = missing()
    for k in miss:
        print(repr(k))
    print(f"Без перевода: {len(miss)}")
