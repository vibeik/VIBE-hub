"""Учёт задержек интерфейса (без Qt): накопление, сводка и текст отчёта.

Идея: таймер Qt, который должен срабатывать каждые 50 мс, срабатывает позже, если цикл событий занят
(отрисовка, тяжёлая функция в главном потоке). Опоздание таймера и есть длительность «подвисания».
Контекст («page:steam», «switch:faceit», «theme») подсказывает, что делал пользователь в этот момент.
"""
from __future__ import annotations

import time
from collections import deque
from dataclasses import dataclass, field

SLOW_MS = 50.0        # опоздание ≥ 50 мс: интерфейс пропустил несколько кадров
STALL_MS = 120.0      # ≥ 120 мс: заметное подвисание, попадает в журнал отдельной строкой
HITCH_MS = 250.0      # ≥ 250 мс: «тормоз», который чувствуется явно
IGNORE_MS = 5000.0    # опоздание больше — сон/гибернация ноутбука, а не подвисание программы
WORST_KEEP = 10
EVENTS_KEEP = 60


def percentile(values: list[float], q: float) -> float:
    """q в диапазоне 0..100; для пустого списка — 0."""
    if not values:
        return 0.0
    vals = sorted(values)
    idx = min(len(vals) - 1, max(0, int(round(q / 100.0 * (len(vals) - 1)))))
    return vals[idx]


@dataclass
class ContextStats:
    ticks: int = 0
    slow: int = 0
    stalls: int = 0
    hitches: int = 0
    worst_ms: float = 0.0
    late_sum_ms: float = 0.0

    def add(self, late_ms: float) -> None:
        self.ticks += 1
        self.late_sum_ms += late_ms
        if late_ms >= SLOW_MS:
            self.slow += 1
        if late_ms >= STALL_MS:
            self.stalls += 1
        if late_ms >= HITCH_MS:
            self.hitches += 1
        self.worst_ms = max(self.worst_ms, late_ms)


@dataclass
class PerfStats:
    started: float = field(default_factory=time.monotonic)
    total: ContextStats = field(default_factory=ContextStats)
    by_context: dict[str, ContextStats] = field(default_factory=dict)
    worst: list[tuple[float, str, float]] = field(default_factory=list)       # (опоздание мс, контекст, секунд от старта)
    events: deque = field(default_factory=lambda: deque(maxlen=EVENTS_KEEP))  # (секунд от старта, имя, мс)
    env: dict[str, str] = field(default_factory=dict)
    _samples: deque = field(default_factory=lambda: deque(maxlen=20000))       # последние опоздания для перцентилей

    def record(self, context: str, late_ms: float) -> None:
        """Одно срабатывание таймера. Отрицательные и «сонные» значения отбрасываются."""
        if late_ms < 0:
            late_ms = 0.0
        if late_ms >= IGNORE_MS:
            return
        self.total.add(late_ms)
        self.by_context.setdefault(context, ContextStats()).add(late_ms)
        self._samples.append(late_ms)
        if late_ms >= STALL_MS:
            self.worst.append((late_ms, context, time.monotonic() - self.started))
            self.worst.sort(key=lambda r: -r[0])
            del self.worst[WORST_KEEP:]

    def event(self, name: str, ms: float) -> None:
        """Длительность разовой операции (создание страницы, применение темы...)."""
        self.events.append((time.monotonic() - self.started, name, ms))

    # ------------------------------------------------------------------ отчёт
    def report(self) -> str:
        up = time.monotonic() - self.started
        t = self.total
        samples = list(self._samples)
        lines = ["VIBE HUB performance report", f"uptime: {up / 60:.1f} min"]
        for k in sorted(self.env):
            lines.append(f"{k}: {self.env[k]}")
        lines.append("")
        lines.append("event loop lateness (timer 50 ms; the larger, the worse the UI froze)")
        if not t.ticks:
            lines.append("  no samples yet")
        else:
            pct = lambda n: f"{100.0 * n / t.ticks:.1f}%"  # noqa: E731
            lines.append(f"  samples {t.ticks}, avg {t.late_sum_ms / t.ticks:.1f} ms, p95 {percentile(samples, 95):.0f} ms, "
                         f"p99 {percentile(samples, 99):.0f} ms, worst {t.worst_ms:.0f} ms")
            lines.append(f"  >= {SLOW_MS:.0f} ms: {t.slow} ({pct(t.slow)});  >= {STALL_MS:.0f} ms: {t.stalls} ({pct(t.stalls)});  "
                         f">= {HITCH_MS:.0f} ms: {t.hitches}")
        if self.by_context:
            lines.append("")
            lines.append("by what was on screen (worst first)")
            rows = sorted(self.by_context.items(), key=lambda kv: -kv[1].worst_ms)
            for name, c in rows[:14]:
                lines.append(f"  {name:<22} samples {c.ticks:>6}  >=50ms {c.slow:>4}  >=120ms {c.stalls:>3}  worst {c.worst_ms:>5.0f} ms")
        if self.worst:
            lines.append("")
            lines.append("worst freezes")
            for ms, ctx, at in self.worst:
                lines.append(f"  {ms:>5.0f} ms  {ctx:<22} at +{at / 60:.1f} min")
        if self.events:
            lines.append("")
            lines.append("one-off operations (ms)")
            for at, name, ms in list(self.events)[-25:]:
                lines.append(f"  +{at:>7.1f}s  {name:<34} {ms:>7.1f}")
        return "\n".join(lines)
