"""Работа с датами. В БД время хранится как локальная ISO-строка 'YYYY-MM-DD HH:MM:SS'."""
from __future__ import annotations

from datetime import date, datetime, timedelta

from utils.i18n import _

FMT = "%Y-%m-%d %H:%M:%S"


def now() -> datetime:
    return datetime.now().replace(microsecond=0)


def now_iso() -> str:
    return now().strftime(FMT)


def to_iso(dt: datetime) -> str:
    return dt.strftime(FMT)


def parse_iso(s: str) -> datetime:
    s = s.strip().replace("T", " ")
    for fmt in (FMT, "%Y-%m-%d %H:%M", "%Y-%m-%d"):
        try:
            return datetime.strptime(s, fmt)
        except ValueError:
            continue
    raise ValueError(f"Неверный формат даты: {s!r}")


def from_epoch_ms(ms: int | float) -> datetime:
    return datetime.fromtimestamp(float(ms) / 1000.0).replace(microsecond=0)


def from_epoch_s(sec: int | float) -> datetime:
    return datetime.fromtimestamp(float(sec)).replace(microsecond=0)


def day_start(d: date | datetime) -> datetime:
    return datetime(d.year, d.month, d.day)


def last_n_days(n: int, today: date | None = None) -> list[date]:
    """n дат, заканчивая сегодняшней, по возрастанию."""
    t = today or date.today()
    return [t - timedelta(days=i) for i in range(n - 1, -1, -1)]


def period_start(kind: str, today: date | None = None) -> datetime:
    """'week' — последние 7 дней (включая сегодня), 'month' — последние 30 дней."""
    t = today or date.today()
    days = {"week": 7, "month": 30}.get(kind)
    if days is None:
        raise ValueError(kind)
    return day_start(t - timedelta(days=days - 1))


def human_ago(iso: str | None, ref: datetime | None = None) -> str:
    if not iso:
        return _("никогда")
    try:
        dt = parse_iso(iso)
        delta = (ref or datetime.now()) - dt
        sec = int(delta.total_seconds())
        if sec < 60:
            return _("только что")
        if sec < 3600:
            return f"{sec // 60} {_('мин')} {_('назад')}"
        if sec < 86400:
            return f"{sec // 3600} {_('ч')} {_('назад')}"
        return dt.strftime("%d.%m.%Y %H:%M")
    except ValueError:
        return iso
