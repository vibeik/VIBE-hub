"""Форматирование чисел и размеров для интерфейса."""
from __future__ import annotations

from utils.i18n import _


def fmt_bytes(n: float | int | None) -> str:
    if n is None:
        return "—"
    n = float(n)
    units = ("Б", "КБ", "МБ", "ГБ", "ТБ")
    for i, unit in enumerate(units):
        if abs(n) < 1024 or i == len(units) - 1:
            if i == 0:
                return f"{n:.0f} {_(unit)}"
            return f"{n:.1f} {_(unit)}"
        n /= 1024
    return f"{n:.1f} {_('ТБ')}"


def fmt_rate(bps: float | None) -> str:
    if bps is None:
        return "—"
    return fmt_bytes(bps) + _("/с")


def fmt_pct(v: float | None, digits: int = 0) -> str:
    if v is None:
        return "—"
    return f"{v:.{digits}f}%"


def fmt_num(v: float | int | None, digits: int = 2) -> str:
    if v is None:
        return "—"
    if float(v).is_integer():
        return str(int(v))
    return f"{v:.{digits}f}"


def fmt_minutes(minutes: int | None) -> str:
    """Минуты Steam -> '123 ч' / '45 мин'."""
    if not minutes:
        return "0 " + _("ч")
    if minutes < 60:
        return f"{minutes} {_('мин')}"
    return f"{minutes / 60:.1f}".rstrip("0").rstrip(".") + " " + _("ч")


def fmt_ms(ms: int | float | None) -> str:
    if not ms or ms < 0:
        return "0:00"
    s = int(ms // 1000)
    h, rem = divmod(s, 3600)
    m, sec = divmod(rem, 60)
    if h:
        return f"{h}:{m:02d}:{sec:02d}"
    return f"{m}:{sec:02d}"


def fmt_signed(v: float | None, digits: int = 0) -> str:
    if v is None:
        return "—"
    return f"{v:+.{digits}f}"
