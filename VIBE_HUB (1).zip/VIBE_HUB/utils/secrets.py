"""Безопасное хранение секретов.

Используется библиотека `keyring`; на Windows она работает поверх Windows Credential Manager.
Если keyring недоступен или не имеет рабочего бэкенда, секреты НЕ пишутся на диск —
они живут только в памяти до закрытия приложения, а пользователь видит предупреждение.
"""
from __future__ import annotations

import logging
import threading
from utils.i18n import _

log = logging.getLogger("vibehub.secrets")

SERVICE = "VibeHub"

# Имена секретов
STEAM_API_KEY = "steam_api_key"
FACEIT_API_KEY = "faceit_api_key"
SPOTIFY_ACCESS = "spotify_access_token"
SPOTIFY_REFRESH = "spotify_refresh_token"
SPOTIFY_EXPIRES = "spotify_expires_at"


class SecretStore:
    def __init__(self, service: str = SERVICE, backend=None):
        self._service = service
        self._mem: dict[str, str] = {}
        self._lock = threading.RLock()
        self._kr = backend
        self.persistent = False
        self.problem: str | None = None
        if backend is None:
            try:
                import keyring  # type: ignore
                from keyring.backends.fail import Keyring as FailKeyring  # type: ignore

                kr_backend = keyring.get_keyring()
                if isinstance(kr_backend, FailKeyring):
                    raise RuntimeError(_("нет рабочего бэкенда keyring"))
                self._kr = keyring
                self.persistent = True
            except Exception as exc:
                self.problem = f"Защищённое хранилище недоступно ({exc}). Ключи будут храниться только в памяти."
                log.warning(self.problem)
        else:
            self.persistent = True

    def get(self, name: str) -> str | None:
        with self._lock:
            if name in self._mem:
                return self._mem[name]
            if self._kr is not None:
                try:
                    return self._kr.get_password(self._service, name)
                except Exception as exc:
                    log.error("Чтение секрета %s не удалось: %s", name, type(exc).__name__)
            return None

    def set(self, name: str, value: str) -> None:
        with self._lock:
            if self._kr is not None:
                try:
                    self._kr.set_password(self._service, name, value)
                    self._mem.pop(name, None)
                    return
                except Exception as exc:
                    log.error("Запись секрета %s не удалась: %s", name, type(exc).__name__)
                    self.problem = _("Не удалось записать в Credential Manager — ключ сохранён только в памяти.")
            self._mem[name] = value

    def delete(self, name: str) -> None:
        with self._lock:
            self._mem.pop(name, None)
            if self._kr is not None:
                try:
                    self._kr.delete_password(self._service, name)
                except Exception as exc:
                    # PasswordDeleteError, если записи нет — это нормально
                    log.debug("Удаление секрета %s: %s", name, type(exc).__name__)

    def delete_many(self, names) -> None:
        for n in names:
            self.delete(n)
