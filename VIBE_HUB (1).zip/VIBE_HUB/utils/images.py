"""Дисковый кэш изображений (аватары, обложки). Без Qt — возвращает путь к файлу."""
from __future__ import annotations

import hashlib
import logging
from pathlib import Path

from api.http import ApiError, HttpClient

log = logging.getLogger("vibehub.images")
_http: HttpClient | None = None


def cached_image(url: str | None, cache_dir: Path, max_age_days: int = 14) -> Path | None:
    """Скачивает картинку (если нет в кэше). None — не удалось (без исключений наружу)."""
    global _http
    if not url or not url.lower().startswith("https://"):
        return None
    cache_dir.mkdir(parents=True, exist_ok=True)
    path = cache_dir / (hashlib.sha1(url.encode()).hexdigest() + ".img")
    try:
        if path.exists():
            import time
            if time.time() - path.stat().st_mtime < max_age_days * 86400:
                return path
        if _http is None:
            _http = HttpClient()
        data = _http.download(url)
        tmp = path.with_suffix(".tmp")
        tmp.write_bytes(data)
        tmp.replace(path)
        return path
    except ApiError as exc:
        log.debug("Картинка не загружена: %s", exc)
    except OSError:
        log.debug("Ошибка кэша изображений", exc_info=True)
    return path if path.exists() else None
