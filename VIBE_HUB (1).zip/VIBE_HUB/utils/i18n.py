"""Локализация. Исходные строки интерфейса — русские; для английского используется
словарь assets/lang/en.json (ключ — русская строка). Нет перевода — показывается оригинал.
Язык применяется при следующем запуске приложения."""
from __future__ import annotations

import json
import logging
from pathlib import Path

log = logging.getLogger("vibehub.i18n")

_lang = "ru"
_table: dict[str, str] = {}


def set_language(lang: str, lang_dir: Path | None = None) -> None:
    global _lang, _table
    _lang = lang if lang in ("ru", "en") else "ru"
    _table = {}
    if _lang == "ru":
        return
    if lang_dir is None:
        from config.settings import app_root
        lang_dir = app_root() / "assets" / "lang"
    f = lang_dir / f"{_lang}.json"
    try:
        _table = json.loads(f.read_text(encoding="utf-8"))
    except Exception as exc:
        log.warning("Не удалось загрузить перевод %s: %s", f, exc)


def current() -> str:
    return _lang


def _(text: str) -> str:
    return _table.get(text, text)
