"""Логотип VIBE HUB: буква V на чёрной плитке, два цветовых варианта.

Единственный источник рисунка: из него строятся значок в приложении, иконка окна и файлы .ico/.png
(см. tools/make_logo.py). Модуль не зависит от Qt.
"""
from __future__ import annotations

# ключ -> (светлый верх, основной, тёмный низ, цвет рамки)
STYLES: dict[str, tuple[str, str, str, str]] = {
    "violet": ("#D8CCFF", "#8B5CF6", "#7C3AED", "#8B5CF6"),
    "yellow": ("#FFF08A", "#FACC15", "#EAB308", "#FACC15"),
}
DEFAULT = "violet"


def normalize(style: object) -> str:
    """Неизвестное значение из файла настроек превращается в вариант по умолчанию."""
    return style if isinstance(style, str) and style in STYLES else DEFAULT


def logo_svg(style: object = DEFAULT) -> str:
    hi, mid, lo, rim = STYLES[normalize(style)]
    return (
        '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 64 64"><defs>'
        '<linearGradient id="v" x1="0" y1="0" x2="0" y2="1">'
        f'<stop offset="0" stop-color="{hi}"/><stop offset=".55" stop-color="{mid}"/><stop offset="1" stop-color="{lo}"/></linearGradient>'
        '<linearGradient id="t" x1="0" y1="0" x2="1" y2="1">'
        '<stop offset="0" stop-color="#1C1C27"/><stop offset="1" stop-color="#06060A"/></linearGradient></defs>'
        '<rect width="64" height="64" rx="15" fill="url(#t)"/>'
        f'<rect x="1" y="1" width="62" height="62" rx="14" fill="none" stroke="{rim}" stroke-opacity=".45" stroke-width="1.6"/>'
        '<path d="M11 18H24.5L32 38L39.5 14H53L37 50H27Z" fill="url(#v)"/>'
        '<path d="M32 38L39.5 14H53L37 50H32Z" fill="#000" fill-opacity=".28"/></svg>'
    )
