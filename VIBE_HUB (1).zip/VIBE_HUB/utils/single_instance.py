"""Один экземпляр приложения: QLockFile + локальный сокет для «поднятия» уже запущенного окна."""
from __future__ import annotations

import getpass
import logging
from pathlib import Path
from typing import Callable

from PySide6.QtCore import QLockFile
from PySide6.QtNetwork import QLocalServer, QLocalSocket

log = logging.getLogger(__name__)


class SingleInstance:
    def __init__(self, data_dir: Path):
        self._lock = QLockFile(str(data_dir / "vibehub.lock"))
        self._lock.setStaleLockTime(15000)
        try:
            user = getpass.getuser()
        except Exception:  # noqa: BLE001
            user = "user"
        self._name = f"VibeHub-{user}"
        self._server: QLocalServer | None = None

    def acquire(self) -> bool:
        return bool(self._lock.tryLock(150))

    def release(self) -> None:
        if self._server is not None:
            self._server.close()
        self._lock.unlock()

    def notify_existing(self) -> bool:
        """Просит уже запущенный экземпляр показать окно."""
        sock = QLocalSocket()
        sock.connectToServer(self._name)
        if not sock.waitForConnected(700):
            return False
        sock.write(b"show")
        sock.flush()
        sock.waitForBytesWritten(500)
        sock.disconnectFromServer()
        return True

    def listen(self, on_show: Callable[[], None]) -> None:
        QLocalServer.removeServer(self._name)
        server = QLocalServer()
        if not server.listen(self._name):
            log.warning("Cannot listen on local server %s", self._name)
            return

        def _on_connection() -> None:
            conn = server.nextPendingConnection()
            if conn is not None:
                conn.waitForReadyRead(200)
                conn.readAll()
                conn.disconnectFromServer()
            on_show()

        server.newConnection.connect(_on_connection)
        self._server = server
