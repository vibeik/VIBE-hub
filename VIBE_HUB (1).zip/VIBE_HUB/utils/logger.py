"""Логирование с маскированием секретов (токены, ключи не попадают в лог)."""
from __future__ import annotations

import logging
import re
import sys
import threading
from logging.handlers import RotatingFileHandler

from config.settings import log_dir

_PATTERNS = [
    # ?key=XXXX, &access_token=XXXX, client_secret=XXXX ...
    (re.compile(r"(?i)((?:key|token|access_token|refresh_token|client_secret|code|code_verifier|api_key)=)([^&\s'\"]+)"), r"\1***"),
    # Authorization: Bearer XXXX / Basic XXXX
    (re.compile(r"(?i)(bearer|basic)\s+[A-Za-z0-9._\-~+/=]{8,}"), r"\1 ***"),
    # "access_token": "XXXX"
    (re.compile(r"(?i)(\"(?:access_token|refresh_token|api_key|key)\"\s*:\s*\")([^\"]+)(\")"), r"\1***\3"),
]


def redact(text: str) -> str:
    for rx, repl in _PATTERNS:
        text = rx.sub(repl, text)
    return text


class RedactingFilter(logging.Filter):
    def filter(self, record: logging.LogRecord) -> bool:
        try:
            record.msg = redact(record.getMessage())
            record.args = ()
        except Exception:
            pass
        return True


_configured = False


def setup_logging(debug: bool = False) -> None:
    global _configured
    if _configured:
        return
    _configured = True
    root = logging.getLogger()
    root.setLevel(logging.DEBUG if debug else logging.INFO)
    fmt = logging.Formatter("%(asctime)s %(levelname)-7s %(name)s: %(message)s")

    fh = RotatingFileHandler(log_dir() / "vibehub.log", maxBytes=1_000_000, backupCount=3, encoding="utf-8")
    fh.setFormatter(fmt)
    fh.addFilter(RedactingFilter())
    root.addHandler(fh)

    if sys.stderr is not None:
        sh = logging.StreamHandler(sys.stderr)
        sh.setFormatter(fmt)
        sh.addFilter(RedactingFilter())
        root.addHandler(sh)

    log = logging.getLogger("vibehub")

    def _excepthook(exc_type, exc, tb):
        log.critical("Необработанное исключение", exc_info=(exc_type, exc, tb))

    def _thread_hook(args):
        log.critical("Необработанное исключение в потоке %s", args.thread.name if args.thread else "?",
                     exc_info=(args.exc_type, args.exc_value, args.exc_traceback))

    sys.excepthook = _excepthook
    threading.excepthook = _thread_hook
    # requests/urllib3 в DEBUG пишут полные URL — оставляем на INFO+
    logging.getLogger("urllib3").setLevel(logging.WARNING)
