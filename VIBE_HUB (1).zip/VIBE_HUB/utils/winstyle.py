"""Оформление окна в Windows 10/11 через DWM: тёмный заголовок, скруглённые углы и эффект «стекла» (Acrylic / Mica).
На других ОС и в старых Windows — ничего не делает."""
from __future__ import annotations

import logging
import sys

log = logging.getLogger(__name__)

DWMWA_USE_IMMERSIVE_DARK_MODE = 20
DWMWA_WINDOW_CORNER_PREFERENCE = 33   # Windows 11
DWMWA_CAPTION_COLOR = 35              # Windows 11 (build 22000+)
DWMWA_TEXT_COLOR = 36
DWMWA_SYSTEMBACKDROP_TYPE = 38        # Windows 11 22H2 (build 22621+)
DWMWA_MICA_EFFECT = 1029              # Windows 11 до 22H2 (build 22000–22620)
DWMWCP_ROUND = 2
DWMSBT_MAINWINDOW = 2                 # Mica
DWMSBT_TRANSIENTWINDOW = 3            # Acrylic (размытие того, что за окном)
COLOR_DEFAULT = 0xFFFFFFFF

BUILD_WIN11 = 22000
BUILD_BACKDROP_TYPE = 22621

GLASS_MODES = ("acrylic", "mica", "off")


def _colorref(hex_color: str) -> int:
    h = hex_color.lstrip("#")
    r, g, b = int(h[0:2], 16), int(h[2:4], 16), int(h[4:6], 16)
    return (b << 16) | (g << 8) | r


def windows_build() -> int:
    """Номер сборки Windows (0 — не Windows)."""
    if sys.platform != "win32":
        return 0
    try:
        return int(sys.getwindowsversion().build)  # type: ignore[attr-defined]
    except Exception:  # noqa: BLE001
        return 0


def effective_glass_mode(requested: object, build: int | None = None) -> str:
    """Какой режим стекла реально доступен: Acrylic — с Windows 11 22H2, Mica — с Windows 11, иначе стекла нет."""
    build = windows_build() if build is None else build
    if requested not in ("acrylic", "mica") or build < BUILD_WIN11:
        return "off"
    if requested == "acrylic" and build < BUILD_BACKDROP_TYPE:
        return "mica"
    return str(requested)


def _dwm_set(hwnd: int, attr: int, value: int) -> int:
    import ctypes
    from ctypes import wintypes
    v = ctypes.c_int(value) if value < 0x80000000 else ctypes.c_uint(value)
    return int(ctypes.windll.dwmapi.DwmSetWindowAttribute(  # type: ignore[attr-defined]
        wintypes.HWND(hwnd), ctypes.c_uint(attr), ctypes.byref(v), ctypes.sizeof(v)))


def apply_dark_titlebar(hwnd: int, caption: str | None = "#0B0B12", text: str | None = "#E7E7F0") -> None:
    """Тёмный заголовок; caption=None — оставить системный цвет (нужно при стекле, чтобы заголовок просвечивал)."""
    if sys.platform != "win32" or not hwnd:
        return
    try:
        _dwm_set(hwnd, DWMWA_USE_IMMERSIVE_DARK_MODE, 1)
        if build_ok(BUILD_WIN11):
            _dwm_set(hwnd, DWMWA_CAPTION_COLOR, COLOR_DEFAULT if caption is None else _colorref(caption))
            _dwm_set(hwnd, DWMWA_TEXT_COLOR, COLOR_DEFAULT if text is None else _colorref(text))
            _dwm_set(hwnd, DWMWA_WINDOW_CORNER_PREFERENCE, DWMWCP_ROUND)
    except Exception:  # noqa: BLE001 — косметика, не должна ронять приложение
        log.debug("Dark titlebar not applied", exc_info=True)


def build_ok(minimum: int) -> bool:
    return windows_build() >= minimum


def apply_glass(hwnd: int, mode: str) -> bool:
    """Включает Acrylic / Mica за клиентской областью окна. True — если Windows приняла настройку."""
    mode = effective_glass_mode(mode)
    if mode == "off" or not hwnd:
        return False
    try:
        import ctypes
        from ctypes import wintypes

        class MARGINS(ctypes.Structure):
            _fields_ = [("l", ctypes.c_int), ("r", ctypes.c_int), ("t", ctypes.c_int), ("b", ctypes.c_int)]

        margins = MARGINS(-1, -1, -1, -1)           # «лист стекла» на всё окно
        ctypes.windll.dwmapi.DwmExtendFrameIntoClientArea(wintypes.HWND(hwnd), ctypes.byref(margins))  # type: ignore[attr-defined]
        if windows_build() >= BUILD_BACKDROP_TYPE:
            res = _dwm_set(hwnd, DWMWA_SYSTEMBACKDROP_TYPE, DWMSBT_TRANSIENTWINDOW if mode == "acrylic" else DWMSBT_MAINWINDOW)
        else:
            res = _dwm_set(hwnd, DWMWA_MICA_EFFECT, 1)
        return res == 0
    except Exception:  # noqa: BLE001
        log.debug("Glass effect not applied", exc_info=True)
        return False
