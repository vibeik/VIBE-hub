@echo off
setlocal
chcp 65001 >nul
cd /d "%~dp0"
echo ==== VIBE HUB: installation ====

set "PY="
where py >nul 2>nul && (py -3.13 -c "pass" >nul 2>nul && set "PY=py -3.13")
if not defined PY where py >nul 2>nul && (py -3.12 -c "pass" >nul 2>nul && set "PY=py -3.12")
if not defined PY where py >nul 2>nul && (py -3.11 -c "pass" >nul 2>nul && set "PY=py -3.11")
if not defined PY where python >nul 2>nul && (python -c "import sys;sys.exit(0 if sys.version_info>=(3,11) else 1)" >nul 2>nul && set "PY=python")
if not defined PY (
    echo [ERROR] Python 3.11 or newer was not found.
    echo Install it from https://www.python.org/downloads/ ^(tick "Add python.exe to PATH"^) and run install.bat again.
    pause
    exit /b 1
)
echo Using: %PY%

if not exist ".venv\Scripts\python.exe" (
    echo Creating virtual environment .venv ...
    %PY% -m venv .venv
    if errorlevel 1 ( echo [ERROR] Could not create the virtual environment. & pause & exit /b 1 )
)

echo Installing dependencies ...
".venv\Scripts\python.exe" -m pip install --upgrade pip
if errorlevel 1 ( echo [ERROR] pip upgrade failed. Check your internet connection. & pause & exit /b 1 )
".venv\Scripts\python.exe" -m pip install -r requirements.txt
if errorlevel 1 ( echo [ERROR] Dependency installation failed. See messages above. & pause & exit /b 1 )

echo.
echo Self-test: creating the window and every page on temporary data ...
".venv\Scripts\python.exe" main.py --selftest
if errorlevel 1 (
    echo.
    echo [WARNING] Self-test reported problems. The log is in %%APPDATA%%\VibeHub\logs\vibehub.log
    echo Please send that file to the developer.
    pause
    exit /b 1
)

echo.
echo Done. Start the app with run.bat
pause
