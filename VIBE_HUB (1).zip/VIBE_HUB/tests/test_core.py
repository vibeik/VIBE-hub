"""БД, репозитории, статистика, цели, очередь воспроизведения, настройки, секреты, логи."""
import sqlite3
from datetime import date, datetime, timedelta

import pytest

from database.db import Database, DatabaseError
from modules import dashboard_data, stats
from modules.goal_service import build_context, sync_auto_goals
from modules.goals import is_reached, progress_percent
from modules.playqueue import PlayQueue
from utils.logger import redact
from utils.timeutil import to_iso


def _m(repos, **kw):
    d = dict(map="Mirage", played_at=to_iso(datetime.now()), result="win", kills=20, deaths=10, assists=3)
    d.update(kw)
    return repos.matches.add(**d)


# ---------- matches ----------
def test_match_crud_and_validation(repos):
    mid = _m(repos)
    assert repos.matches.get(mid)["kills"] == 20
    repos.matches.update(mid, kills=25, result="loss")
    got = repos.matches.get(mid)
    assert got["kills"] == 25 and got["result"] == "loss"
    with pytest.raises(ValueError):
        repos.matches.add(map="x", played_at="2025-01-01", result="oops", kills=1, deaths=1)
    with pytest.raises(ValueError):
        repos.matches.add(map="x", played_at="2025-01-01", result="win", kills=-1, deaths=1)
    assert repos.matches.delete(mid) and repos.matches.get(mid) is None


def test_match_filters_by_date_source_map(repos):
    now = datetime.now()
    _m(repos, played_at=to_iso(now - timedelta(days=40)), map="Nuke")
    _m(repos, played_at=to_iso(now - timedelta(days=2)), map="Mirage")
    repos.matches.upsert_external("faceit", "abc", map="Inferno", played_at=to_iso(now), result="win",
                                  kills=10, deaths=5, assists=1)
    assert len(repos.matches.list()) == 3
    assert len(repos.matches.list(date_from=now - timedelta(days=7))) == 2
    assert [m["map"] for m in repos.matches.list(source="faceit")] == ["Inferno"]
    assert repos.matches.list(map_name="Nuke")[0]["map"] == "Nuke"
    assert repos.matches.maps() == ["Inferno", "Mirage", "Nuke"]


def test_external_import_is_idempotent(repos):
    kw = dict(map="Mirage", played_at="2025-05-01 10:00:00", result="win", kills=1, deaths=1, assists=0)
    assert repos.matches.upsert_external("faceit", "m1", **kw) is True
    assert repos.matches.upsert_external("faceit", "m1", **kw) is False
    assert len(repos.matches.list()) == 1


# ---------- stats ----------
def test_stats_summary(repos):
    _m(repos, kills=20, deaths=10)
    _m(repos, kills=10, deaths=20, result="loss")
    _m(repos, kills=5, deaths=0, result="draw")
    s = stats.summarize(repos.matches.list())
    assert s["matches"] == 3 and s["wins"] == 1 and s["losses"] == 1 and s["draws"] == 1
    assert s["win_rate"] == 50.0                  # ничьи не входят в Win Rate
    assert s["kd"] == pytest.approx(35 / 30)
    assert stats.summarize([])["kd"] is None and stats.summarize([])["win_rate"] is None


def test_kd_zero_deaths():
    assert stats.kd(7, 0) == 7.0


def test_by_day_includes_empty_days(repos):
    today = date.today()
    _m(repos, played_at=to_iso(datetime.now()))
    days = stats.by_day(repos.matches.list(), 7, today)
    assert len(days) == 7 and days[today]["matches"] == 1
    assert sum(d["matches"] for d in days.values()) == 1


def test_weekly_dashboard_data(repos):
    _m(repos)
    w = dashboard_data.weekly(repos)
    assert len(w["days"]) == 7 and sum(w["matches"]) == 1 and w["wins"][-1] == 1
    assert w["kd"][0] is None   # день без матчей — не 0, а «нет данных»


# ---------- goals ----------
def test_goal_logic():
    assert is_reached(0, 10, 10) and not is_reached(0, 9, 10)
    assert is_reached(10, 4, 5) is True            # цель «снизиться»
    assert progress_percent(0, 5, 10) == 50
    assert progress_percent(1000, 900, 1000) == 0  # не уходит в минус


def test_goal_lifecycle_history_and_completion(repos):
    gid = repos.goals.create("ELO 2000", 2000, category="FACEIT", start=1500, current=1500)
    assert repos.goals.set_current(gid, 1800) is False
    assert repos.goals.set_current(gid, 2000) is True
    g = repos.goals.get(gid)
    assert g["status"] == "completed" and g["completed_at"]
    fields = [h["field"] for h in repos.goals.history(gid)]
    assert "created" in fields and "current_value" in fields and "status" in fields
    repos.goals.update(gid, title="ELO 2100", target_value=2100)
    assert repos.goals.get(gid)["title"] == "ELO 2100"
    with pytest.raises(ValueError):
        repos.goals.update(gid, title="  ")
    assert repos.goals.delete(gid) and repos.goals.history(gid) == []   # история удаляется каскадно


def test_auto_goals_sync(repos):
    gid = repos.goals.create("K/D 1.5", 1.5, metric="tracker_kd", start=1.0, current=1.0)
    _m(repos, kills=30, deaths=10)
    ctx = build_context(repos, None)
    done = sync_auto_goals(repos, ctx)
    assert [g["id"] for g in done] == [gid]
    assert repos.goals.get(gid)["status"] == "completed"
    assert sync_auto_goals(repos, ctx) == []        # повторно — без дублей уведомлений
    assert repos.activity.recent(5)[0]["kind"] == "goal"


# ---------- accounts / cache / snapshots ----------
def test_account_upsert_keeps_extra_and_delete(repos):
    repos.accounts.upsert("faceit", external_id="1", username="n", extra={"a": 1}, touch_connected=True)
    repos.accounts.upsert("faceit", username="n2", extra={"b": 2})
    a = repos.accounts.get("faceit")
    assert a["username"] == "n2" and a["extra"] == {"a": 1, "b": 2} and a["external_id"] == "1"
    repos.accounts.delete("faceit")
    assert repos.accounts.get("faceit") is None


def test_snapshots_dedupe(repos):
    repos.snapshots.add(elo=1000, level=3, matches=10, wins=5, win_rate=50, kd=1.0, hs_pct=40)
    repos.snapshots.add(elo=1000, level=3, matches=10, wins=5, win_rate=50, kd=1.0, hs_pct=40)
    repos.snapshots.add(elo=1025, level=3, matches=11, wins=6, win_rate=55, kd=1.0, hs_pct=40)
    assert [s["elo"] for s in repos.snapshots.since(None)] == [1000, 1025]


def test_cache_roundtrip(repos):
    ts = repos.cache.set("k:1", {"a": [1, 2]})
    assert repos.cache.get("k:1") == ({"a": [1, 2]}, ts)
    repos.cache.clear("k:")
    assert repos.cache.get("k:1") is None


def test_activity_trim(repos):
    for i in range(520):
        repos.activity.add("x", str(i))
    assert len(repos.activity.recent(1000)) == 500


# ---------- music repo ----------
def test_music_library_and_playlists(repos):
    m = repos.music
    m.add_folder("C:/Music")
    for i in range(3):
        m.upsert_track({"path": f"C:/Music/{i}.mp3", "folder": "C:/Music", "title": f"Song {i}", "artist": "A",
                        "album": "", "duration_ms": 1000, "cover": None, "mtime": 1.0})
    assert m.count_tracks() == 3 and len(m.tracks("song 1")) == 1
    pid = m.create_playlist("Fav")
    ids = [t["id"] for t in m.tracks()]
    assert m.add_to_playlist(pid, ids) == 3 and m.add_to_playlist(pid, ids[:1]) == 0
    m.remove_from_playlist(pid, ids[0])
    assert len(m.playlist_tracks(pid)) == 2 and m.playlists()[0]["count"] == 2
    m.remove_folder("C:/Music")
    assert m.count_tracks() == 0 and m.playlist_tracks(pid) == []


# ---------- PlayQueue ----------
def test_playqueue_sequential_and_repeat():
    q = PlayQueue()
    q.set_queue([1, 2, 3], start_id=2)
    assert q.current == 2 and q.next() == 3 and q.next() is None
    q.set_repeat("all")
    assert q.next() == 1 and q.prev() == 3
    q.set_repeat("one")
    assert q.next(auto=True) == q.current
    assert q.prev() is not None


def test_playqueue_shuffle_keeps_current_and_all_tracks():
    q = PlayQueue()
    q.set_queue(list(range(10)), start_id=4)
    q.set_shuffle(True)
    assert q.current == 4
    seen = [q.current]
    while (n := q.next()) is not None:
        seen.append(n)
    assert sorted(seen) == list(range(10))
    q.set_shuffle(False)
    assert q.current == seen[-1]


# ---------- DB: backup / restore / recovery ----------
def test_backup_restore_roundtrip(tmp_path, db, repos):
    _m(repos)
    b = db.backup_to(tmp_path / "b.db")
    _m(repos)
    assert len(repos.matches.list()) == 2
    db.restore_from(b, tmp_path / "bk")
    assert len(repos.matches.list()) == 1
    assert list((tmp_path / "bk").glob("pre-restore-*.db"))   # страховочная копия создана


def test_restore_rejects_garbage(tmp_path, db):
    bad = tmp_path / "x.db"
    bad.write_bytes(b"not a database at all" * 50)
    with pytest.raises(DatabaseError):
        db.validate_backup(bad)
    other = tmp_path / "other.db"
    c = sqlite3.connect(other)
    c.execute("CREATE TABLE foo(a)")
    c.commit()
    c.close()
    with pytest.raises(DatabaseError):
        db.validate_backup(other)
    with pytest.raises(DatabaseError):
        db.validate_backup(tmp_path / "missing.db")


def test_recovery_from_corrupt_db_uses_backup(tmp_path):
    p, bk = tmp_path / "v.db", tmp_path / "bk"
    d = Database(p)
    from database.repos import Repos
    Repos(d).goals.create("keep me", 5)
    d.auto_backup(bk)
    d.close()
    p.write_bytes(b"garbage" * 1000)
    for ext in ("-wal", "-shm"):
        (tmp_path / f"v.db{ext}").unlink(missing_ok=True)
    d2 = Database.open_with_recovery(p, bk)
    assert d2.recovered_from and "восстановлена" in d2.recovered_from
    assert Repos(d2).goals.list()[0]["title"] == "keep me"
    d2.close()


def test_recovery_without_backup_creates_fresh_db(tmp_path):
    p = tmp_path / "v.db"
    p.write_bytes(b"garbage" * 1000)
    d = Database.open_with_recovery(p, tmp_path / "none")
    assert d.recovered_from and d.query_one("SELECT COUNT(*) FROM matches")[0] == 0
    d.close()


def test_auto_backup_rotation(tmp_path, db):
    bk = tmp_path / "bk"
    bk.mkdir()
    for i in range(8):
        (bk / f"auto-2020010{i}.db").write_bytes(b"x")
    db.auto_backup(bk, keep=5)
    assert len(list(bk.glob("auto-*.db"))) == 5


def test_concurrent_writes(db, repos):
    import threading
    errs = []

    def work():
        try:
            for _ in range(30):
                _m(repos)
        except Exception as e:  # pragma: no cover
            errs.append(e)

    ts = [threading.Thread(target=work) for _ in range(5)]
    [t.start() for t in ts]
    [t.join() for t in ts]
    assert not errs and len(repos.matches.list()) == 150


# ---------- settings / secrets / logs ----------
def test_settings_persist_and_recover_from_corrupt(tmp_path):
    from config.settings import Settings
    p = tmp_path / "s.json"
    s = Settings(p)
    seen = []
    s.on_change(lambda k, v: seen.append((k, v)))
    s.set("accent", "#123456")
    assert Settings(p).get("accent") == "#123456" and seen == [("accent", "#123456")]
    p.write_text("{broken", encoding="utf-8")
    s2 = Settings(p)
    assert s2.get("language") == "ru" and p.with_suffix(".json.bad").exists()


def test_secret_store_in_memory_fallback():
    from utils.secrets import SecretStore

    class Boom:
        def set_password(self, *a): raise RuntimeError("no backend")
        def get_password(self, *a): raise RuntimeError("no backend")
        def delete_password(self, *a): raise RuntimeError("no backend")

    s = SecretStore(backend=Boom())
    s.set("k", "v")
    assert s.get("k") == "v" and s.problem
    s.delete("k")
    assert s.get("k") is None


def test_log_redaction():
    t = redact("GET https://x/y?key=SECRET123&steamid=1 Authorization: Bearer abcdefghijkl1234 "
               '{"access_token": "TOPSECRET"} code_verifier=zzz')
    for leaked in ("SECRET123", "abcdefghijkl1234", "TOPSECRET", "zzz"):
        assert leaked not in t
    assert "steamid=1" in t


def test_pc_history_prune(repos):
    repos.pc.add({"cpu": 10.0, "ram": 20.0})
    repos.db.execute("INSERT INTO pc_history(ts,cpu) VALUES('2000-01-01 00:00:00', 1)")
    repos.pc.prune(7)
    assert len(repos.pc.since(datetime(2000, 1, 1))) == 1
