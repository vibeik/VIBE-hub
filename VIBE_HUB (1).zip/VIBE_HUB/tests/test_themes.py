"""Темы и QSS: палитры читаемы, QSS собирается без пропущенных подстановок, стекло не делает окно «пустым»."""
import re

import pytest
from config.settings import DEFAULTS
from ui import palettes as pal
from ui.qss import build_qss

HEX = re.compile(r"^#[0-9A-Fa-f]{6}$")
KEYS = {"bg", "surface", "surface2", "border", "text", "muted", "accent", "accent2"}


def colors(name: str) -> dict[str, str]:
    c = dict(pal.PALETTES[name])
    c.update(pal.STATUS)
    return c


def test_catalog_is_consistent():
    assert set(pal.THEME_LABELS) == set(pal.PALETTES)
    assert pal.DEFAULT_THEME in pal.PALETTES and DEFAULTS["theme"] in pal.PALETTES
    assert len(pal.PALETTES) >= 12
    for name, p in pal.PALETTES.items():
        assert set(p) == KEYS, name
        assert all(HEX.match(v) for v in p.values()), name
    assert DEFAULTS["accent"] == pal.PALETTES[DEFAULTS["theme"]]["accent"]
    assert DEFAULTS["accent2"] == pal.PALETTES[DEFAULTS["theme"]]["accent2"]


def test_themes_are_distinct():
    assert len({(p["accent"], p["accent2"]) for p in pal.PALETTES.values()}) == len(pal.PALETTES)
    assert len({p["bg"] for p in pal.PALETTES.values()}) == len(pal.PALETTES)


@pytest.mark.parametrize("name", sorted(pal.PALETTES))
def test_palette_is_readable(name):
    p = pal.PALETTES[name]
    assert pal.contrast(p["text"], p["bg"]) >= 12
    assert pal.contrast(p["text"], p["surface2"]) >= 10
    assert pal.contrast(p["muted"], p["surface2"]) >= 4.5       # приглушённый текст на карточке (WCAG AA)
    assert pal.contrast(p["accent2"], p["bg"]) >= 4.0           # акцентные цифры на фоне
    assert pal.contrast(p["accent"], p["bg"]) >= 4.0
    assert pal.on_accent(p["accent"], p["accent2"]) == "#FFFFFF"  # белый текст на кнопках встроенных тем читается


def test_on_accent_switches_for_light_accents():
    assert pal.on_accent("#FACC15", "#F59E0B") == "#0B0B12"      # жёлтый акцент — тёмный текст
    assert pal.on_accent("#A3E635", "#22D3EE") == "#0B0B12"


def test_mix_and_contrast_basics():
    assert pal.mix("#000000", "#FFFFFF", 0.5) == "#808080"
    assert pal.mix("#123456", "#ABCDEF", 0) == "#123456"
    assert round(pal.contrast("#000000", "#FFFFFF")) == 21


@pytest.mark.parametrize("name", sorted(pal.PALETTES))
@pytest.mark.parametrize("glass", [None, 0.9, 0.7, 0.3])
def test_qss_has_no_unresolved_placeholders(name, glass):
    q = build_qss(colors(name), glass)
    assert not re.findall(r"\$[A-Za-z_]", q)
    assert q.count("{") == q.count("}")
    assert "None" not in q and "nan" not in q


def test_opaque_by_default_and_glass_changes_only_window_background():
    c = colors("violet")
    solid, glass = build_qss(c, None), build_qss(c, 0.7)
    assert "QMainWindow { background: #0B0B12; }" in solid and "QWidget#Root { background: #0B0B12; }" in solid
    assert "QMainWindow { background: transparent; }" in glass
    assert "QWidget#Root { background: rgba(11,11,18,0.70); }" in glass
    assert "QDialog, QMessageBox { background: #0B0B12; }" in glass      # диалоги всегда непрозрачные


def test_glass_never_goes_below_minimum_alpha():
    q = build_qss(colors("violet"), 0.05)
    assert "QWidget#Root { background: rgba(11,11,18,0.30); }" in q
    q = build_qss(colors("violet"), 3.0)
    assert "rgba(11,11,18,0.95)" in q


def test_corner_radii_are_rounder():
    q = build_qss(colors("violet"))
    radii = sorted({int(x) for x in re.findall(r"border-radius:\s*(\d+)px", q)})
    assert radii[-1] >= 22 and "QFrame#Card" in q
    card = re.search(r"QFrame#Card \{[^}]*\}", q).group(0)
    assert "border-radius: 22px" in card


def test_glass_defaults():
    assert DEFAULTS["glass"] in ("acrylic", "mica", "off")
    assert 10 <= DEFAULTS["glass_transparency"] <= 70
