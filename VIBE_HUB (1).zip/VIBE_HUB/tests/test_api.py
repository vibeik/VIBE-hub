"""HTTP-клиент, Steam OpenID, FACEIT, Spotify (сеть подменена — реальные сервисы не вызываются)."""
import socket
import threading
import time
import urllib.request

import pytest
import requests

from api import faceit_api as fapi
from api import spotify_api as sp
from api import steam_api as sapi
from api.http import ApiError, AuthError, HttpClient, NetworkError, NotFoundError, RateLimitError
from api.oauth_server import CallbackServer, OAuthError
from tests.conftest import FakeResp, FakeSession
from utils import secrets as sec


def mk(handler, **kw):
    s = FakeSession(handler)
    return HttpClient(session=s, sleep=lambda x: None, **kw), s


# ---------- HttpClient ----------
def test_http_rejects_plain_http():
    c, s = mk(lambda *a: FakeResp(200, {}))
    with pytest.raises(ApiError):
        c.request("GET", "http://insecure.test/x")
    assert s.calls == []


def test_http_retries_5xx_then_succeeds():
    seq = [FakeResp(503), FakeResp(502), FakeResp(200, {"ok": 1})]
    c, s = mk(lambda *a: seq.pop(0))
    assert c.get_json("https://a.test/x") == {"ok": 1} and len(s.calls) == 3


def test_http_network_error_message_has_no_secret():
    def boom(*a, **k):
        raise requests.ConnectionError("HTTPSConnectionPool(host='a', ...) url: /x?key=TOPSECRET")
    c, _ = mk(boom)
    with pytest.raises(NetworkError) as e:
        c.request("GET", "https://a.test/x", params={"key": "TOPSECRET"})
    assert "TOPSECRET" not in str(e.value)


def test_http_429_waits_retry_after_then_raises():
    seq = [FakeResp(429, headers={"Retry-After": "1"}), FakeResp(200, {"ok": True})]
    c, _ = mk(lambda *a: seq.pop(0))
    assert c.get_json("https://a.test/x") == {"ok": True}
    c2, _ = mk(lambda *a: FakeResp(429, headers={"Retry-After": "120"}))
    with pytest.raises(RateLimitError) as e:
        c2.request("GET", "https://a.test/x")
    assert e.value.retry_after == 120


def test_http_error_mapping():
    for code, exc in ((401, AuthError), (403, AuthError), (404, NotFoundError), (400, ApiError)):
        c, _ = mk(lambda *a, code=code: FakeResp(code, {"error": {"message": "m", "reason": "R"}}))
        with pytest.raises(exc) as e:
            c.request("GET", "https://a.test/x")
        assert e.value.status == code


def test_http_min_interval_throttles():
    slept = []
    c = HttpClient(session=FakeSession(lambda *a: FakeResp(200, {})), min_interval=0.5, sleep=slept.append)
    c.request("GET", "https://a.test/1")
    c.request("GET", "https://a.test/2")
    assert slept and slept[0] > 0


# ---------- локальный сервер колбэка ----------
def _free_port():
    with socket.socket() as s:
        s.bind(("127.0.0.1", 0))
        return s.getsockname()[1]


def test_callback_server_receives_params_and_times_out():
    port = _free_port()
    with CallbackServer(port, "/cb") as srv:
        threading.Timer(0.2, lambda: urllib.request.urlopen(f"http://127.0.0.1:{port}/cb?code=abc&state=s1").read()).start()
        assert srv.wait(5) == {"code": "abc", "state": "s1"}
    with CallbackServer(_free_port(), "/cb") as srv2:
        with pytest.raises(OAuthError):
            srv2.wait(0.4)
        t0 = time.time()
        with pytest.raises(OAuthError):
            srv2.wait(10, cancelled=lambda: True)
        assert time.time() - t0 < 2


def test_callback_server_port_busy():
    port = _free_port()
    with CallbackServer(port, "/cb"):
        with pytest.raises(OAuthError):
            CallbackServer(port, "/cb").start()


# ---------- Steam ----------
RT = "http://127.0.0.1:8899/steam/callback"


def _openid(**over):
    p = {"openid.mode": "id_res", "openid.op_endpoint": sapi.OPENID_ENDPOINT, "openid.return_to": RT,
         "openid.claimed_id": "https://steamcommunity.com/openid/id/76561198000000001",
         "openid.identity": "https://steamcommunity.com/openid/id/76561198000000001", "openid.sig": "x"}
    p.update(over)
    return p


def test_steam_openid_validation():
    assert sapi.extract_steam_id(_openid(), RT) == "76561198000000001"
    assert sapi.extract_steam_id(_openid(**{"openid.mode": "cancel"}), RT) is None
    assert sapi.extract_steam_id(_openid(**{"openid.claimed_id": "https://evil.test/openid/id/76561198000000001"}), RT) is None
    assert sapi.extract_steam_id(_openid(**{"openid.return_to": "http://evil/"}), RT) is None
    assert sapi.extract_steam_id(_openid(**{"openid.op_endpoint": "https://evil/openid/login"}), RT) is None
    url = sapi.build_login_url(RT, "http://127.0.0.1:8899")
    assert url.startswith("https://steamcommunity.com/openid/login?") and "checkid_setup" in url


def test_steam_verify_assertion():
    c, s = mk(lambda *a, **k: FakeResp(200, text="ns:http://specs.openid.net/auth/2.0\nis_valid:true\n"))
    assert sapi.verify_assertion(_openid(), c) is True
    assert s.calls[0][2]["data"]["openid.mode"] == "check_authentication"
    c2, _ = mk(lambda *a, **k: FakeResp(200, text="is_valid:false\n"))
    assert sapi.verify_assertion(_openid(), c2) is False


def test_steam_xml_profile_and_bomb_rejected():
    xml = "<profile><steamID64>1</steamID64><steamID>Vibe</steamID><avatarFull>https://a/x.jpg</avatarFull><privacyState>public</privacyState></profile>"
    assert sapi.parse_profile_xml(xml)["personaname"] == "Vibe"
    assert sapi.parse_profile_xml('<!DOCTYPE x [<!ENTITY a "b">]><profile/>') is None


def test_steam_client_requires_key_and_handles_private():
    with pytest.raises(AuthError):
        sapi.SteamClient(None).steam_level("1")

    def handler(m, url, kw):
        if "GetOwnedGames" in url:
            return FakeResp(200, {"response": {}})
        if "GetPlayerAchievements" in url:
            return FakeResp(200, {"playerstats": {"success": False, "error": "Profile is not public"}})
        if "GetSteamLevel" in url:
            return FakeResp(200, {"response": {"player_level": 42}})
        return FakeResp(403)
    c, _ = mk(handler)
    cl = sapi.SteamClient("KEY", c)
    assert cl.owned_games("1") is None          # скрыто приватностью, не «0 игр»
    assert cl.steam_level("1") == 42
    with pytest.raises(sapi.PrivateProfileError):
        cl.achievements("1", 730)


def test_steam_achievements_parse():
    c, _ = mk(lambda *a, **k: FakeResp(200, {"playerstats": {"success": True, "gameName": "CS2", "achievements": [
        {"apiname": "A", "name": "First", "description": "d", "achieved": 1, "unlocktime": 5},
        {"apiname": "B", "name": "Second", "achieved": 0}]}}))
    r = sapi.SteamClient("K", c).achievements("1", 730)
    assert r["unlocked"] == 1 and r["total"] == 2


# ---------- FACEIT ----------
PLAYER = {"player_id": "pid", "nickname": "Vibe", "avatar": "https://a/x.png", "country": "am",
          "faceit_url": "https://www.faceit.com/{lang}/players/Vibe",
          "games": {"cs2": {"skill_level": 7, "faceit_elo": 1850, "region": "EU"}}}
ITEM = {"stats": {"Match Id": "1-abc", "Match Finished At": 1735732800000, "Result": "1", "Kills": "25", "Deaths": "15",
                  "Assists": "4", "Headshots %": "48", "Map": "de_mirage", "Final Score": "13 / 9"}}


def test_faceit_parsers():
    p = fapi.parse_player(PLAYER)
    assert p["level"] == 7 and p["elo"] == 1850 and "/ru/" in p["profile_url"]
    with pytest.raises(ApiError):
        fapi.parse_player({"nickname": "x", "games": {"csgo": {}}})
    lt = fapi.parse_lifetime({"lifetime": {"Matches": "100", "Wins": "55", "Win Rate %": "55",
                                           "Average K/D Ratio": "1.12", "Average Headshots %": "41",
                                           "Recent Results": ["1", "0"]}})
    assert lt["losses"] == 45 and lt["kd"] == 1.12 and lt["hs_pct"] == 41
    m = fapi.parse_match(ITEM)
    assert m["map"] == "Mirage" and m["result"] == "win" and m["kills"] == 25 and m["score"] == "13:9"
    assert fapi.parse_match({"stats": {"Kills": "1"}}) is None     # неполные данные пропускаются
    assert fapi.parse_lifetime({})["matches"] is None              # нет данных -> None, не выдумываем


def test_faceit_client_needs_key_and_sends_bearer():
    with pytest.raises(ApiError):
        fapi.FaceitClient("")
    c, s = mk(lambda *a, **k: FakeResp(200, PLAYER))
    fapi.FaceitClient("KEY", c).player_by_nickname("Vibe")
    assert s.calls[0][2]["headers"]["Authorization"] == "Bearer KEY"
    assert s.calls[0][2]["params"] == {"nickname": "Vibe", "game": "cs2"}
    c404, _ = mk(lambda *a, **k: FakeResp(404, {}))
    with pytest.raises(NotFoundError):
        fapi.FaceitClient("KEY", c404).player_by_nickname("nobody")


def _faceit_env(repos, settings, store, pages=None):
    from modules.faceit_service import FaceitService

    def handler(method, url, kw):
        if url.endswith("/stats/cs2"):
            return FakeResp(200, {"lifetime": {"Matches": "2", "Wins": "1", "Win Rate %": "50", "Average K/D Ratio": "1.1",
                                               "Average Headshots %": "40"}})
        if "/games/cs2/stats" in url:
            return FakeResp(200, {"items": pages or [ITEM, {"stats": {**ITEM["stats"], "Match Id": "2-x", "Result": "0",
                                                                       "Match Finished At": 1735736400000}}]})
        if "/players/pid" in url:
            return FakeResp(200, PLAYER)
        if "/players" in url:
            return FakeResp(200, PLAYER)
        return FakeResp(404, {})
    http, s = mk(handler)
    store.set(sec.FACEIT_API_KEY, "KEY")
    return FaceitService(repos, settings, store, client_factory=lambda k: fapi.FaceitClient(k, http)), s


def test_faceit_service_link_refresh_import(repos, settings, store):
    svc, _ = _faceit_env(repos, settings, store)
    svc.link("Vibe")
    assert svc.is_linked() and settings.get("faceit_nickname") == "Vibe"
    o = svc.refresh(force=True)
    assert o["level"] == 7 and o["elo"] == 1850 and o["matches"] == 2 and o["losses"] == 1
    assert len(repos.matches.list(source="faceit")) == 2
    assert o["elo_change"] is None                    # одного снимка мало — ничего не выдумываем
    svc.refresh(force=True)
    assert len(repos.matches.list(source="faceit")) == 2   # без дублей
    assert svc.refresh(force=False)["nickname"] == "Vibe"  # в пределах минуты — из кэша


def test_faceit_elo_change_from_snapshots(repos, settings, store):
    svc, _ = _faceit_env(repos, settings, store)
    svc.link("Vibe")
    repos.snapshots.add(elo=1800, level=7, matches=1, wins=1, win_rate=100, kd=1, hs_pct=1)
    repos.snapshots.add(elo=1850, level=7, matches=2, wins=2, win_rate=100, kd=1, hs_pct=1)
    assert svc.elo_change()["delta"] == 50


def test_faceit_disconnect_removes_everything(repos, settings, store):
    svc, _ = _faceit_env(repos, settings, store)
    svc.link("Vibe")
    svc.refresh(force=True)
    svc.disconnect()
    assert not svc.is_linked() and store.get(sec.FACEIT_API_KEY) is None
    assert repos.matches.list(source="faceit") == [] and repos.snapshots.last() is None
    assert svc.overview() == {"linked": False, "has_key": False}


# ---------- Spotify ----------
def test_spotify_pkce_and_auth_url():
    v, ch = sp.make_pkce()
    import base64
    import hashlib
    assert ch == base64.urlsafe_b64encode(hashlib.sha256(v.encode()).digest()).decode().rstrip("=")
    assert 43 <= len(v) <= 128
    url = sp.build_auth_url("cid", "http://127.0.0.1:8888/callback", ch, "st")
    assert "code_challenge_method=S256" in url and "127.0.0.1%3A8888" in url and "client_secret" not in url


def test_spotify_playback_parse():
    assert sp.parse_playback(None) is None
    d = {"is_playing": True, "progress_ms": 1000, "device": {"name": "PC"},
         "context": {"type": "playlist", "uri": "spotify:playlist:1"},
         "item": {"name": "Song", "duration_ms": 200000, "artists": [{"name": "A"}, {"name": "B"}],
                  "album": {"name": "Alb", "images": [{"url": "https://i.scdn.co/x"}]}}}
    p = sp.parse_playback(d, {"spotify:playlist:1": "Mix"})
    assert p["title"] == "Song" and p["artists"] == "A, B" and p["context_name"] == "Mix" and p["is_playing"]
    assert sp.parse_playback({"is_playing": False, "item": None})["title"] == ""   # реклама/нет трека — не падаем


def _spotify_client(store, handler):
    http, s = mk(handler)
    store.set(sec.SPOTIFY_ACCESS, "AT")
    store.set(sec.SPOTIFY_REFRESH, "RT")
    store.set(sec.SPOTIFY_EXPIRES, str(time.time() + 3600))
    return sp.SpotifyClient("cid", store, http), s


def test_spotify_refresh_on_expiry_and_401(store):
    calls = {"token": 0}

    def handler(m, url, kw):
        if url == sp.TOKEN_URL:
            calls["token"] += 1
            return FakeResp(200, {"access_token": "AT2", "expires_in": 3600})
        if kw["headers"]["Authorization"] == "Bearer AT2":
            return FakeResp(200, {"id": "u"})
        return FakeResp(401, {"error": {"message": "expired"}})
    cl, _ = _spotify_client(store, handler)
    assert cl.me() == {"id": "u"} and calls["token"] == 1
    assert store.get(sec.SPOTIFY_REFRESH) == "RT"      # refresh-токен сохранён, если сервер не прислал новый


def test_spotify_revoked_refresh_clears_tokens(store):
    def handler(m, url, kw):
        return FakeResp(400, {"error": "invalid_grant"}) if url == sp.TOKEN_URL else FakeResp(401)
    cl, _ = _spotify_client(store, handler)
    store.set(sec.SPOTIFY_EXPIRES, "0")
    with pytest.raises(AuthError):
        cl.me()
    assert not cl.has_tokens()


def test_spotify_premium_and_no_device_errors(store):
    def handler(m, url, kw):
        if url.endswith("/next"):
            return FakeResp(403, {"error": {"status": 403, "reason": "PREMIUM_REQUIRED", "message": "Premium required"}})
        return FakeResp(404, {"error": {"status": 404, "reason": "NO_ACTIVE_DEVICE", "message": "x"}})
    cl, _ = _spotify_client(store, handler)
    with pytest.raises(sp.PremiumRequired):
        cl.next()
    with pytest.raises(sp.NoActiveDevice):
        cl.pause()


def test_spotify_playback_204_and_playlists_paging(store):
    def handler(m, url, kw):
        if url.endswith("/me/player"):
            return FakeResp(204)
        off = kw["params"]["offset"]
        items = [{"id": str(off + i), "uri": f"spotify:playlist:{off + i}", "name": f"P{off + i}", "images": [],
                  "items": {"total": 3}} for i in range(2)]
        return FakeResp(200, {"items": items, "next": "x" if off < 50 else None})
    cl, _ = _spotify_client(store, handler)
    assert cl.playback() is None
    pl = cl.playlists()
    assert len(pl) == 4 and pl[0]["total"] == 3


def test_spotify_service_connect_state_check_and_disconnect(repos, settings, store):
    from modules.spotify_service import SpotifyService
    port = _free_port()
    settings.set("spotify_client_id", "cid")
    settings.set("spotify_port", port)

    def handler(m, url, kw):
        if url == sp.TOKEN_URL:
            assert kw["data"]["code_verifier"] and kw["data"]["client_id"] == "cid"
            return FakeResp(200, {"access_token": "AT", "refresh_token": "RT", "expires_in": 3600})
        return FakeResp(200, {"id": "u1", "display_name": "Vibe", "external_urls": {"spotify": "https://open.spotify.com/user/u1"}})
    http, _ = mk(handler)
    svc = SpotifyService(repos, settings, store, http)

    def fake_browser(url):
        from urllib.parse import parse_qs, urlsplit
        st = parse_qs(urlsplit(url).query)["state"][0]
        threading.Timer(0.2, lambda: urllib.request.urlopen(
            f"http://127.0.0.1:{port}/callback?code=C&state={st}").read()).start()
    svc.connect(open_browser=fake_browser, timeout=5)
    assert svc.is_connected() and repos.accounts.get("spotify")["username"] == "Vibe"
    svc.disconnect()
    assert not svc.is_connected() and store.get(sec.SPOTIFY_REFRESH) is None

    def bad_state_browser(url):
        threading.Timer(0.2, lambda: urllib.request.urlopen(
            f"http://127.0.0.1:{port}/callback?code=C&state=WRONG").read()).start()
    with pytest.raises(AuthError):
        svc.connect(open_browser=bad_state_browser, timeout=5)
    assert not svc.is_connected()


# ---------- Steam service ----------
def test_steam_service_signin_refresh_private_and_disconnect(repos, settings, store):
    from modules.steam_service import SteamService
    port = _free_port()
    sid = "76561198000000001"

    def handler(m, url, kw):
        if "openid/login" in url:
            return FakeResp(200, text="is_valid:true\n")
        if "GetPlayerSummaries" in url:
            return FakeResp(200, {"response": {"players": [{"personaname": "Vibe", "avatarfull": "https://a/x.jpg",
                                                            "profileurl": "https://steamcommunity.com/id/vibe/",
                                                            "communityvisibilitystate": 1}]}})
        return FakeResp(500)
    http, _ = mk(handler)
    svc = SteamService(repos, settings, store, http=http)

    def browser(url):
        from urllib.parse import quote
        q = (f"openid.mode=id_res&openid.op_endpoint={quote(sapi.OPENID_ENDPOINT, safe='')}"
             f"&openid.return_to={quote(f'http://127.0.0.1:{port}/steam/callback', safe='')}"
             f"&openid.claimed_id={quote('https://steamcommunity.com/openid/id/' + sid, safe='')}"
             f"&openid.identity={quote('https://steamcommunity.com/openid/id/' + sid, safe='')}&openid.sig=x")
        threading.Timer(0.2, lambda: urllib.request.urlopen(f"http://127.0.0.1:{port}/steam/callback?{q}").read()).start()
    assert svc.sign_in(port, timeout=5, open_browser=browser) == sid
    store.set(sec.STEAM_API_KEY, "KEY")
    o = svc.refresh()
    assert o["name"] == "Vibe" and o["private"] is True and o["games_count"] == 0
    assert any("закрыт" in n for n in o["notes"])      # честно сообщаем о приватности, ничего не обходим
    svc.disconnect()
    assert not svc.is_linked() and store.get(sec.STEAM_API_KEY) is None
