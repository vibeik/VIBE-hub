"""Каждая русская строка интерфейса должна иметь английский перевод в assets/lang/en.json."""
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent / "tools"))

import collect_strings as cs  # noqa: E402
from utils import i18n  # noqa: E402


def test_every_ui_string_has_english_translation():
    miss = cs.missing()
    assert not miss, f"нет перевода для {len(miss)} строк, например: {miss[:5]}"


def test_translations_not_identical_to_source():
    en = cs.load_en()
    same = [k for k, v in en.items() if k == v and k not in cs.NO_TRANSLATION and not k.isascii()]
    assert not same, same


def test_set_language_en_translates_and_falls_back():
    try:
        i18n.set_language("en")
        assert i18n._("Сохранить") == "Save"
        assert i18n._("строка без перевода") == "строка без перевода"
        i18n.set_language("ru")
        assert i18n._("Сохранить") == "Сохранить"
    finally:
        i18n.set_language("ru")


def test_en_json_has_no_stale_keys():
    """Ключ в en.json, которого нет в исходниках, — устаревший перевод."""
    known = set(cs.collect()) | cs.EXTRA_KEYS
    stale = sorted(set(cs.load_en()) - known)
    assert not stale, f"устаревшие ключи: {stale[:5]}"
