"""Логика оптимизации без Qt: частота опроса датчиков, ограничитель дорогих вызовов, отчёт о задержках."""
from __future__ import annotations

import pytest

from modules import sensors
from modules.polling import BACKGROUND_INTERVAL_MS, IDLE_INTERVAL_MS, WatchCounter, poll_interval_ms
from utils import perf


# ---------------------------------------------------------------- частота опроса
def test_poll_interval_live_when_watched():
    assert poll_interval_ms(1000, background=False, watchers=1, record=True) == 1000
    assert poll_interval_ms(500, background=False, watchers=2, record=False) == 500


def test_poll_interval_slow_when_nobody_watches():
    assert poll_interval_ms(1000, background=False, watchers=0, record=True) == IDLE_INTERVAL_MS
    # историю не пишем — опрашивать нужно ещё реже
    assert poll_interval_ms(1000, background=False, watchers=0, record=False) == IDLE_INTERVAL_MS * 2


def test_poll_interval_background_never_faster_than_idle():
    assert poll_interval_ms(500, background=True, watchers=1, record=True) >= max(BACKGROUND_INTERVAL_MS, IDLE_INTERVAL_MS)


def test_poll_interval_respects_slow_user_setting():
    assert poll_interval_ms(20000, background=False, watchers=0, record=True) == 20000
    assert poll_interval_ms(100, background=False, watchers=1, record=True) == 250      # нижняя граница


def test_watch_counter_never_negative():
    w = WatchCounter()
    w.unwatch()
    assert w.count == 0
    w.watch(), w.watch()
    assert w.count == 2
    w.unwatch(), w.unwatch(), w.unwatch()
    assert w.count == 0


def test_page_switch_scenario():
    """Открыли Dashboard → живой опрос; ушли на Steam → редкий; свернули окно при открытом мониторе → тоже редкий."""
    w = WatchCounter()
    assert poll_interval_ms(1000, background=False, watchers=w.count, record=True) == IDLE_INTERVAL_MS
    w.watch()
    assert poll_interval_ms(1000, background=False, watchers=w.count, record=True) == 1000
    assert poll_interval_ms(1000, background=True, watchers=w.count, record=True) == IDLE_INTERVAL_MS
    w.unwatch()
    assert poll_interval_ms(1000, background=False, watchers=w.count, record=True) == IDLE_INTERVAL_MS


# ---------------------------------------------------------------- ограничитель
def test_throttle_first_call_is_due_then_waits():
    t = sensors.Throttle(2.0)
    assert t.due(100.0)
    t.done(100.0, 0.05)
    assert not t.due(101.9) and t.due(102.0)


def test_throttle_expensive_call_backs_off():
    t = sensors.Throttle(6.0, factor=10.0, max_s=60.0)
    t.done(0.0, 1.5)                     # вызов занял 1,5 с -> следующий не раньше чем через 15 с
    assert not t.due(14.9) and t.due(15.0)
    t.done(0.0, 30.0)                    # аномально дорогой вызов не может отложить опрос дольше max_s
    assert not t.due(59.9) and t.due(60.0)


def test_throttle_reset():
    t = sensors.Throttle(5.0)
    t.done(0.0, 0.0)
    t.reset()
    assert t.due(0.0)


@pytest.mark.parametrize("fails,expected", [(0, 10.0), (1, 60.0), (2, 300.0), (3, 900.0), (9, 900.0)])
def test_wmi_backoff_grows_and_caps(fails, expected):
    assert sensors.wmi_backoff(fails) == expected


def test_gpu_interval_by_source():
    assert sensors.SensorReader._gpu_interval({}) == sensors.GPU_NONE_EVERY_S
    assert sensors.SensorReader._gpu_interval({"name": "RTX", "util": 3.0}) == sensors.GPU_NVIDIA_EVERY_S
    assert sensors.SensorReader._gpu_interval({"util": 3.0, "name": None}) == sensors.GPU_ENGINE_EVERY_S


def test_sensor_reader_does_not_call_expensive_sources_every_tick(monkeypatch):
    """GPU и диски — не на каждом чтении: за несколько быстрых чтений подряд источник вызывается один раз."""
    calls = {"gpu": 0, "disks": 0}
    r = sensors.SensorReader()
    monkeypatch.setattr(r, "_read_gpu", lambda: (calls.__setitem__("gpu", calls["gpu"] + 1) or {}))
    real_disks = r._read_disks
    monkeypatch.setattr(r, "_read_disks", lambda: (calls.__setitem__("disks", calls["disks"] + 1) or real_disks()))
    monkeypatch.setattr(sensors, "read_cpu_temp", lambda: (None, "n/a"))
    for _ in range(5):
        s = r.read()
    assert calls["gpu"] == 1 and calls["disks"] == 1
    assert s.gpu is None and s.gpu_note             # данных нет — причина объяснена, ничего не выдумано


# ---------------------------------------------------------------- отчёт о задержках
def test_percentile_basics():
    assert perf.percentile([], 95) == 0.0
    assert perf.percentile([5.0], 99) == 5.0
    assert perf.percentile(list(range(101)), 50) == 50
    assert perf.percentile(list(range(101)), 95) == 95


def test_record_classifies_and_ignores_sleep_gaps():
    st = perf.PerfStats()
    for late in (0.0, 10.0, 60.0, 130.0, 300.0, -5.0):
        st.record("page:steam", late)
    st.record("page:steam", perf.IGNORE_MS + 1)           # ноутбук «спал» — не считаем подвисанием
    c = st.by_context["page:steam"]
    assert (c.ticks, c.slow, c.stalls, c.hitches) == (6, 3, 2, 1)
    assert c.worst_ms == 300.0 and st.total.ticks == 6


def test_worst_list_is_sorted_and_capped():
    st = perf.PerfStats()
    for i in range(30):
        st.record("x", 130.0 + i)
    assert len(st.worst) == perf.WORST_KEEP
    assert [w[0] for w in st.worst] == sorted((w[0] for w in st.worst), reverse=True)
    assert st.worst[0][0] == 159.0


def test_report_has_sections_and_no_user_data():
    st = perf.PerfStats()
    st.env = {"os": "Windows-11", "screen": "1920x1080 logical, DPR 1.50"}
    st.record("switch:faceit", 200.0)
    st.record("page:dashboard", 4.0)
    st.event("page faceit: create", 123.4)
    text = st.report()
    for needle in ("performance report", "os: Windows-11", "switch:faceit", "worst freezes", "page faceit: create", "123.4"):
        assert needle in text


def test_report_without_samples_is_honest():
    assert "no samples yet" in perf.PerfStats().report()


def test_events_are_bounded():
    st = perf.PerfStats()
    for i in range(perf.EVENTS_KEEP * 3):
        st.event(f"e{i}", 1.0)
    assert len(st.events) == perf.EVENTS_KEEP
