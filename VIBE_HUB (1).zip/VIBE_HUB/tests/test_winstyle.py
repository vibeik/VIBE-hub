"""Выбор режима стекла по версии Windows (сам вызов DWM проверяется только на Windows)."""
from utils import winstyle as w


def test_modes_by_build():
    assert w.effective_glass_mode("acrylic", build=26100) == "acrylic"       # Windows 11 24H2
    assert w.effective_glass_mode("acrylic", build=22621) == "acrylic"       # 22H2 — первая сборка с типами подложки
    assert w.effective_glass_mode("acrylic", build=22000) == "mica"          # Windows 11 21H2: Acrylic нет, остаётся Mica
    assert w.effective_glass_mode("mica", build=22621) == "mica"
    assert w.effective_glass_mode("acrylic", build=19045) == "off"           # Windows 10
    assert w.effective_glass_mode("acrylic", build=0) == "off"               # не Windows


def test_unknown_or_off_is_off():
    for req in ("off", "", None, "blur", 3):
        assert w.effective_glass_mode(req, build=26100) == "off"


def test_noop_off_windows():
    assert w.windows_build() == 0
    assert w.apply_glass(123, "acrylic") is False
    w.apply_dark_titlebar(123)           # не падает
