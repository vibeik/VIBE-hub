import sys
from pathlib import Path

import pytest

ROOT = Path(__file__).resolve().parent.parent
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))


class FakeResp:
    def __init__(self, status=200, json_data=None, text="", headers=None, url="https://example.test/x"):
        self.status_code = status
        self._json = json_data
        self.text = text if text or json_data is None else ""
        self.headers = headers or {}
        self.url = url
        self.content = b"x" if (json_data is not None or text) else b""

    def json(self):
        if self._json is None:
            raise ValueError("no json")
        return self._json


class FakeSession:
    """Подменяет requests.Session: отвечает по очереди или по функции-обработчику."""

    def __init__(self, handler):
        self.handler = handler
        self.calls = []

    def request(self, method, url, **kw):
        self.calls.append((method, url, kw))
        return self.handler(method, url, kw)


@pytest.fixture
def db(tmp_path):
    from database.db import Database
    d = Database(tmp_path / "t.db")
    yield d
    d.close()


@pytest.fixture
def repos(db):
    from database.repos import Repos
    return Repos(db)


@pytest.fixture
def settings(tmp_path):
    from config.settings import Settings
    return Settings(tmp_path / "settings.json")


class MemKeyring:
    def __init__(self):
        self.d = {}

    def set_password(self, s, n, v):
        self.d[(s, n)] = v

    def get_password(self, s, n):
        return self.d.get((s, n))

    def delete_password(self, s, n):
        if (s, n) not in self.d:
            raise KeyError(n)
        del self.d[(s, n)]


@pytest.fixture
def store():
    from utils.secrets import SecretStore
    return SecretStore(backend=MemKeyring())
