"""Сенсоры, сканер музыки, i18n, форматирование, автозапуск."""
import json
from pathlib import Path

from modules import autostart, music_scan, sensors
from utils import format as F
from utils import i18n


def test_parse_nvidia_smi_values_and_na():
    r = sensors.parse_nvidia_smi("NVIDIA GeForce RTX 4050 Laptop GPU, 37, 52, 1024, 6144\n")
    assert r == {"name": "NVIDIA GeForce RTX 4050 Laptop GPU", "util": 37.0, "temp": 52.0, "mem_used": 1024.0, "mem_total": 6144.0}
    r = sensors.parse_nvidia_smi("GPU, [N/A], [Not Supported], 10, 20")
    assert r["util"] is None and r["temp"] is None           # «нет данных» — None, не 0
    assert sensors.parse_nvidia_smi("") is None and sensors.parse_nvidia_smi("a,b") is None


def test_parse_gpu_engine_total_clamps():
    assert sensors.parse_gpu_engine_total("10.5\n20\n\n") == 30.5
    assert sensors.parse_gpu_engine_total("80\n90\n") == 100.0
    assert sensors.parse_gpu_engine_total("error text") is None


def test_sensor_reader_real_snapshot_has_no_fake_values():
    r = sensors.SensorReader()
    s = r.read()
    assert 0 <= s.cpu <= 100 and 0 <= s.ram <= 100 and s.ram_total > 0
    assert s.net_down_bps is not None and s.net_down_bps >= 0
    if s.cpu_temp is None:
        assert s.cpu_temp_note             # причина отсутствия данных объяснена
    if s.gpu is None:
        assert s.gpu_note and s.gpu_temp is None


def test_music_scan(tmp_path, repos):
    (tmp_path / "Artist - Song One.mp3").write_bytes(b"x")
    (tmp_path / "plain.flac").write_bytes(b"x")
    (tmp_path / "sub").mkdir()
    (tmp_path / "sub" / "z.ogg").write_bytes(b"x")
    (tmp_path / "notes.txt").write_text("no")
    assert music_scan.title_from_filename(Path("Artist - Song One.mp3")) == ("Song One", "Artist")
    res = music_scan.scan_folder(repos.music, str(tmp_path), tmp_path / "covers")
    assert res["added"] == 3 and res["total"] == 3
    tr = {t["title"]: t for t in repos.music.tracks()}
    assert tr["Song One"]["artist"] == "Artist" and "plain" in tr
    assert music_scan.scan_folder(repos.music, str(tmp_path), tmp_path / "covers")["added"] == 0   # повторно — без изменений
    (tmp_path / "plain.flac").unlink()
    assert music_scan.scan_folder(repos.music, str(tmp_path), tmp_path / "covers")["removed"] == 1


def test_scan_can_be_stopped(tmp_path, repos):
    for i in range(5):
        (tmp_path / f"{i}.mp3").write_bytes(b"x")
    res = music_scan.scan_folder(repos.music, str(tmp_path), tmp_path, should_stop=lambda: True)
    assert res["total"] == 0 and repos.music.count_tracks() == 0


def test_i18n_fallback(tmp_path):
    (tmp_path / "en.json").write_text(json.dumps({"Привет": "Hello"}), encoding="utf-8")
    i18n.set_language("en", tmp_path)
    assert i18n._("Привет") == "Hello" and i18n._("Нет перевода") == "Нет перевода"
    i18n.set_language("ru")
    assert i18n._("Привет") == "Привет"
    i18n.set_language("en", tmp_path / "missing")      # нет файла — не падаем
    assert i18n._("Привет") == "Привет"
    i18n.set_language("ru")


def test_format_helpers():
    assert F.fmt_bytes(None) == "—" and F.fmt_bytes(1536) == "1.5 КБ" and F.fmt_bytes(10) == "10 Б"
    assert F.fmt_minutes(0) == "0 ч" and F.fmt_minutes(30) == "30 мин" and F.fmt_minutes(90) == "1.5 ч"
    assert F.fmt_ms(65000) == "1:05" and F.fmt_ms(3661000) == "1:01:01"
    assert F.fmt_num(2.0) == "2" and F.fmt_num(None) == "—" and F.fmt_signed(5) == "+5"


def test_autostart_command_and_non_windows():
    assert "main.py" in autostart.build_command() or "VibeHub" in autostart.build_command()
    if not autostart.supported():
        assert autostart.is_enabled() is False
        try:
            autostart.set_enabled(True)
            raised = False
        except OSError:
            raised = True
        assert raised
