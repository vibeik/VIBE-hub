"""Очистка при удалении: удаляет только своё и никогда — чужие папки. Реальные ключи и реестр в тестах не трогаются."""
import json
from pathlib import Path

import main as app_main
import pytest
from modules import cleanup
from utils import i18n
from utils import secrets as sec


class FakeKeyring:
    def __init__(self):
        self.data: dict[tuple[str, str], str] = {}

    def get_password(self, service, name):
        return self.data.get((service, name))

    def set_password(self, service, name, value):
        self.data[(service, name)] = value

    def delete_password(self, service, name):
        if (service, name) not in self.data:
            raise KeyError(name)
        del self.data[(service, name)]


@pytest.fixture(autouse=True)
def _isolate(monkeypatch):
    monkeypatch.setattr(cleanup.autostart, "supported", lambda: False)   # реестр не трогаем
    yield
    i18n.set_language("ru")


def _data_dir(tmp_path: Path) -> Path:
    base = tmp_path / "VibeHub"
    (base / "cache" / "covers").mkdir(parents=True)
    (base / "cache" / "covers" / "a.jpg").write_bytes(b"x")
    (base / "backups").mkdir()
    (base / "vibehub.db").write_bytes(b"db")
    (base / "settings.json").write_text(json.dumps({"language": "ru"}), encoding="utf-8")
    return base


def test_safe_dir_rules(tmp_path):
    assert cleanup.is_safe_data_dir(_data_dir(tmp_path))
    other = tmp_path / "Documents"
    other.mkdir()
    (other / "diploma.docx").write_bytes(b"x")
    assert not cleanup.is_safe_data_dir(other)                      # чужая папка
    marked = tmp_path / "custom"
    marked.mkdir()
    (marked / "vibehub.db").write_bytes(b"db")
    assert cleanup.is_safe_data_dir(marked)                         # своя, но с другим именем (VIBEHUB_DATA_DIR)
    assert not cleanup.is_safe_data_dir(Path.home())
    assert not cleanup.is_safe_data_dir(Path(Path.home().anchor or "/"))


def test_cache_only_keeps_user_data(tmp_path):
    base = _data_dir(tmp_path)
    steps = cleanup.run(False, base=base, store=sec.SecretStore(backend=FakeKeyring()))
    assert all(s.ok for s in steps), [s.line() for s in steps]
    assert not (base / "cache").exists()
    assert (base / "vibehub.db").exists() and (base / "settings.json").exists() and (base / "backups").exists()


def test_delete_data_removes_everything(tmp_path):
    base = _data_dir(tmp_path)
    steps = cleanup.run(True, base=base, store=sec.SecretStore(backend=FakeKeyring()))
    assert all(s.ok for s in steps)
    assert not base.exists()
    assert tmp_path.exists()                                         # родитель не тронут


def test_refuses_foreign_folder(tmp_path):
    other = tmp_path / "Documents"
    other.mkdir()
    (other / "diploma.docx").write_bytes(b"x")
    st = cleanup.remove_data(other)
    assert not st.ok and (other / "diploma.docx").exists()


def test_secrets_removed_but_foreign_entries_stay():
    kr = FakeKeyring()
    store = sec.SecretStore(backend=kr)
    for n in cleanup.ALL_SECRETS:
        store.set(n, "secret")
    kr.set_password("OtherApp", "token", "keep")
    st = cleanup.remove_secrets(store)
    assert st.ok, st.line()
    assert kr.data == {("OtherApp", "token"): "keep"}


def test_missing_data_dir_is_not_created(tmp_path):
    base = tmp_path / "VibeHub"
    steps = cleanup.run(True, base=base, store=sec.SecretStore(backend=FakeKeyring()))
    assert all(s.ok for s in steps)
    assert not base.exists()


def test_messages_follow_language_from_settings(tmp_path):
    base = _data_dir(tmp_path)
    (base / "settings.json").write_text(json.dumps({"language": "en"}), encoding="utf-8")
    steps = cleanup.run(False, base=base, store=sec.SecretStore(backend=FakeKeyring()))
    assert steps[2].name.startswith("Cache") and steps[2].detail == "removed"


def test_cli_flags(monkeypatch, capsys):
    calls: list[bool] = []

    def fake_run(delete_data, **_kw):
        calls.append(delete_data)
        return [cleanup.Step("x", True)]

    monkeypatch.setattr(cleanup, "run", fake_run)
    assert app_main.main(["--cleanup"]) == 0
    assert app_main.main(["--cleanup", "--delete-data"]) == 0
    assert calls == [False, True]
    assert "[ OK ] x" in capsys.readouterr().out
    monkeypatch.setattr(cleanup, "run", lambda *a, **k: [cleanup.Step("boom", False, "why")])
    assert app_main.main(["--cleanup"]) == 1
    assert app_main.main(["--delete-data"]) == 2                     # без --cleanup — отказ, ничего не удаляется
    assert calls == [False, True]
