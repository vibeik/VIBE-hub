import random

import pytest

from ui.dashboard.layout_engine import COLS, Item, Layout, collides


def defaults():
    return [Item("a", 0, 0, 6, 3), Item("b", 6, 0, 6, 3), Item("c", 0, 3, 12, 2), Item("d", 0, 5, 4, 2, min_w=3, min_h=2)]


def assert_invariants(lay: Layout):
    vis = lay.visible_items()
    for i, a in enumerate(vis):
        assert 0 <= a.x and a.x + a.w <= COLS, a
        assert a.y >= 0 and a.w >= a.min_w and a.h >= a.min_h, a
        for b in vis[i + 1:]:
            assert not collides(a, b), (a, b)
    # прижатость вверх: сдвиг на 1 вверх либо упирается в верх, либо в соседа
    for a in vis:
        if a.y == 0:
            continue
        a.y -= 1
        blocked = any(collides(a, b) for b in vis if b is not a)
        a.y += 1
        assert blocked, f"{a.id} можно сдвинуть вверх"


def test_defaults_valid():
    assert_invariants(Layout.from_defaults(defaults()))


def test_move_pushes_down_and_keeps_invariants():
    lay = Layout.from_defaults(defaults())
    lay.move("c", 0, 0)
    assert_invariants(lay)
    assert lay.items["c"].y == 0
    assert lay.items["a"].y >= 2 and lay.items["b"].y >= 2


def test_move_clamps_to_grid():
    lay = Layout.from_defaults(defaults())
    lay.move("d", 99, -5)
    d = lay.items["d"]
    assert d.x + d.w == COLS and d.y >= 0
    assert_invariants(lay)


def test_resize_clamps_min_and_cols():
    lay = Layout.from_defaults(defaults())
    lay.resize("d", 1, 1)
    assert (lay.items["d"].w, lay.items["d"].h) == (3, 2)
    lay.resize("d", 50, 3)
    assert lay.items["d"].w == COLS and lay.items["d"].x == 0
    assert_invariants(lay)


def test_hide_frees_space_and_show_puts_at_bottom():
    lay = Layout.from_defaults(defaults())
    lay.set_visible("a", False)
    assert lay.items["b"].y == 0 and lay.items["c"].y == 3
    assert_invariants(lay)
    rows_before = lay.rows()
    lay.set_visible("a", True)
    assert lay.items["a"].visible
    assert lay.rows() >= rows_before
    assert_invariants(lay)


def test_hidden_items_do_not_collide():
    lay = Layout.from_defaults(defaults())
    lay.set_visible("c", False)
    lay.move("d", 0, 0)
    assert_invariants(lay)
    assert lay.items["c"].visible is False


def test_json_roundtrip():
    lay = Layout.from_defaults(defaults())
    lay.move("b", 0, 0)
    lay.set_visible("d", False)
    restored = Layout.from_saved(lay.to_json(), defaults())
    for k, it in lay.items.items():
        r = restored.items[k]
        assert (r.visible, r.w, r.h) == (it.visible, it.w, it.h)
        if it.visible:
            assert (r.x, r.y) == (it.x, it.y)
    assert_invariants(restored)


@pytest.mark.parametrize("garbage", [None, 5, "x", [], {}, {"items": "nope"}, {"items": [1, None, "a"]},
                                     {"items": [{"id": "a", "x": "zz", "y": None, "w": -4, "h": 10 ** 30}]}])
def test_from_saved_survives_garbage(garbage):
    lay = Layout.from_saved(garbage, defaults())
    assert set(lay.items) == {"a", "b", "c", "d"}
    assert_invariants(lay)


def test_from_saved_unknown_dropped_and_new_added_at_bottom():
    saved = {"items": [{"id": "a", "x": 0, "y": 0, "w": 6, "h": 3, "visible": True},
                       {"id": "ghost", "x": 0, "y": 0, "w": 3, "h": 3},
                       {"id": "a", "x": 5, "y": 5, "w": 3, "h": 3}]}     # дубликат игнорируется
    lay = Layout.from_saved(saved, defaults())
    assert "ghost" not in lay.items
    assert lay.items["a"].w == 6
    assert set(lay.items) == {"a", "b", "c", "d"}
    assert_invariants(lay)


def test_overlapping_saved_data_is_resolved():
    saved = {"items": [{"id": k, "x": 0, "y": 0, "w": 12, "h": 3} for k in "abcd"]}
    lay = Layout.from_saved(saved, defaults())
    assert_invariants(lay)


def test_random_operations_keep_invariants():
    rng = random.Random(1234)
    lay = Layout.from_defaults(defaults() + [Item(f"w{i}", 0, 10 + i * 2, rng.randint(2, 6), rng.randint(2, 4)) for i in range(6)])
    ids = list(lay.items)
    for _ in range(800):
        op = rng.choice(["move", "resize", "toggle"])
        k = rng.choice(ids)
        if op == "move":
            lay.move(k, rng.randint(-3, 14), rng.randint(-3, 30))
        elif op == "resize":
            lay.resize(k, rng.randint(-1, 15), rng.randint(-1, 9))
        else:
            lay.set_visible(k, not lay.items[k].visible)
        assert_invariants(lay)


def test_copy_is_independent():
    lay = Layout.from_defaults(defaults())
    c = lay.copy()
    c.move("a", 6, 0)
    assert c.items["a"].x == 6
    assert lay.items["a"].x == 0 and lay.items["b"].x == 6
