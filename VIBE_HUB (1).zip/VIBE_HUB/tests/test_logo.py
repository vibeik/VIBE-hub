"""Логотип: рисунок валиден, варианты различаются, файлы .ico собраны корректно."""
import struct
import sys
import xml.etree.ElementTree as ET
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT / "tools"))

import make_logo  # noqa: E402

from config.settings import DEFAULTS  # noqa: E402
from utils import logo  # noqa: E402

PNG_SIG = b"\x89PNG\r\n\x1a\n"


def test_svg_is_valid_and_styles_differ():
    docs = {k: logo.logo_svg(k) for k in logo.STYLES}
    for svg in docs.values():
        root = ET.fromstring(svg)
        assert root.tag.endswith("svg") and root.get("viewBox") == "0 0 64 64"
    assert len(set(docs.values())) == len(docs)
    assert "#8B5CF6" in docs["violet"] and "#FACC15" in docs["yellow"]


def test_normalize_falls_back_to_default():
    assert logo.normalize("yellow") == "yellow"
    for bad in (None, "", "green", 5, ["violet"]):
        assert logo.normalize(bad) == logo.DEFAULT
    assert logo.logo_svg("nope") == logo.logo_svg(logo.DEFAULT)


def test_default_setting_is_known_style():
    assert DEFAULTS["logo_style"] in logo.STYLES


def _read_ico(data: bytes) -> dict[int, bytes]:
    reserved, kind, count = struct.unpack("<HHH", data[:6])
    assert (reserved, kind) == (0, 1)
    out = {}
    for i in range(count):
        w, _h, _c, _r, _planes, bpp, size, off = struct.unpack("<BBBBHHII", data[6 + 16 * i:22 + 16 * i])
        assert bpp == 32
        out[w or 256] = data[off:off + size]
    return out


def test_pack_ico_roundtrip():
    pngs = {s: PNG_SIG + bytes([s % 251]) * s for s in make_logo.ICO_SIZES}
    back = _read_ico(make_logo.pack_ico(pngs))
    assert back == pngs


def test_shipped_icons_are_complete():
    for style, (ico_name, png_name) in make_logo.FILES.items():
        entries = _read_ico((ROOT / "assets" / "icons" / ico_name).read_bytes())
        assert sorted(entries) == list(make_logo.ICO_SIZES), style
        assert all(blob.startswith(PNG_SIG) for blob in entries.values())
        assert (ROOT / "assets" / "images" / png_name).read_bytes().startswith(PNG_SIG)
